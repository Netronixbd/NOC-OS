#!/usr/bin/env bash
# Run as root on Ubuntu 22.04/24.04:  sudo bash install.sh   (safe to re-run for upgrades)
set -e
APP=/opt/isp-portal
apt-get update
apt-get install -y python3 python3-venv python3-pip tzdata snmp ppp pptp-linux iproute2
mkdir -p $APP && cp -r ./* $APP/ && cd $APP
# PPTP needs the ppp kernel modules
printf "ppp_generic\nppp_mppe\n" > /etc/modules-load.d/ppp.conf
modprobe ppp_generic 2>/dev/null || true
modprobe ppp_mppe 2>/dev/null || true
python3 -m venv venv
./venv/bin/pip install --upgrade pip && ./venv/bin/pip install -r requirements.txt
if [ ! -f .env ]; then
  cat > .env <<ENV
SECRET_KEY=$(python3 -c "import secrets;print(secrets.token_hex(32))")
ADMIN_USER=admin
ADMIN_PASS=Amir@2647
ENV
  chmod 600 .env
fi
cat > /etc/systemd/system/isp-portal.service <<UNIT
[Unit]
Description=Network Operations Console
After=network-online.target
[Service]
WorkingDirectory=$APP
EnvironmentFile=$APP/.env
ExecStart=$APP/venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000 --proxy-headers --forwarded-allow-ips='*'
Restart=always
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload && systemctl enable isp-portal && systemctl restart isp-portal
echo ">>> Done. Open http://SERVER_IP:8000  ·  login: admin / Amir@2647  (change it in My account)"
