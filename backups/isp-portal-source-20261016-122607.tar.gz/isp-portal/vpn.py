import threading
"""PPTP client tunnels (pppd + pptp-linux) so the server can reach private device IPs behind a MikroTik."""
import ipaddress
import os
import re
import shutil
import subprocess
import time

PPP = "/etc/ppp"
PEERS = f"{PPP}/peers"
CHAP = f"{PPP}/chap-secrets"
UPSCRIPT = f"{PPP}/ip-up.d/99-ispp-routes"
B, E = "# >>> isp-portal tunnels >>>", "# <<< isp-portal tunnels <<<"
HOST_RE = re.compile(r"^[A-Za-z0-9._\-]{1,253}$")
USER_RE = re.compile(r'^[^\s"\\]{1,64}$')


def peer(t):
    return f"ispp{t['id']}"


def available():
    return bool(shutil.which("pon") and shutil.which("pptp") and shutil.which("pppd"))


def validate(t):
    if not HOST_RE.match(t["server"] or ""):
        raise ValueError("Invalid server host")
    if not USER_RE.match(t["username"] or ""):
        raise ValueError("Invalid username (no spaces or quotes)")
    if "\n" in (t["password"] or "") or "\r" in (t["password"] or ""):
        raise ValueError("Invalid password")
    routes = []
    for r in (t.get("routes") or "").replace("\n", ",").split(","):
        r = r.strip()
        if r:
            routes.append(str(ipaddress.ip_network(r, strict=False)))
    return routes


def _q(s):
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'


def write_all(tunnels):
    """Write peer files, the managed chap-secrets block and the route script."""
    os.makedirs(PEERS, exist_ok=True)
    lines, cases = [], []
    for t in tunnels:
        routes = validate(t)
        p = peer(t)
        with open(f"{PEERS}/{p}", "w") as f:
            f.write("\n".join([
                f'pty "pptp {t["server"]} --nolaunchpppd"', f"name {t['username']}", f"remotename PPTP-{t['id']}",
                "noauth", "refuse-eap", "refuse-pap", "refuse-chap", "refuse-mschap", "require-mschap-v2",
                "require-mppe-128" if t.get("mppe", True) else "refuse-mppe", "nodefaultroute",
                f"ipparam {p}", f"ifname {p}", "persist", "maxfail 0", "holdoff 15", "lcp-echo-interval 20",
                "lcp-echo-failure 4", f"logfile /var/log/{p}.log", ""]))
        lines.append(f'{_q(t["username"])} {_q("PPTP-" + str(t["id"]))} {_q(t["password"])} *')
        if routes:
            cases.append(f'  {p}) ' + "; ".join(f'ip route replace {r} dev "$PPP_IFACE"' for r in routes) + " ;;")
    old = ""
    if os.path.exists(CHAP):
        old = open(CHAP).read()
    old = re.sub(re.escape(B) + r".*?" + re.escape(E) + r"\n?", "", old, flags=re.S)
    with open(CHAP, "w") as f:
        f.write(old.rstrip("\n") + ("\n" if old.strip() else "") + B + "\n" + "\n".join(lines) + "\n" + E + "\n")
    os.chmod(CHAP, 0o600)
    os.makedirs(os.path.dirname(UPSCRIPT), exist_ok=True)
    with open(UPSCRIPT, "w") as f:
        f.write("#!/bin/sh\ncase \"$PPP_IPPARAM\" in\n" + "\n".join(cases) + "\nesac\nexit 0\n")
    os.chmod(UPSCRIPT, 0o755)


def _run(cmd, timeout=20):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


def status(t):
    p = peer(t)
    r = _run(["ip", "-o", "-4", "addr", "show", "dev", p])
    m = re.search(r"inet (\S+) peer (\S+?)/", r.stdout or "")
    running = _run(["pgrep", "-f", f"call {p}$"]).returncode == 0 or _run(["pgrep", "-f", f"ifname {p}"]).returncode == 0
    return dict(up=bool(m), local=m.group(1).split("/")[0] if m else None, remote=m.group(2) if m else None,
                daemon=running)



_CONNECT_LOCK = threading.Lock()


def connect(t):
    # Serialize GUI and watchdog requests inside this application process.
    with _CONNECT_LOCK:
        if not available():
            raise RuntimeError("pptp-linux / ppp not installed (apt install ppp pptp-linux)")

        current = status(t)
        if current["up"]:
            return current
        if current["daemon"]:
            raise RuntimeError("PPTP connection is already starting; refusing duplicate pon.")

        _run(["modprobe", "ppp_generic"])
        _run(["modprobe", "ppp_mppe"])

        r = _run(["pon", peer(t), "noauth"])
        if r.returncode != 0:
            raise RuntimeError((r.stderr or r.stdout or "pon failed").strip()[:200])

        for _ in range(20):
            time.sleep(1)
            current = status(t)
            if current["up"]:
                return current

        current = status(t)
        if current["daemon"]:
            raise RuntimeError(
                "PPTP process started but tunnel has no IPv4 address yet. "
                "Check the tunnel log before retrying."
            )
        return current

def disconnect(t):
    _run(["poff", peer(t)])
    return status(t)


def log_tail(t, n=40):
    try:
        with open(f"/var/log/{peer(t)}.log", errors="ignore") as f:
            return "".join(f.readlines()[-n:])
    except OSError:
        return "(no log yet)"
