import json
import logging
import os
import re
import secrets
import time
from datetime import datetime, timedelta
from urllib.parse import urlparse

from fastapi import BackgroundTasks, Depends, FastAPI, File, Form, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from sqlalchemy import func
from starlette.concurrency import run_in_threadpool
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.sessions import SessionMiddleware

import cases
import core
import ctx
import diag
import mikrotik
import monitor
import olt as oltlib
import oui
import rusers
import snmp
import telegram_bot
from cases import adopt_router_user, notify_new, upsert_customer
from core import (CATEGORIES, ROLES, VENDORS, check_pw, flash, get_db, hash_pw, limited, render, required_role, templates)
from ctx import olt_dict, olt_dicts, profile_dict, router_dicts
from db import (OLT, STATUS_LABEL, Admin, Alarm, AuditLog, Complaint, Customer, OltProfile, Router, SessionLocal,
                apply_action, audit, get_or_create_secret_key, get_setting, init_db, seed_profiles, set_setting)
from util import looks_mac, norm_phone, parse_comment

log = logging.getLogger("portal")


class NeedLogin(Exception):
    pass


class Forbidden(Exception):
    pass


PUBLIC = {"/", "/login", "/admin/login", "/admin/logout", "/branding/logo", "/favicon.ico"}


def is_ajax(request: Request) -> bool:
    return (
        request.headers.get("x-requested-with") == "fetch"
        or "application/json" in (request.headers.get("accept") or "")
    )


class SecurityMiddleware(BaseHTTPMiddleware):
    """Commercial-grade HTTP security headers & same-origin CSRF protection."""
    async def dispatch(self, request: Request, call_next):
        if request.method in ("POST", "PUT", "DELETE", "PATCH"):
            origin = request.headers.get("origin") or request.headers.get("referer")
            host = request.headers.get("host")
            if origin and host:
                parsed = urlparse(origin)
                if parsed.netloc and parsed.netloc.lower() != host.lower():
                    return JSONResponse(dict(ok=False, error="Cross-origin request blocked (CSRF protection)"), status_code=403)
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "same-origin")
        response.headers.setdefault("X-XSS-Protection", "1; mode=block")
        if request.url.path.startswith("/admin"):
            response.headers.setdefault("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        return response


def guard(request: Request):
    """Global access control: every page needs a staff login; the role decides what may be done."""
    p = request.url.path
    if p in PUBLIC:
        return
    uid, user = request.session.get("uid"), None
    if uid:
        with SessionLocal() as db:
            a = db.get(Admin, uid)
            if a and a.active is not False:
                user = dict(id=a.id, username=a.username, role=a.role or "super", name=a.full_name or a.username)
    if not user:
        raise NeedLogin()
    request.state.user = user
    if ROLES.get(user["role"], 0) < ROLES[required_role(p, request.method)]:
        raise Forbidden()


init_db()
app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None, dependencies=[Depends(guard)])
app.add_middleware(SecurityMiddleware)
app.add_middleware(SessionMiddleware, secret_key=get_or_create_secret_key(),
                   same_site="strict", max_age=12 * 3600)
ADMIN = []


@app.exception_handler(NeedLogin)
def _need_login(request, exc):
    if request.url.path.startswith("/admin/api") or is_ajax(request):
        return JSONResponse(dict(ok=False, error="login required"), status_code=401)
    return RedirectResponse("/login", 303)


@app.exception_handler(Forbidden)
def _forbidden(request, exc):
    if request.url.path.startswith("/admin/api") or request.method != "GET" or is_ajax(request):
        return JSONResponse(dict(ok=False, error="Your role does not allow this action"), status_code=403)
    return render(request, "forbidden.html")


@app.on_event("startup")
def startup():
    init_db()
    with SessionLocal() as db:
        if not db.query(Admin).count():
            db.add(Admin(
                username=os.getenv("ADMIN_USER", "admin"),
                password_hash=hash_pw(os.getenv("ADMIN_PASS", "Amir@2647")),
                role="super",
                full_name="Super admin",
                active=True,
            ))
            db.commit()
        if not db.query(Admin).filter(Admin.role == "super", Admin.active.is_(True)).count():
            first_admin = db.query(Admin).order_by(Admin.id).first()
            if first_admin:
                first_admin.role = "super"
                first_admin.active = True
                db.commit()
    oui.background_init()
    rusers.start(ctx.all_routers_fresh)
    monitor.start()
    telegram_bot.start_poller()


# ================================================================ login / logout / branding
def _login_ctx(request):
    return dict(flash=request.session.pop("flash", []), site_title=get_setting("site_title", "Network Operations"),
                logo_url=core.logo_url())


@app.get("/")
def root():
    return RedirectResponse("/admin", 303)


@app.get("/login")
@app.get("/admin/login")
def login_page(request: Request):
    if request.session.get("uid"):
        return RedirectResponse("/admin", 303)
    return templates.TemplateResponse(request, "login.html", _login_ctx(request))


@app.post("/login")
@app.post("/admin/login")
def login(request: Request, username: str = Form(""), password: str = Form(""), db=Depends(get_db)):
    ip = request.client.host if request.client else "unknown"
    uname = username.strip().lower()
    if limited(f"l:{ip}", 10, 600) or (uname and limited(f"lu:{uname}", 8, 600)):
        flash(request, "Too many failed login attempts. Try again in a few minutes.", "err")
        return RedirectResponse("/login", 303)
    a = db.query(Admin).filter(func.lower(Admin.username) == uname).first()
    if a and a.active is not False and check_pw(password, a.password_hash):
        request.session.clear()
        request.session.update(uid=a.id, admin=a.username, role=a.role)
        a.last_login = datetime.utcnow()
        db.commit()
        audit(db, a.username, "login", "", ip)
        return RedirectResponse("/admin", 303)
    audit(db, uname or "unknown", "login_failed", "", ip)
    flash(request, "Wrong username or password, or the account is disabled.", "err")
    return RedirectResponse("/login", 303)


@app.get("/admin/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", 303)


@app.get("/branding/logo")
def branding_logo():
    path = os.path.join("data", "logo.bin")
    if not os.path.exists(path):
        return JSONResponse(dict(error="no logo"), status_code=404)
    return FileResponse(path, media_type=get_setting("logo_type", "image/png"),
                        headers={"Cache-Control": "public, max-age=86400",
                                 "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; sandbox"})


# ================================================================ admin: complaints / tickets
@app.get("/admin/tickets", dependencies=ADMIN)
@app.get("/admin/complaints", dependencies=ADMIN)
def admin_home(request: Request, status: str = "active", q: str = "", db=Depends(get_db)):
    qry = db.query(Complaint)
    if status == "active":
        qry = qry.filter(Complaint.status != "closed")
    elif status in STATUS_LABEL:
        qry = qry.filter(Complaint.status == status)
    since = datetime.utcnow() - timedelta(hours=24)
    stats = dict(
        active=db.query(Complaint).filter(Complaint.status != "closed").count(),
        today=db.query(Complaint).filter(Complaint.created_at >= since).count(),
        closed=db.query(Complaint).filter_by(status="closed").count(),
        online=sum(1 for u in rusers.all_users() if u.get("online")),
    )
    items = qry.order_by(Complaint.id.desc()).limit(200).all()
    if q.strip():
        ql = q.strip().lower()
        items = [
            x for x in items
            if ql in (x.customer.user_id or "").lower()
            or ql in (x.customer.name or "").lower()
            or ql in (x.customer.phone or "")
            or ql in (x.message or "").lower()
            or ql in (x.olt_name or "").lower()
        ]
    snaps = {}
    for x in items:
        try:
            snaps[x.id] = json.loads(x.diag_json or "{}").get("lines", [])
        except ValueError:
            snaps[x.id] = []
    return render(request, "admin_complaints.html", items=items, status=status, q=q, stats=stats, snaps=snaps)


@app.post("/admin/complaints/{cid}/act", dependencies=ADMIN)
def complaint_act(request: Request, cid: int, action: str = Form(...), message: str = Form(""),
                  db=Depends(get_db)):
    by = request.session["admin"]
    back = RedirectResponse(request.headers.get("referer") or "/admin/tickets", 303)
    if action not in ("wait", "reply", "close"):
        if is_ajax(request):
            return JSONResponse(dict(ok=False, error="Invalid action"), status_code=400)
        return back
    if action == "reply" and not message.strip():
        if is_ajax(request):
            return JSONResponse(dict(ok=False, error="Write a reply message first."), status_code=400)
        flash(request, "Write a reply message first.", "err")
        return back
    c = apply_action(db, cid, action, by, message)
    if not c:
        if is_ajax(request):
            return JSONResponse(dict(ok=False, error="Ticket not found or already closed."), status_code=404)
        flash(request, "Complaint not found or already closed.", "err")
        return back
    from html import escape
    txt = {
        "wait": f"⏳ #{cid} → Waiting for update (by {escape(by)})",
        "reply": f"💬 #{cid} reply by {escape(by)}:\n{escape(message.strip()[:500])}",
        "close": f"✅ #{cid} closed by {escape(by)}" + (f"\n📝 {escape(message.strip()[:300])}" if message.strip() else ""),
    }[action]
    try:
        telegram_bot.send(txt, reply_to=c.tg_message_id)
        if action == "close" and c.tg_message_id:
            telegram_bot._remove_buttons(get_setting("tg_chat_id"), c.tg_message_id)
    except Exception:
        pass
    if is_ajax(request):
        return JSONResponse(dict(ok=True, status=c.status, status_label=STATUS_LABEL.get(c.status, c.status),
                                 message=f"Ticket #{cid} updated ({action})."))
    flash(request, f"Ticket #{cid} updated.")
    return back


# ================================================================ admin: diagnose & live suggestions
@app.get("/admin/diagnose", dependencies=ADMIN)
def diagnose_search(request: Request, q: str = "", db=Depends(get_db)):
    q = q.strip()
    results = None
    if q:
        results = ctx.find(db, q)
        if len(results) == 1:
            r = results[0]
            return RedirectResponse(f"/admin/d?uid={r['uid']}&mac={r.get('mac', '')}", 303)
    recent = db.query(Complaint).filter(Complaint.status != "closed").order_by(Complaint.id.desc()).limit(8).all()
    all_u = rusers.all_users()
    active_samples = [u for u in all_u if u.get("online")][:12]
    return render(request, "admin_diagnose.html", q=q, results=results, recent=recent,
                  active_count=sum(1 for u in all_u if u.get("online")),
                  total_cached=len(all_u), active_samples=active_samples)


@app.get("/admin/api/suggest", dependencies=ADMIN)
async def admin_suggest(q: str = "", db=Depends(get_db)):
    q = q.strip()
    if len(q) < 1:
        return JSONResponse([])
    res = await run_in_threadpool(ctx.suggest, db, q, 12)
    return JSONResponse(res)


@app.get("/admin/d", dependencies=ADMIN)
def diag_page(request: Request, uid: str = "", mac: str = "", db=Depends(get_db)):
    cust = db.query(Customer).filter_by(user_id=uid).first() if uid else None
    return render(request, "admin_diag.html", uid=uid, mac=mac, cust=cust)


@app.get("/admin/api/diag", dependencies=ADMIN)
async def api_diag(uid: str = "", mac: str = ""):
    try:
        return JSONResponse(await run_in_threadpool(ctx.diagnose, uid, mac or None))
    except Exception as e:
        log.exception("diag failed")
        return JSONResponse(dict(error=str(e)), status_code=500)


@app.get("/admin/api/ping", dependencies=ADMIN)
async def api_ping(uid: str):
    return JSONResponse(await run_in_threadpool(lambda: mikrotik.ping(uid, ctx.all_routers_fresh())))


@app.get("/admin/api/live", dependencies=ADMIN)
async def api_live(uid: str):
    return JSONResponse(await run_in_threadpool(lambda: mikrotik.session_live(uid, ctx.all_routers_fresh())))


@app.post("/admin/api/disconnect", dependencies=ADMIN)
async def api_disconnect(request: Request, uid: str = Form(...)):
    res = await run_in_threadpool(lambda: mikrotik.disconnect(uid, ctx.all_routers_fresh()))
    with SessionLocal() as db:
        audit(db, request.session["admin"], "disconnect", uid, "ok" if res.get("ok") else res.get("error", ""))
    return JSONResponse(res)


@app.post("/admin/api/user-action", dependencies=ADMIN)
async def api_user_action(request: Request, db=Depends(get_db)):
    """In-place PPPoE & Customer modification directly from Diagnose page (no tab redirect)."""
    f = await request.form()
    uid = (f.get("uid") or "").strip()
    act = (f.get("action") or "").strip()
    rid = int(f.get("rid") or 0)
    if not uid:
        return JSONResponse(dict(ok=False, error="User ID is required"), status_code=400)

    if act == "notes":
        c = cases.adopt_router_user(db, uid)
        if not c:
            c = Customer(user_id=uid, token=secrets.token_hex(8), router_id=rid or None)
            db.add(c)
        c.name = (f.get("name") or "").strip()
        c.phone = norm_phone(f.get("phone") or "")
        c.address = (f.get("address") or "").strip()
        c.onu_mac = snmp.norm_mac(f.get("onu_mac") or "") or ""
        db.commit()
        # Also update router PPP secret comment if router is available
        r = next((x for x in router_dicts(db) if x["id"] == (rid or c.router_id)), None)
        if r and r.get("api_enabled") and (c.name or c.phone):
            comment = " ".join(x for x in (c.name, c.phone) if x)
            try:
                await run_in_threadpool(lambda: mikrotik.secret_set(r, uid, comment=comment))
            except Exception:
                pass
        rusers.refresh_async()
        audit(db, request.session["admin"], "user_notes", uid)
        return JSONResponse(dict(ok=True, message="Customer details & ONU MAC saved in-place."))

    routers = router_dicts(db, rid or None)
    r = next((x for x in routers if x["id"] == rid), None) if rid else (routers[0] if routers else None)
    if not r:
        return JSONResponse(dict(ok=False, error="Router not found"), status_code=404)

    try:
        if act == "password":
            pw = (f.get("password") or "").strip()
            if not pw:
                return JSONResponse(dict(ok=False, error="Password cannot be empty"), status_code=400)
            await run_in_threadpool(lambda: mikrotik.secret_set(r, uid, password=pw))
            msg = f"PPPoE password updated on {r['name']}."
        elif act == "profile":
            prof = (f.get("profile") or "").strip()
            if not prof:
                return JSONResponse(dict(ok=False, error="Select a profile"), status_code=400)
            await run_in_threadpool(lambda: mikrotik.secret_set(r, uid, profile=prof))
            msg = f"Profile changed to '{prof}' on {r['name']}."
        elif act in ("enable", "disable"):
            is_dis = (act == "disable")
            await run_in_threadpool(lambda: mikrotik.secret_set(r, uid, disabled="yes" if is_dis else "no"))
            if is_dis:
                await run_in_threadpool(lambda: mikrotik.disconnect(uid, [r]))
            msg = f"Account {'disabled & session disconnected' if is_dis else 'enabled'} on {r['name']}."
        else:
            return JSONResponse(dict(ok=False, error="Unknown action"), status_code=400)
        audit(db, request.session["admin"], f"user_{act}", uid, r["name"])
        rusers.refresh_async()
        return JSONResponse(dict(ok=True, message=msg))
    except Exception as e:
        return JSONResponse(dict(ok=False, error=f"Router refused: {e}"), status_code=400)


@app.post("/admin/diag/telegram", dependencies=ADMIN)
async def diag_to_telegram(request: Request, uid: str = Form(...), cid: int = Form(0)):
    """Post the full technical report (verdict + findings) to the Telegram group."""
    d = await run_in_threadpool(ctx.diagnose, uid, None)
    reply_to = None
    if cid:
        with SessionLocal() as db:
            c = db.get(Complaint, cid)
            reply_to = (c.tg_diag_message_id or c.tg_message_id) if c else None
    txt = f"🔎 <b>Diagnosis report · {util_escape(uid)}</b>\n" + "\n".join(util_escape(l) for l in d["report"])
    try:
        await run_in_threadpool(lambda: telegram_bot.send(txt, reply_to=reply_to))
        with SessionLocal() as db:
            audit(db, request.session["admin"], "tg_report", uid)
        return JSONResponse(dict(ok=True))
    except Exception as e:
        return JSONResponse(dict(ok=False, error=str(e)))


def util_escape(s):
    from html import escape
    return escape(str(s))


# ================================================================ admin: alarms & audit
@app.get("/admin/alarms", dependencies=ADMIN)
def alarms_page(request: Request, db=Depends(get_db)):
    active = db.query(Alarm).filter(Alarm.cleared_at.is_(None)).order_by(Alarm.id.desc()).all()
    hist = db.query(Alarm).filter(Alarm.cleared_at.isnot(None)).order_by(Alarm.id.desc()).limit(60).all()
    return render(request, "admin_alarms.html", active=active, hist=hist)


@app.post("/admin/alarms/{aid}/ack", dependencies=ADMIN)
def alarm_ack(request: Request, aid: int, db=Depends(get_db)):
    a = db.get(Alarm, aid)
    if a:
        a.ack_by = request.session["admin"]
        db.commit()
    if is_ajax(request):
        return JSONResponse(dict(ok=True, ack_by=request.session["admin"]))
    return RedirectResponse("/admin/alarms", 303)


@app.post("/admin/alarms/ack-all", dependencies=ADMIN)
def alarm_ack_all(request: Request, db=Depends(get_db)):
    by = request.session["admin"]
    n = 0
    for a in db.query(Alarm).filter(Alarm.cleared_at.is_(None), Alarm.ack_by == "").all():
        a.ack_by = by
        n += 1
    db.commit()
    if is_ajax(request):
        return JSONResponse(dict(ok=True, count=n, ack_by=by))
    flash(request, f"Acknowledged {n} active alarm(s).")
    return RedirectResponse("/admin/alarms", 303)


@app.get("/admin/audit", dependencies=ADMIN)
def audit_page(request: Request, db=Depends(get_db)):
    return render(request, "admin_audit.html", items=db.query(AuditLog).order_by(AuditLog.id.desc()).limit(200).all())


# ================================================================ Legacy /admin/users redirects to automated Diagnose
@app.get("/admin/api/profiles", dependencies=ADMIN)
async def api_profiles(router: int, db=Depends(get_db)):
    r = next((x for x in router_dicts(db) if x["id"] == router), None)
    if not r:
        return JSONResponse([])
    try:
        return JSONResponse(await run_in_threadpool(mikrotik.list_profiles, r))
    except Exception as e:
        return JSONResponse(dict(error=str(e)), status_code=500)


@app.get("/admin/customers", dependencies=ADMIN)
@app.get("/admin/users", dependencies=ADMIN)
@app.get("/admin/users/new", dependencies=ADMIN)
def users_redirect():
    return RedirectResponse("/admin/diagnose", 303)


@app.get("/admin/users/manage", dependencies=ADMIN)
def user_manage_redirect(uid: str = ""):
    return RedirectResponse(f"/admin/d?uid={uid}" if uid else "/admin/diagnose", 303)


# ================================================================ admin: devices (routers / OLTs / profiles) with In-Place APIs
def fld(name, label, value="", type="text", options=None, help=""):
    return dict(name=name, label=label, value=value if value is not None else "", type=type, options=options or [], help=help)


@app.get("/admin/devices", dependencies=ADMIN)
def devices_page(request: Request, db=Depends(get_db)):
    seed_profiles(db)
    profs = db.query(OltProfile).all()
    pn = {p.id: p.name for p in profs}
    pc = {p.id: sum(1 for c in profile_dict(p)["oids"].values() if c.get("oid")) for p in profs}
    prof_json = {
        p.id: dict(
            id=p.id,
            name=p.name,
            vendor=p.vendor,
            enterprise_oid=p.enterprise_oid or "",
            index_template=p.index_template or "{ifindex}",
            status_map=p.status_map or "",
            notes=p.notes or "",
            oids=profile_dict(p)["oids"],
        )
        for p in profs
    }
    return render(
        request,
        "admin_devices.html",
        routers=db.query(Router).all(),
        olts=db.query(OLT).all(),
        profiles=profs,
        pn=pn,
        pc=pc,
        fields=oltlib.FIELDS,
        prof_json=json.dumps(prof_json),
    )


def router_fields(r=None):
    r = r or Router(name="", host="", api_enabled=True, port=8728, username="", password="", use_ssl=False,
                    snmp_enabled=False, snmp_port=161, snmp_community="public")
    return [fld("name", "Name", r.name), fld("host", "IP / host", r.host),
            fld("api_enabled", "Enable API (user details, session, logs)", r.api_enabled is not False, "checkbox"),
            fld("port", "API port (8728 / 8729 SSL)", r.port, "number"), fld("use_ssl", "Use SSL (api-ssl)", r.use_ssl, "checkbox"),
            fld("username", "API user", r.username),
            fld("password", "API password", "", "password", help="Leave blank to keep the saved password" if r.id else ""),
            fld("snmp_enabled", "Enable SNMP (live interface rate, errors)", r.snmp_enabled, "checkbox"),
            fld("snmp_port", "SNMP port", r.snmp_port or 161, "number"),
            fld("snmp_community", "SNMP community", r.snmp_community or "public")]


@app.get("/admin/devices/router/new", dependencies=ADMIN)
def router_new(request: Request):
    return render(request, "admin_form.html", title="Add MikroTik router", fields=router_fields(), back="/admin/devices",
                  action="/admin/devices/router/new")


@app.get("/admin/devices/router/{rid}", dependencies=ADMIN)
def router_edit_page(request: Request, rid: int, db=Depends(get_db)):
    r = db.get(Router, rid)
    if not r:
        return RedirectResponse("/admin/devices", 303)
    return render(request, "admin_form.html", title=f"Edit router {r.name}", fields=router_fields(r),
                  back="/admin/devices", action=f"/admin/devices/router/{rid}")


async def _save_router(request, db, r):
    f = await request.form()
    r.name, r.host = f.get("name", "").strip(), f.get("host", "").strip()
    r.api_enabled, r.use_ssl, r.snmp_enabled = bool(f.get("api_enabled")), bool(f.get("use_ssl")), bool(f.get("snmp_enabled"))
    r.port, r.snmp_port = int(f.get("port") or 8728), int(f.get("snmp_port") or 161)
    r.username, r.snmp_community = f.get("username", "").strip(), f.get("snmp_community", "").strip() or "public"
    if f.get("password"):
        r.password = f["password"]
    db.add(r)
    db.commit()


@app.post("/admin/devices/router/new", dependencies=ADMIN)
async def router_create(request: Request, db=Depends(get_db)):
    r = Router(password="")
    await _save_router(request, db, r)
    rusers.refresh_async()
    monitor.discover_async()
    if is_ajax(request):
        return JSONResponse(dict(ok=True, id=r.id, message=f"Router '{r.name}' added."))
    flash(request, "Router added. Use Test API / Test SNMP to verify.")
    return RedirectResponse("/admin/devices", 303)


@app.post("/admin/devices/router/{rid}", dependencies=ADMIN)
async def router_update(request: Request, rid: int, db=Depends(get_db)):
    r = db.get(Router, rid)
    if r:
        await _save_router(request, db, r)
        rusers.refresh_async()
        monitor.discover_async([rid])
        if is_ajax(request):
            return JSONResponse(dict(ok=True, id=r.id, message=f"Router '{r.name}' updated."))
        flash(request, "Router saved.")
    return RedirectResponse("/admin/devices", 303)


@app.post("/admin/devices/router/{rid}/delete", dependencies=ADMIN)
def router_delete(request: Request, rid: int, db=Depends(get_db)):
    r = db.get(Router, rid)
    if r:
        db.query(Customer).filter_by(router_id=rid).update({"router_id": None})
        db.delete(r)
        db.commit()
        if is_ajax(request):
            return JSONResponse(dict(ok=True, message="Router removed."))
        flash(request, "Router removed.")
    return RedirectResponse("/admin/devices", 303)


@app.post("/admin/devices/router/{rid}/test", dependencies=ADMIN)
def router_test(request: Request, rid: int, db=Depends(get_db)):
    try:
        ident = mikrotik.test(router_dicts(db, rid)[0])
        msg = f"API connected ✅ Router identity: {ident}"
        if is_ajax(request):
            return JSONResponse(dict(ok=True, message=msg))
        flash(request, msg)
    except Exception as e:
        msg = f"API connection failed: {e}"
        if is_ajax(request):
            return JSONResponse(dict(ok=False, error=msg), status_code=400)
        flash(request, msg, "err")
    return RedirectResponse("/admin/devices", 303)


@app.post("/admin/devices/router/{rid}/snmp-test", dependencies=ADMIN)
def router_snmp_test(request: Request, rid: int, db=Depends(get_db)):
    try:
        r = mikrotik.snmp_test(router_dicts(db, rid)[0])
        msg = f"SNMP OK ✅ Name: {r['name']}, uptime: {r['uptime']}"
        if is_ajax(request):
            return JSONResponse(dict(ok=True, message=msg))
        flash(request, msg)
    except Exception as e:
        msg = f"SNMP failed: {e}"
        if is_ajax(request):
            return JSONResponse(dict(ok=False, error=msg), status_code=400)
        flash(request, msg, "err")
    return RedirectResponse("/admin/devices", 303)


@app.post("/admin/devices/router/{rid}/sync", dependencies=ADMIN)
def router_sync(request: Request, rid: int, overwrite: str = Form(""), db=Depends(get_db)):
    try:
        secs, acts = mikrotik.list_users(router_dicts(db, rid)[0])
    except Exception as e:
        if is_ajax(request):
            return JSONResponse(dict(ok=False, error=f"Sync failed: {e}"), status_code=400)
        flash(request, f"Sync failed: {e}", "err")
        return RedirectResponse("/admin/devices", 303)
    new = upd = 0
    for s in secs:
        uid = s.get("name")
        if not uid:
            continue
        name, phone = parse_comment(s.get("comment", ""))
        r = upsert_customer(db, uid, name or uid, phone, router_id=rid, overwrite=bool(overwrite))
        new += r == "new"
        upd += r == "updated"
    db.commit()
    rusers.refresh_async()
    monitor.discover_async([rid])
    msg = f"Sync done: {len(acts)} active sessions, {new} new & {upd} updated from {len(secs)} secrets."
    if is_ajax(request):
        return JSONResponse(dict(ok=True, message=msg))
    flash(request, msg)
    return RedirectResponse("/admin/devices", 303)


# ---- OLTs
def olt_fields(o, db):
    o = o or OLT(name="", vendor="BDCOM", host="", snmp_port=161, community="public", snmp_version="2c", vlans="",
                 enabled=True)
    profs = [(str(p.id), p.name) for p in db.query(OltProfile).all()]
    return [fld("name", "OLT name", o.name), fld("vendor", "Vendor", o.vendor, "select", [(v, v) for v in VENDORS]),
            fld("host", "OLT IP", o.host), fld("snmp_port", "SNMP port", o.snmp_port or 161, "number"),
            fld("community", "SNMP community (read)", o.community),
            fld("snmp_version", "SNMP version", o.snmp_version, "select", [("2c", "v2c"), ("1", "v1")]),
            fld("profile_id", "OID profile", str(o.profile_id or ""), "select", profs),
            fld("vlans", "PPPoE VLAN IDs (optional, comma separated)", o.vlans,
                help="Only needed if the OLT FDB lookup requires community@vlan"),
            fld("enabled", "Enabled", o.enabled is not False, "checkbox")]


async def _save_olt(request, db, o):
    f = await request.form()
    o.name, o.vendor, o.host = f.get("name", "").strip(), f.get("vendor", "BDCOM"), f.get("host", "").strip()
    o.snmp_port, o.community = int(f.get("snmp_port") or 161), f.get("community", "").strip() or "public"
    o.snmp_version = f.get("snmp_version", "2c")
    pid = int(f["profile_id"]) if f.get("profile_id") and str(f.get("profile_id")).isdigit() else None
    if not pid:
        # Auto-pick matching vendor OID profile
        v = (o.vendor or "").lower()
        for p in db.query(OltProfile).all():
            if (p.vendor or "").lower() == v:
                pid = p.id
                break
    o.profile_id = pid
    o.vlans, o.enabled = f.get("vlans", "").strip(), bool(f.get("enabled"))
    db.add(o)
    db.commit()


@app.get("/admin/devices/olt/new", dependencies=ADMIN)
def olt_new(request: Request, db=Depends(get_db)):
    return render(request, "admin_form.html", title="Add OLT", fields=olt_fields(None, db), back="/admin/devices",
                  action="/admin/devices/olt/new")


@app.post("/admin/devices/olt/new", dependencies=ADMIN)
async def olt_create(request: Request, db=Depends(get_db)):
    o = OLT()
    await _save_olt(request, db, o)
    if is_ajax(request):
        return JSONResponse(dict(ok=True, id=o.id, message=f"OLT '{o.name}' added with auto-matched OID profile."))
    flash(request, "OLT added and bound to OID profile.")
    return RedirectResponse("/admin/devices", 303)


@app.get("/admin/devices/olt/{oid}", dependencies=ADMIN)
def olt_edit_page(request: Request, oid: int, db=Depends(get_db)):
    o = db.get(OLT, oid)
    if not o:
        return RedirectResponse("/admin/devices", 303)
    return render(request, "admin_form.html", title=f"Edit OLT {o.name}", fields=olt_fields(o, db),
                  back="/admin/devices", action=f"/admin/devices/olt/{oid}")


@app.post("/admin/devices/olt/{oid}", dependencies=ADMIN)
async def olt_update(request: Request, oid: int, db=Depends(get_db)):
    o = db.get(OLT, oid)
    if o:
        await _save_olt(request, db, o)
        if is_ajax(request):
            return JSONResponse(dict(ok=True, id=o.id, message=f"OLT '{o.name}' saved."))
        flash(request, "OLT saved.")
    return RedirectResponse("/admin/devices", 303)


@app.post("/admin/devices/olt/{oid}/delete", dependencies=ADMIN)
def olt_delete(request: Request, oid: int, db=Depends(get_db)):
    o = db.get(OLT, oid)
    if o:
        db.delete(o)
        db.commit()
        if is_ajax(request):
            return JSONResponse(dict(ok=True, message="OLT removed."))
        flash(request, "OLT removed.")
    return RedirectResponse("/admin/devices", 303)


@app.post("/admin/devices/olt/{oid}/test", dependencies=ADMIN)
def olt_test(request: Request, oid: int, db=Depends(get_db)):
    profs = {p.id: p for p in db.query(OltProfile)}
    try:
        i = oltlib.sys_info(olt_dict(db.get(OLT, oid), profs))
        msg = f"SNMP OK ✅ {i['name']} | {i['descr']}"
        if is_ajax(request):
            return JSONResponse(dict(ok=True, message=msg))
        flash(request, msg)
    except Exception as e:
        msg = f"SNMP failed: {e}"
        if is_ajax(request):
            return JSONResponse(dict(ok=False, error=msg), status_code=400)
        flash(request, msg, "err")
    return RedirectResponse("/admin/devices", 303)


@app.get("/admin/devices/olt/{oid}/tools", dependencies=ADMIN)
def olt_tools(request: Request, oid: int, db=Depends(get_db)):
    o = db.get(OLT, oid)
    if not o:
        return RedirectResponse("/admin/devices", 303)
    return render(request, "admin_olt_tools.html", o=o, prof=db.get(OltProfile, o.profile_id), result=None,
                  fields=oltlib.FIELDS, form={})


def _tools_work(action, dev, prof, f):
    if action == "walk":
        rows = snmp.walk(dev, (f.get("oid_in") or "1.3.6.1.2.1.1").strip(), timeout=90)
        return dict(kind="walk", total=len(rows), rows=rows[:400])
    if action == "locate":
        m = snmp.norm_mac(f.get("mac", ""))
        if not m:
            raise ValueError("Enter a valid MAC address")
        return dict(kind="locate", data=oltlib.locate_one(dev, prof, m) or dict(found=False))
    if action == "discover":
        suf, name = (f.get("suffix") or "").strip(), None
        if not suf:
            m = snmp.norm_mac(f.get("mac", ""))
            if not m:
                raise ValueError("Enter a customer router MAC, or the ONU index suffix")
            suf, name = oltlib.resolve_suffix(dev, prof, m)
            if not suf:
                raise ValueError("MAC not found in the OLT MAC table (is that customer online?)")
        st = (f.get("start") or "").strip() or prof["enterprise_oid"] or "1.3.6.1.4.1"
        rows, total = oltlib.discover(dev, st, suf)
        known = {k[6:]: v for k, v in f.items() if k.startswith("known_") and str(v).strip()}
        best = oltlib.match_known(rows, known) if known else []
        return dict(kind="discover", rows=rows, total=total, suffix=suf, ifname=name, start=st, best=best)
    raise ValueError("Unknown action")


@app.post("/admin/devices/olt/{oid}/tools", dependencies=ADMIN)
async def olt_tools_run(request: Request, oid: int, db=Depends(get_db)):
    f = dict((await request.form()).items())
    o = db.get(OLT, oid)
    profs = {p.id: p for p in db.query(OltProfile)}
    dev = olt_dict(o, profs)
    try:
        result = await run_in_threadpool(_tools_work, f.get("action", ""), dev, dev["profile"], f)
    except Exception as e:
        flash(request, f"{f.get('action')} failed: {e}", "err")
        result = None
    return render(request, "admin_olt_tools.html", o=o, prof=db.get(OltProfile, o.profile_id), result=result,
                  fields=oltlib.FIELDS, form=f)


@app.post("/admin/devices/olt/{oid}/scan", dependencies=ADMIN)
async def olt_scan(request: Request, oid: int, db=Depends(get_db)):
    o = db.get(OLT, oid)
    dev = olt_dict(o, {p.id: p for p in db.query(OltProfile)})
    try:
        res = await run_in_threadpool(oltlib.scan, dev, dev["profile"])
    except Exception as e:
        flash(request, f"Scan failed: {e}", "err")
        return RedirectResponse(f"/admin/devices/olt/{oid}/tools", 303)
    return render(request, "admin_olt_scan.html", o=o, res=res)


@app.post("/admin/devices/profile/{pid}/assign-many", dependencies=ADMIN)
async def profile_assign_many(request: Request, pid: int, db=Depends(get_db)):
    f = await request.form()
    p = db.get(OltProfile, pid)
    if p:
        oids = profile_dict(p)["oids"]
        n = 0
        for fld_, col, div, unit in zip(f.getlist("field"), f.getlist("oid_col"), f.getlist("div"), f.getlist("unit")):
            if fld_ in dict(oltlib.FIELDS):
                oids[fld_] = dict(oid=col.strip("."), div=float(div or 1), unit=unit or "dbm")
                n += 1
        p.oids = json.dumps(oids)
        db.commit()
        flash(request, f"{n} OIDs saved to profile. Verify with Locate by MAC.")
    return RedirectResponse(f.get("back") if str(f.get("back", "")).startswith("/admin/") else "/admin/devices", 303)


# ---- profiles
@app.get("/admin/devices/profile/{pid}", dependencies=ADMIN)
def profile_page(request: Request, pid: int, db=Depends(get_db)):
    p = db.get(OltProfile, pid)
    if not p:
        return RedirectResponse("/admin/devices", 303)
    return render(request, "admin_profile.html", p=p, oids=profile_dict(p)["oids"], fields=oltlib.FIELDS)


@app.post("/admin/devices/profile/{pid}", dependencies=ADMIN)
async def profile_save(request: Request, pid: int, db=Depends(get_db)):
    p = db.get(OltProfile, pid)
    if not p:
        if is_ajax(request):
            return JSONResponse(dict(ok=False, error="Profile not found"), status_code=404)
        return RedirectResponse("/admin/devices", 303)
    f = await request.form()
    p.name, p.vendor = f.get("name", p.name).strip(), f.get("vendor", p.vendor)
    p.enterprise_oid, p.index_template = f.get("enterprise_oid", "").strip(), f.get("index_template", "").strip() or "{ifindex}"
    p.status_map, p.notes = f.get("status_map", "").strip(), f.get("notes", "")
    old_oids = profile_dict(p)["oids"]
    oids = {}
    for key, _ in oltlib.FIELDS:
        o = f.get(f"oid_{key}", "").strip().strip(".")
        if o:
            prev_alt = (old_oids.get(key) or {}).get("alt")
            entry = dict(oid=o, div=float(f.get(f"div_{key}") or 1), unit=f.get(f"unit_{key}") or "dbm",
                         conf=f.get(f"conf_{key}") or "", index=f.get(f"index_{key}") or "auto")
            if prev_alt:
                entry["alt"] = prev_alt
            oids[key] = entry
    p.oids = json.dumps(oids)
    db.commit()
    if is_ajax(request):
        return JSONResponse(dict(ok=True, count=len(oids), message=f"Profile '{p.name}' saved ({len(oids)} OIDs)."))
    flash(request, "Profile saved.")
    return RedirectResponse("/admin/devices", 303)


@app.post("/admin/devices/profile/{pid}/reset", dependencies=ADMIN)
def profile_reset(request: Request, pid: int, db=Depends(get_db)):
    """Restore/reload full master vendor OIDs for a profile."""
    seed_profiles(db, force_reset_id=pid)
    p = db.get(OltProfile, pid)
    cnt = sum(1 for c in profile_dict(p)["oids"].values() if c.get("oid")) if p else 0
    if is_ajax(request):
        return JSONResponse(dict(ok=True, count=cnt, message=f"Standard MIB OIDs loaded for '{p.name if p else ''}' ({cnt} fields)."))
    flash(request, f"Standard MIB OIDs restored ({cnt} fields).")
    return RedirectResponse("/admin/devices", 303)


@app.post("/admin/devices/profile/reset-all", dependencies=ADMIN)
def profile_reset_all(request: Request, db=Depends(get_db)):
    """Ensure all vendor OLT OID profiles are populated with accurate MIB OIDs."""
    for p in db.query(OltProfile).all():
        seed_profiles(db, force_reset_id=p.id)
    if is_ajax(request):
        return JSONResponse(dict(ok=True, message="All OLT OID profiles updated with full standard MIB definitions."))
    flash(request, "All OLT OID profiles updated with full standard MIB definitions.")
    return RedirectResponse("/admin/devices", 303)


@app.post("/admin/devices/profile/{pid}/assign", dependencies=ADMIN)
def profile_assign(request: Request, pid: int, field: str = Form(...), oid_col: str = Form(...),
                   div: float = Form(1), unit: str = Form("dbm"), back: str = Form("/admin/devices"),
                   db=Depends(get_db)):
    p = db.get(OltProfile, pid)
    if p and field in dict(oltlib.FIELDS):
        oids = profile_dict(p)["oids"]
        oids[field] = dict(oid=oid_col.strip("."), div=div or 1, unit=unit)
        p.oids = json.dumps(oids)
        db.commit()
        flash(request, f"Saved '{field}' → {oid_col}")
    return RedirectResponse(back if back.startswith("/admin/") else "/admin/devices", 303)


@app.post("/admin/devices/profile-new", dependencies=ADMIN)
def profile_new(request: Request, name: str = Form("New profile"), vendor: str = Form("BDCOM"), db=Depends(get_db)):
    p = OltProfile(name=name.strip() or "New profile", vendor=vendor or "Other", index_template="{ifindex}", oids="{}",
                   status_map="1=Online,2=Offline")
    db.add(p)
    db.commit()
    if is_ajax(request):
        return JSONResponse(dict(ok=True, id=p.id, message=f"Profile '{p.name}' created."))
    return RedirectResponse("/admin/devices", 303)


@app.post("/admin/devices/profile/{pid}/delete", dependencies=ADMIN)
def profile_delete(request: Request, pid: int, db=Depends(get_db)):
    p = db.get(OltProfile, pid)
    if p:
        db.query(OLT).filter_by(profile_id=pid).update({"profile_id": None})
        db.delete(p)
        db.commit()
        if is_ajax(request):
            return JSONResponse(dict(ok=True, message="Profile deleted."))
        flash(request, "Profile deleted.")
    return RedirectResponse("/admin/devices", 303)


@app.post("/admin/settings/monitor", dependencies=ADMIN)
async def set_monitor(request: Request):
    f = await request.form()
    for k in ("mon_interval", "mon_cpu_warn", "mon_cpu_crit", "mon_drop_pct", "mon_pon_drop_pct"):
        v = (f.get(k) or "").strip()
        if v.replace(".", "", 1).isdigit():
            set_setting(k, v)
    if is_ajax(request):
        return JSONResponse(dict(ok=True, message="Monitoring thresholds saved."))
    flash(request, "Monitoring thresholds saved.")
    return RedirectResponse("/admin/settings", 303)


@app.post("/admin/settings/oui", dependencies=ADMIN)
async def set_oui(request: Request, file: UploadFile = File(None)):
    try:
        if file is not None and file.filename:
            n = oui.save_upload(await file.read())
        else:
            n = oui.update()
        if is_ajax(request):
            return JSONResponse(dict(ok=True, message=f"OUI database loaded: {n} vendors."))
        flash(request, f"OUI database loaded: {n} vendors.")
    except Exception as e:
        if is_ajax(request):
            return JSONResponse(dict(ok=False, error=f"OUI update failed: {e}"), status_code=400)
        flash(request, f"OUI update failed: {e}", "err")
    return RedirectResponse("/admin/settings", 303)


@app.post("/admin/settings/telegram", dependencies=ADMIN)
def set_telegram(request: Request, action: str = Form("save"), token: str = Form(""), chat_id: str = Form("")):
    if action == "remove":
        set_setting("tg_token", "")
        set_setting("tg_chat_id", "")
        flash(request, "Telegram settings removed.")
    else:
        if token.strip():
            set_setting("tg_token", token.strip())
        if chat_id.strip():
            set_setting("tg_chat_id", chat_id.strip())
        if action == "test":
            try:
                telegram_bot.send("✅ Test message from the support portal.")
                flash(request, "Test message sent. Check your Telegram group.")
            except Exception as e:
                flash(request, f"Telegram error: {e}", "err")
        else:
            flash(request, "Telegram settings saved.")
    return RedirectResponse("/admin/settings", 303)


from r_admin import router as admin_router   # noqa: E402
from r_ops import router as ops_router       # noqa: E402

app.include_router(admin_router)
app.include_router(ops_router)
