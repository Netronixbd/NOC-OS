"""Collects MikroTik (API+SNMP) + OUI + OLT + ping data for one PPPoE user; derives hints, verdict, replies."""
import re
import time

import mikrotik
import olt
import oui
import snmp


def _fmt_dist(m):
    if m is None:
        return None
    try:
        v = float(m)
    except Exception:
        return str(m)
    if v >= 1000:
        return f"{int(v)} m ({v / 1000:.2f} km)"
    return f"{int(v) if v == int(v) else v} m ({v / 1000:.3f} km)"


def collect(uid, mac_hint, onu_mac, routers, olts, history=None, with_ping=True):
    mt = mikrotik.diagnose(uid, routers) if uid else dict(found=False)
    sn = None
    if mt.get("found"):
        r = next((x for x in routers if x.get("name") == mt.get("router")), None)
        if r and r.get("snmp_enabled") and mt.get("state") == "online":
            sn = mikrotik.snmp_ppp(r, uid)
    elif uid:   # SNMP-only routers
        for r in routers:
            if r.get("snmp_enabled") and not r.get("api_enabled", True):
                s = mikrotik.snmp_ppp(r, uid)
                if s.get("ok"):
                    sn, mt = s, dict(found=True, router=r.get("name"), router_id=r.get("id"), state="online", snmp_only=True)
                    break
    mac = snmp.norm_mac(mac_hint) if mac_hint else snmp.norm_mac(mt.get("mac"))
    device = oui.describe(mac)
    opt = olt.locate(olts, mac, onu_mac) if olts and (mac or onu_mac) else None
    if opt and opt.get("found"):
        om = (opt["fields"].get("mac") or {}).get("value") or opt.get("onu_mac")
        x = oui.describe(om) if om else None
        opt["onu_brand"] = (x or {}).get("short") or (x or {}).get("vendor") or opt.get("onu_brand")
        dist_val = (opt["fields"].get("distance") or {}).get("value")
        opt["distance_fmt"] = _fmt_dist(dist_val)
    ping = mikrotik.ping(uid, routers) if (with_ping and mt.get("found") and mt.get("state") == "online"
                                          and not mt.get("snmp_only")) else None
    l2 = dict(vlan=(opt or {}).get("vlan"), checked=(opt or {}).get("checked") or [], mikrotik=None)
    if mt.get("found") and mac and not mt.get("snmp_only"):
        r = next((x for x in routers if x.get("name") == mt.get("router")), None)
        if r:
            try:
                l2["mikrotik"] = mikrotik.l2_info(r, mac, l2["vlan"])
            except Exception as e:
                l2["mikrotik"] = dict(error=str(e)[:120])
    d = dict(
        uid=uid, mikrotik=mt, snmp=sn, device=device, optical=opt, ping=ping, l2=l2, mac=mac,
        ts=int(time.time()), olts_configured=bool(olts), history=history or {},
    )
    finalize(d)
    return d


def parse_rate(s):
    """MikroTik rate-limit 'rx/tx ...' -> (up_bps, down_bps) (rx = customer upload)."""
    if not s:
        return None, None

    def conv(x):
        m = re.fullmatch(r"(\d+(?:\.\d+)?)([kKmMgG]?)", x or "")
        return float(m[1]) * {"": 1, "k": 1e3, "m": 1e6, "g": 1e9}[m[2].lower()] if m else None
    a, _, b = str(s).split()[0].partition("/")
    return conv(a), conv(b or a)


def finalize(d):
    """(Re)compute everything derived from the collected data."""
    up, down = parse_rate((d["mikrotik"] or {}).get("rate_limit"))
    d["plan"] = dict(up_bps=up, down_bps=down)
    d["hints"] = hints(d)
    d["analysis"] = analyze(d)
    d["verdict"] = verdict(d)
    d["report"] = summary(d, True)
    return d


def hints(d):
    mt, opt, sn, pg = d["mikrotik"], d["optical"], d["snmp"], d.get("ping")
    H = []
    add = lambda lv, code, t: H.append(dict(level=lv, code=code, text=t))
    logs = " ".join((l.get("message") or "").lower() for l in mt.get("logs", []))
    if not mt.get("found"):
        add("err", "not_found", "User ID not found on any connected MikroTik CCR (check user ID spelling / router API settings).")
    else:
        st = mt.get("state")
        if mt.get("disabled"):
            add("err", "disabled", "PPPoE secret is DISABLED on the router (expired / billing block?). Enable it directly from Quick Actions.")
        for l in mt.get("lists", []):
            add("warn", "blocklist", f"Customer IP is in address-list '{l}' (possible block / expired list).")
        if st == "online":
            add("ok", "online", f"PPPoE session online{' (up ' + mt['uptime'] + ')' if mt.get('uptime') else ''} on {mt.get('router', 'CCR')}.")
            if mt.get("uptime_sec") is not None and mt["uptime_sec"] < 600:
                add("warn", "new_session", "Session is very new (<10 min): link may be flapping, check disconnect history/logs.")
        else:
            onu_down = opt and opt.get("found") and (
                opt.get("link") == "down" or (opt["fields"].get("status") or {}).get("online") is False)
            if onu_down:
                add("err", "onu_down", "ONU is OFFLINE on the OLT: likely fiber cut / ONU power off / LOS. Check ONU power and fiber.")
            elif opt and opt.get("found"):
                add("warn", "onu_up_ppp_down", "ONU is online on OLT but PPPoE is down: check customer router (PPPoE user/pass, WAN cable) and logs.")
            elif opt and not opt.get("found"):
                add("info", "onu_unknown", "ONU not found on any OLT by MAC (MAC may have aged out while offline). "
                                           "You can save the ONU MAC directly in Quick Actions on this page.")
            else:
                add("info", "no_olt", "No OLT lookup available, fiber side not verified.")
        if any(k in logs for k in ("authentication failed", "auth failed", "bad password")):
            add("err", "auth_fail", "Logs show PPPoE authentication failures: customer router has a wrong username/password.")
        if any(k in logs for k in ("not responding", "timeout", "lcp")):
            add("warn", "lcp", "Logs show LCP/keepalive timeouts: unstable line or ONU/router issue.")
        if mt.get("mac_users"):
            add("warn", "dup_mac", "The same router MAC is also logged in as: " + ", ".join(mt["mac_users"][:3]) +
                " (shared / cloned router or duplicate account).")
        if (mt.get("log_logins") or 0) >= 4:
            add("warn", "flap", f"Session was re-established {mt['log_logins']} times in the router log: the link is flapping.")
        i = mt.get("iface") or {}
        if any(int(i.get(k) or 0) > 0 for k in ("rx_error", "tx_error")):
            add("warn", "iface_err", "Interface errors present on the PPPoE interface (cable / ONU LAN port / router).")
        dr = (mt.get("queue") or {}).get("dropped")
        if dr and any((x or 0) > 0 for x in mikrotik._pair(dr)):
            add("info", "queue_drop", "Queue is dropping packets (speed limit reached / congestion).")
    if sn and sn.get("ok") and ((sn.get("in_errors") or 0) > 0 or (sn.get("out_errors") or 0) > 0):
        add("warn", "iface_err", "SNMP shows errors on the PPPoE interface.")
    if pg and pg.get("ok"):
        if pg["loss"] >= 20:
            add("err", "loss", f"Ping to customer router: {pg['loss']}% packet loss ({pg['received']}/{pg['sent']} replies).")
        elif pg["loss"] >= 5:
            add("warn", "loss", f"Ping to customer router: {pg['loss']}% packet loss.")
        if pg.get("avg") is not None and pg["avg"] > 20:
            add("warn", "latency", f"High latency to customer router: avg {pg['avg']} ms.")
        if pg.get("jitter") is not None and pg["jitter"] > 10:
            add("warn", "jitter", f"High jitter to customer router: {pg['jitter']} ms.")
        if pg["loss"] < 5 and (pg.get("avg") or 0) <= 20 and (pg.get("jitter") or 0) <= 10:
            add("ok", "ping_ok", f"Ping 20×100 ms clean: avg {pg.get('avg')} ms, jitter {pg.get('jitter')} ms, no loss.")
    dev = d.get("device")
    if dev and dev.get("local"):
        add("info", "local_mac", "Customer MAC is locally-administered (random/virtual); the brand shown may not be reliable.")
    if opt and opt.get("found"):
        f = opt["fields"]
        for key, label in (("rx", "ONU Rx"), ("olt_rx", "OLT Rx")):
            v = f.get(key) or {}
            q, val = v.get("quality"), v.get("value")
            if q == "bad":
                add("err", "rx_bad", f"{label} {val} dBm is below -27 dBm: critical weak signal (dirty connector, fiber bend, bad splice).")
            elif q == "weak":
                add("warn", "rx_weak", f"{label} {val} dBm is weak (-24 to -27 dBm): needs fiber attention soon.")
            elif q == "high":
                add("warn", "rx_high", f"{label} {val} dBm is too strong (> -8 dBm): may need an optical attenuator.")
        if (f.get("distance") or {}).get("value", 0) > 20000:
            add("warn", "far", "ONU distance is above 20 km.")
        if (f.get("temp") or {}).get("value") and f["temp"]["value"] > 70:
            add("warn", "temp", f"ONU temperature is high: {f['temp']['value']} °C.")
        uni, pd = (f.get("uni_speed") or {}).get("value"), (d.get("plan") or {}).get("down_bps")
        if uni and pd and uni * 1e6 < pd * 0.95:
            add("warn", "uni100", f"ONU LAN port negotiated {uni} Mbps but the plan is {pd / 1e6:.0f} Mbps: the router port or cable limits the speed.")
        if opt.get("multi"):
            add("warn", "mac_multi", "Router MAC was seen on several ONUs: " + ", ".join(opt["multi"]))
        ph = d.get("pon_health")
        if ph and ph["total"] >= 4 and ph["online"] / ph["total"] < 0.7:
            add("err", "pon_area", f"PON {ph['pon']} on {ph['olt']}: only {ph['online']}/{ph['total']} ONUs online: likely an area / fiber outage.")
        tr = d.get("trend")
        if tr and tr.get("delta") is not None and tr["delta"] <= -3:
            add("warn", "trend", f"ONU Rx is {abs(tr['delta'])} dB lower than usual (median of earlier checks {tr['median']} dBm).")
    n30 = (d.get("history") or {}).get("count30") or 0
    if n30 >= 2:
        add("warn", "repeat", f"Repeat complaint: {n30} other complaints in the last 30 days.")
    return H


def verdict(d):
    errs = [h for h in d["hints"] if h["level"] == "err"]
    warns = [h for h in d["hints"] if h["level"] == "warn"]
    if errs:
        t = f"❌ {len(errs)} problem(s) found" + (f", {len(warns)} warning(s)" if warns else "")
    elif warns:
        t = f"⚠️ {len(warns)} warning(s), no hard fault"
    else:
        t = "✅ No issue found: all checks passed"
    cause = ((d.get("analysis") or {}).get("cause") or {})
    return dict(ok=not errs and not warns, errors=len(errs), warnings=len(warns), text=t, cause=cause.get("title"))


def _bps(n):
    if n is None:
        return None
    return f"{n / 1e6:.2f} Mbps" if n >= 1e6 else f"{n / 1e3:.1f} Kbps"


def summary(d, full=False):
    """Plain-text lines for Telegram / ticket snapshot / copy-report."""
    mt, opt, dev, sn, pg = d["mikrotik"], d["optical"], d.get("device"), d.get("snmp"), d.get("ping")
    L = []
    if full and d.get("verdict"):
        L.append("🧾 " + d["verdict"]["text"])
        ca = (d.get("analysis") or {}).get("cause")
        if ca:
            L.append("🎯 Likely cause: " + ca["title"])
            if ca.get("steps"):
                L.append("👉 " + ca["steps"][0])
    if mt.get("found"):
        em = {"online": "🟢 Online", "offline": "🔴 Offline", "disabled": "⛔ Disabled"}.get(mt["state"], mt["state"])
        L.append(f"🌐 PPPoE: {em}" + (f" · {mt['ip']}" if mt.get("ip") else "") +
                 (f" · up {mt['uptime']}" if mt.get("uptime") else "") + (f" · {mt['router']}" if mt.get("router") else ""))
        t = (sn if sn and sn.get("ok") else mt.get("traffic")) or {}
        live = f" · ↓ {_bps(t['down_bps'])} ↑ {_bps(t['up_bps'])}" if t.get("down_bps") is not None else ""
        pool = mt.get("profile_pool") or mt.get("pool_by_ip")
        if mt.get("profile") or live or pool:
            L.append(f"⚡ Profile: {mt.get('profile') or '-'}" + (f" ({mt['rate_limit']})" if mt.get("rate_limit") else "")
                     + (f" · pool {pool}" if pool else "") + live)
        s = mt.get("session")
        if s and mt.get("state") == "online":
            L.append(f"📊 Session: ↓ {s['down_bytes'] / 1e6:.1f} MB · ↑ {s['up_bytes'] / 1e6:.1f} MB")
        if mt.get("state") != "online":
            if mt.get("last_disconnect_reason"):
                L.append(f"🔌 Last disconnect: {mt['last_disconnect_reason']}")
            if mt.get("last_logged_out"):
                L.append(f"🕒 Last logout: {mt['last_logged_out']}")
    else:
        L.append("❔ PPPoE: user not found on router / router unreachable")
    if dev:
        L.append(f"📟 Customer router: {dev.get('short') or dev.get('vendor') or 'Unknown brand'} · WAN MAC {dev['mac']}")
    if pg and pg.get("ok"):
        L.append(f"📡 Ping 20×100ms: loss {pg['loss']}% · avg {pg.get('avg')} ms · max {pg.get('max')} ms · jitter {pg.get('jitter')} ms")
    if opt and opt.get("found"):
        f = opt["fields"]
        fv = lambda k: (f.get(k) or {}).get("value")
        L.append(f"🛰 OLT: {opt['olt']} ({opt.get('vendor') or '-'}) · PON {opt.get('pon') or '?'} · ONU {opt.get('onu') or '?'}"
                 f" ({opt.get('ifname')}) · link {opt.get('link') or '?'}" + (f" · VLAN {opt['vlan']}" if opt.get("vlan") else "") +
                 (f" · {fv('status')}" if fv("status") else ""))
        brand = opt.get("onu_brand_full") or " / ".join(x for x in (fv("vendor"), fv("model")) if x) or opt.get("onu_brand")
        extra = []
        if fv("mac") or opt.get("onu_mac"):
            extra.append(f"ONU MAC {fv('mac') or opt.get('onu_mac')}")
        if brand or extra:
            L.append("🏷 ONU: " + (brand or "-") + (" · " + " · ".join(extra) if extra else ""))
        bits = []
        for k, lab in (("rx", "ONU Rx"), ("tx", "ONU Tx"), ("olt_rx", "OLT Rx")):
            v = f.get(k) or {}
            if v.get("value") is not None:
                q = {"good": " ✅", "weak": " ⚠️", "bad": " 🚨", "high": " ⚠️"}.get(v.get("quality"), "")
                bits.append(f"{lab} {v['value']} dBm{q}")
        if fv("distance") is not None:
            bits.append(f"Distance {opt.get('distance_fmt') or (str(fv('distance')) + ' m')}")
        for k, u in (("temp", " °C"), ("voltage", " V")):
            if fv(k) is not None:
                bits.append(f"{fv(k)}{u}")
        if fv("uni_speed") is not None:
            bits.append(f"LAN port {fv('uni_speed')} Mbps")
        if bits:
            L.append("📉 " + " · ".join(bits))
    elif opt is not None:
        L.append("🛰 OLT: ONU not found by MAC")
    n30 = (d.get("history") or {}).get("count30")
    if n30:
        L.append(f"📚 Previous complaints (30 days): {n30}")
    if full:
        q = mt.get("queue") or {}
        if q.get("max_limit"):
            L.append(f"🚦 Queue: {q['max_limit']} · drops {q.get('dropped')}")
        for l in (mt.get("logs") or [])[-3:]:
            L.append(f"📜 {l.get('time')} {(l.get('message') or '')[:110]}")
    icon = {"err": "🚨", "warn": "⚠️", "ok": "✅", "info": "ℹ️"}
    for h in d["hints"]:
        if full or h["level"] in ("err", "warn"):
            L.append(f"{icon[h['level']]} {h['text']}")
    return L


# ------------------------------------------------------------------ structured analysis (checklist + likely cause)
def analyze(d):
    mt, opt, pg, sn = d["mikrotik"], d["optical"], d.get("ping"), d.get("snmp")
    f = opt["fields"] if opt and opt.get("found") else {}
    fv = lambda k: (f.get(k) or {}).get("value")
    C = []

    def chk(cat, name, status, detail="", action=""):
        C.append(dict(cat=cat, name=name, status=status, detail=detail, action=action))
    online = mt.get("found") and mt.get("state") == "online"
    # ---- account
    if not mt.get("found"):
        chk("Account", "User exists on router", "fail", "Not found on any connected router",
            "Check the user ID spelling, the router API settings, or whether the account is on RADIUS only.")
    else:
        chk("Account", "User exists on router", "pass", mt.get("router", "") + (" · RADIUS" if mt.get("radius") else ""))
        chk("Account", "Account enabled", "fail" if mt.get("disabled") else "pass",
            "PPP secret is disabled" if mt.get("disabled") else "", "Enable it in Quick Actions on this page once payment is confirmed." if mt.get("disabled") else "")
        lists = mt.get("lists") or []
        chk("Account", "Not in a block list", "warn" if lists else "pass", ", ".join(lists),
            "Remove the IP from the block/expired address-list after payment." if lists else "")
    # ---- session
    if mt.get("found"):
        chk("Session", "PPPoE session", "pass" if online else "fail", f"online {mt.get('uptime') or ''}".strip() if online else "offline",
            "" if online else "See Line checks below to find out why the router does not connect.")
        if online:
            new = mt.get("uptime_sec") is not None and mt["uptime_sec"] < 600
            fl = (mt.get("log_logins") or 0) >= 4
            chk("Session", "Session stability", "warn" if (new or fl) else "pass",
                (f"{mt.get('log_logins')} logins in log" if fl else ("session < 10 min old" if new else "stable")),
                "Check power/cable of ONU and router; look at the disconnect reason." if (new or fl) else "")
        auth = any(k in " ".join((l.get("message") or "").lower() for l in mt.get("logs", [])) for k in ("authentication failed", "auth failed", "bad password"))
        chk("Session", "Authentication", "fail" if auth else "pass", "authentication failures in log" if auth else "",
            "Customer router has a wrong PPPoE username/password: correct it or reset the password in Quick Actions." if auth else "")
        chk("Session", "Duplicate login", "warn" if mt.get("mac_users") else "pass",
            ", ".join(mt.get("mac_users") or []), "Same router MAC used by another account: shared/cloned router or duplicate account." if mt.get("mac_users") else "")
        if mt.get("last_disconnect_reason") and not online:
            chk("Session", "Last disconnect reason", "warn", mt["last_disconnect_reason"])
    # ---- line / ONU
    if opt and opt.get("found"):
        chk("Line", "ONU located via CCR MAC correlation", "pass", f"{opt['olt']} · PON {opt.get('pon')} · {opt.get('ifname')}")
        down = opt.get("link") == "down" or (f.get("status") or {}).get("online") is False
        chk("Line", "ONU link", "fail" if down else "pass", opt.get("link") or "",
            "ONU is offline: check ONU power adapter and the fiber (LOS)." if down else "")
        for k, lab in (("rx", "ONU Rx power"), ("olt_rx", "OLT Rx power")):
            v = f.get(k)
            if v and v.get("value") is not None:
                q = v.get("quality")
                chk("Line", lab, {"good": "pass", "weak": "warn", "high": "warn", "bad": "fail"}.get(q, "pass"), f"{v['value']} dBm",
                    {"bad": "Very weak: clean/replace connector, check bends/splices.", "weak": "Weak: plan a fiber check.",
                     "high": "Too strong: add an attenuator."}.get(q, ""))
        if fv("tx") is not None:
            chk("Line", "ONU Tx power", "pass", f"{fv('tx')} dBm")
        if fv("distance") is not None:
            chk("Line", "ONU Distance", "warn" if fv("distance") > 20000 else "pass", opt.get("distance_fmt") or f"{fv('distance')} m")
        if fv("mac") or opt.get("onu_mac"):
            chk("Line", "ONU MAC & Brand", "pass", f"{fv('mac') or opt.get('onu_mac')} · {opt.get('onu_brand_full') or opt.get('onu_brand') or '-'}")
        if fv("temp") is not None:
            chk("Line", "ONU temperature", "warn" if fv("temp") > 70 else "pass", f"{fv('temp')} °C")
        if fv("uni_speed") is not None:
            pd = (d.get("plan") or {}).get("down_bps")
            lim = pd and fv("uni_speed") * 1e6 < pd * 0.95
            chk("Line", "ONU LAN port speed", "warn" if lim else "pass", f"{fv('uni_speed')} Mbps",
                "Port is slower than the plan: replace the LAN cable / use a Gigabit router port." if lim else "")
        ph = d.get("pon_health")
        if ph:
            ratio = ph["online"] / ph["total"] if ph["total"] else 1
            chk("Line", "Other ONUs on this PON", "fail" if (ph["total"] >= 4 and ratio < 0.7) else "pass",
                f"{ph['online']}/{ph['total']} online on PON {ph['pon']}",
                "Many ONUs are down on this PON: area/fiber outage, escalate to the field team." if (ph["total"] >= 4 and ratio < 0.7) else "")
        chk("Line", "MAC seen once", "warn" if opt.get("multi") else "pass", ", ".join(opt.get("multi") or []))
    elif opt is not None:
        chk("Line", "ONU located via MAC table", "warn", "Router MAC not found on any OLT",
            "MAC may have aged out while offline; save the ONU MAC in Quick Actions on this page.")
    else:
        chk("Line", "ONU located via MAC table", "na", "No OLT configured or no MAC known")
    # ---- L2
    l2 = d.get("l2") or {}
    if opt and opt.get("found"):
        chk("L2", "VLAN on OLT", "pass" if l2.get("vlan") else "na", str(l2.get("vlan") or "not exposed by this OLT"))
        mk = l2.get("mikrotik") or {}
        if mk.get("router") and l2.get("vlan"):
            ok = bool(mk.get("vlan_ifaces"))
            chk("L2", "VLAN interface on router", "pass" if ok else "warn", ", ".join(v["name"] for v in mk.get("vlan_ifaces", [])) or "no /interface vlan with this id",
                "" if ok else "The VLAN id seen on the OLT has no matching VLAN interface on the router.")
    # ---- performance
    if pg and pg.get("ok"):
        chk("Performance", "Packet loss", "fail" if pg["loss"] >= 20 else ("warn" if pg["loss"] >= 5 else "pass"), f"{pg['loss']}%",
            "Check LAN cable / Wi-Fi vs wired / ONU port." if pg["loss"] >= 5 else "")
        chk("Performance", "Latency", "warn" if (pg.get("avg") or 0) > 20 else "pass", f"avg {pg.get('avg')} ms")
        chk("Performance", "Jitter", "warn" if (pg.get("jitter") or 0) > 10 else "pass", f"{pg.get('jitter')} ms")
    i = mt.get("iface") or {}
    if i:
        er = int(i.get("rx_error") or 0) + int(i.get("tx_error") or 0)
        chk("Performance", "Interface errors", "warn" if er else "pass", str(er) if er else "",
            "Check cable / ONU LAN port." if er else "")
    dr = (mt.get("queue") or {}).get("dropped")
    if dr:
        dd = any((x or 0) > 0 for x in mikrotik._pair(dr))
        chk("Performance", "Queue drops", "warn" if dd else "pass", dr, "Speed limit reached or congestion." if dd else "")
    # ---- history
    tr = d.get("trend")
    if tr and tr.get("delta") is not None:
        chk("History", "Signal trend", "warn" if tr["delta"] <= -3 else "pass", f"{tr['delta']:+.1f} dB vs usual ({tr['median']} dBm)",
            "Signal is degrading: schedule a fiber inspection." if tr["delta"] <= -3 else "")
    n30 = (d.get("history") or {}).get("count30") or 0
    if n30:
        chk("History", "Repeat issues", "warn" if n30 >= 2 else "pass", f"{n30} tickets in 30 days",
            "Recurring problem: do a root-cause visit." if n30 >= 2 else "")
    score = 100
    for c in C:
        score -= {"fail": 18, "warn": 6}.get(c["status"], 0)
    return dict(checks=C, score=max(0, min(100, score)), cause=_cause(d, C, online))


def _cause(d, C, online):
    mt, opt = d["mikrotik"], d["optical"]
    f = opt["fields"] if opt and opt.get("found") else {}
    st = {(c["cat"], c["name"]): c["status"] for c in C}
    codes = {h["code"] for h in d["hints"] if h["level"] in ("err", "warn")}
    R = lambda t, conf, steps, esc=False: dict(title=t, confidence=conf, steps=steps, escalate=esc)
    if not mt.get("found"):
        return R("User not found on the routers", "high", ["Check the user ID spelling.", "Confirm the router API is reachable (Devices → Test API).", "If the user is on RADIUS they appear only while online."])
    if mt.get("disabled") or "blocklist" in codes:
        return R("Account disabled / restricted (billing or expiry)", "high", ["Confirm payment status.", "Enable the account in Quick Actions on this page or remove it from the block list.", "Disconnect the session so the customer re-logs in."])
    if "pon_area" in codes and not online:
        return R("PON / area outage", "high", ["Other ONUs on the same PON are down too.", "Do not visit the customer: check the splitter/feeder fiber.", "Escalate to the field team."], True)
    if not online:
        if opt and opt.get("found") and (opt.get("link") == "down" or (f.get("status") or {}).get("online") is False):
            return R("ONU is offline (power or fiber/LOS)", "high" if st.get(("Line", "ONU link")) == "fail" else "medium",
                     ["Ask the customer to check the ONU power adapter and LEDs.", "If LOS LED is red: check fiber connectors; if still down dispatch a technician.", "Check the PON: if several ONUs are down it is an area issue."], True)
        if "auth_fail" in codes:
            return R("Wrong PPPoE username / password on the customer router", "high", ["Correct the PPPoE credentials on the router or reset the secret password in Quick Actions.", "Disconnect session and confirm reconnect."])
        if opt and opt.get("found"):
            return R("ONU is up but PPPoE does not connect (customer router / WAN cable)", "medium", ["Ask the customer to power-cycle the router and check the ONU → router WAN cable.", "Verify PPPoE settings and VLAN on the router.", "If a different router works, the old router is faulty."])
        return R("Offline: fiber side could not be verified", "low", ["Save the ONU MAC in Quick Actions on this page so OLT lookup works while offline.", "Check the ONU LEDs with the customer."])
    if {"rx_bad", "rx_weak", "trend"} & codes:
        return R("Weak or degrading optical signal", "high" if "rx_bad" in codes else "medium", ["Inspect/clean connectors at ONU and splitter.", "Check fiber bends and splices.", "Compare Rx with other ONUs on the PON."], "rx_bad" in codes)
    if "uni100" in codes:
        return R("ONU LAN port / customer router limited to 100 Mbps", "high", ["Replace the LAN cable between ONU and router.", "Use a Gigabit WAN port on the customer router."])
    if {"loss", "latency", "jitter", "iface_err"} & codes:
        return R("Line quality problem (loss / latency / errors)", "medium", ["Test with a LAN cable instead of Wi-Fi.", "Check the ONU LAN port and cable.", "Compare optical levels; if fine suspect the customer router."])
    if {"flap", "lcp", "new_session"} & codes:
        return R("Unstable link (frequent reconnects)", "medium", ["Check ONU and router power adapters.", "Check the fiber connector and signal level.", "Look at the disconnect reasons in the log."])
    if "dup_mac" in codes:
        return R("Duplicate use of the same router / MAC", "medium", ["Confirm whether two accounts share one router.", "Disable the unauthorised account."])
    return R("No fault found on the ISP side", "high" if len(C) >= 8 else "medium",
             ["Line, session and signal are healthy.", "Likely customer-side: Wi-Fi interference, device or app problem.", "Ask the customer to test with a LAN cable and another device."])


# ------------------------------------------------------------------ customer-facing reply
BN = dict(
    hello="প্রিয় গ্রাহক{n},", bye="আপনার ধৈর্যের জন্য ধন্যবাদ।\n— সাপোর্ট টিম",
    ok=("আমরা আপনার লাইনটি পরীক্ষা করেছি। বর্তমানে আমাদের দিক থেকে কোনো সমস্যা পাওয়া যায়নি; আপনার সংযোগ সক্রিয় আছে এবং সিগন্যাল স্বাভাবিক। "
        "অনুগ্রহ করে আপনার রাউটার ও ডিভাইস একবার রিস্টার্ট করুন। ওয়াই-ফাইতে সমস্যা হলে রাউটারের কাছে গিয়ে বা LAN ক্যাবল দিয়ে পরীক্ষা করুন। "
        "এরপরও সমস্যা থাকলে আমাদের জানান, আমরা আবার দেখব।"),
    intro="আপনার লাইনটি পরীক্ষা করে নিচের বিষয়গুলো পাওয়া গেছে:",
    disabled="আপনার ইন্টারনেট সংযোগটি বর্তমানে বন্ধ আছে (বিল বা মেয়াদ সংক্রান্ত কারণে হতে পারে)। বিল পরিশোধ করে আমাদের জানালে সংযোগ দ্রুত চালু করে দেওয়া হবে।",
    blocklist="আপনার সংযোগটি বিল/মেয়াদ সংক্রান্ত কারণে সীমিত করা আছে বলে দেখা যাচ্ছে। অনুগ্রহ করে বিল পরিশোধ করে আমাদের জানান।",
    onu_down=("আপনার ফাইবার লাইনে সিগন্যাল পাওয়া যাচ্ছে না। অনুগ্রহ করে ONU/মডেমের পাওয়ার অ্যাডাপ্টার চালু আছে কিনা এবং ফাইবার ক্যাবলটি ঠিকমতো লাগানো আছে কিনা দেখুন। "
              "ঠিক থাকলে আমাদের টেকনিশিয়ান শীঘ্রই আপনার সাথে যোগাযোগ করবেন।"),
    onu_up_ppp_down=("আপনার ফাইবার লাইনের সিগন্যাল ঠিক আছে, তবে রাউটার থেকে ইন্টারনেট কানেক্ট হচ্ছে না। অনুগ্রহ করে রাউটার একবার বন্ধ করে চালু করুন "
                     "এবং ONU থেকে রাউটারের WAN পোর্টের ক্যাবলটি ঠিকমতো লাগানো আছে কিনা দেখুন।"),
    auth_fail=("আপনার রাউটারে ইউজারনেম বা পাসওয়ার্ড ভুল দেওয়া আছে বলে মনে হচ্ছে। অনুগ্রহ করে রাউটারের PPPoE সেটিং ঠিক করুন, প্রয়োজনে আমরা সঠিক তথ্য জানিয়ে দেব।"),
    rx_bad="আপনার ফাইবার লাইনের সিগন্যাল খুবই দুর্বল পাওয়া গেছে, যা ইন্টারনেট ধীর বা বারবার বিচ্ছিন্ন হওয়ার কারণ। আমাদের টেকনিশিয়ান লাইনটি পরীক্ষা করে ঠিক করে দেবেন।",
    rx_weak="আপনার ফাইবার লাইনের সিগন্যাল কিছুটা দুর্বল পাওয়া গেছে। আমরা বিষয়টি দেখছি এবং প্রয়োজনে টেকনিশিয়ান পাঠানো হবে।",
    lcp="আপনার সংযোগ মাঝে মাঝে বিচ্ছিন্ন হচ্ছে বলে দেখা যাচ্ছে। অনুগ্রহ করে ONU ও রাউটারের পাওয়ার এবং LAN ক্যাবলের প্লাগ ঠিকমতো লাগানো আছে কিনা দেখুন।",
    loss="আপনার লাইনে প্যাকেট লস বা ল্যাটেন্সি বেশি পাওয়া গেছে। ওয়াই-ফাইয়ের বদলে LAN ক্যাবল দিয়ে পরীক্ষা করে দেখুন এবং রাউটার রিস্টার্ট করুন। সমস্যা থাকলে আমরা লাইন আরও পরীক্ষা করব।",
    iface_err="আপনার লাইনের ক্যাবল বা ONU-এর LAN পোর্টে সমস্যা থাকতে পারে। অনুগ্রহ করে LAN ক্যাবলটি ঠিকমতো লাগানো আছে কিনা দেখুন।",
    not_found="আপনার ইউজার আইডিটি আমাদের সিস্টেমে খুঁজে পাওয়া যায়নি। অনুগ্রহ করে সঠিক ইউজার আইডি জানান।",
    followup="আমরা বিষয়টি দেখছি এবং খুব শীঘ্রই আপনাকে জানাব।",
    pon_area="আপনার এলাকার ফাইবার লাইনে একটি সমস্যা ধরা পড়েছে এবং আমাদের টিম এটি ঠিক করার কাজ করছে। অনুগ্রহ করে অপেক্ষা করুন, ঠিক হলে আপনাকে জানানো হবে।",
    uni100="আপনার রাউটারের WAN পোর্ট বা LAN ক্যাবল সম্ভবত 100 Mbps-এ চলছে, যা আপনার প্যাকেজের গতি সীমিত করছে। ভালো ক্যাবল ব্যবহার করুন এবং Gigabit পোর্টে লাগান।",
)
EN = dict(
    hello="Dear customer{n},", bye="Thank you for your patience.\n— Support Team",
    ok=("We have checked your line and found no problem on our side: your connection is active and the signal is normal. "
        "Please restart your router and devices. If Wi-Fi is slow, try closer to the router or with a LAN cable. "
        "If the problem continues, let us know and we will look again."),
    intro="We checked your line and found the following:",
    disabled="Your connection is currently disabled (possibly due to billing/expiry). Please pay the bill and let us know; we will reactivate it quickly.",
    blocklist="Your connection appears to be restricted for billing/expiry reasons. Please clear the bill and let us know.",
    onu_down=("We are not receiving a signal on your fiber line. Please check that the ONU/modem power adapter is on and the fiber cable is plugged in properly. "
              "If both are fine, our technician will contact you shortly."),
    onu_up_ppp_down=("Your fiber signal is fine, but your router is not connecting to the internet. Please power-cycle the router and check the cable from the ONU to the router WAN port."),
    auth_fail="Your router seems to have a wrong PPPoE username or password. Please correct the PPPoE settings; we can share the correct details if needed.",
    rx_bad="Your fiber signal is very weak, which causes slow speed or disconnections. Our technician will inspect and fix the line.",
    rx_weak="Your fiber signal is slightly weak. We are looking into it and will send a technician if needed.",
    lcp="Your connection seems to drop now and then. Please check the power and LAN cable plugs of your ONU and router.",
    loss="We noticed packet loss / high latency on your line. Please test with a LAN cable instead of Wi-Fi and restart the router. We will check further if it continues.",
    iface_err="There may be an issue with the cable or the ONU LAN port. Please make sure the LAN cable is plugged in firmly.",
    not_found="We could not find your user ID in our system. Please send the correct user ID.",
    followup="We are looking into it and will update you soon.",
    pon_area="We detected a fiber problem in your area and our team is working on it. Please wait; we will update you once it is fixed.",
    uni100="Your router WAN port or LAN cable seems to run at 100 Mbps, which limits your package speed. Please use a good cable and a Gigabit port.",
)
ORDER = ["not_found", "disabled", "blocklist", "pon_area", "onu_down", "auth_fail", "onu_up_ppp_down", "rx_bad", "rx_weak", "lcp",
         "loss", "latency", "jitter", "iface_err", "uni100"]
ALIAS = {"latency": "loss", "jitter": "loss"}


def customer_reply(d, lang="bn", name=""):
    T = BN if lang == "bn" else EN
    codes = {h["code"] for h in d["hints"] if h["level"] in ("err", "warn")}
    picked, seen = [], set()
    for c in ORDER:
        if c in codes:
            k = ALIAS.get(c, c)
            if k not in seen:
                seen.add(k)
                picked.append(T[k])
    n = f" {name}" if name else ""
    body = T["ok"] if not picked else (T["intro"] + "\n" + "\n".join(f"{i}. {m}" for i, m in enumerate(picked[:3], 1)))
    return T["hello"].format(n=n) + "\n\n" + body + "\n\n" + T["bye"]
