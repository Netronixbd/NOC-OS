import ipaddress
import re
import ssl
import time
from concurrent.futures import ThreadPoolExecutor

from librouteros import connect
from librouteros.query import Key

import snmp
import util


def _connect(r, timeout=7):
    kw = dict(host=r["host"], username=r["username"], password=r["password"], port=int(r["port"] or 8728), timeout=timeout)
    if r.get("use_ssl"):
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        kw["ssl_wrapper"] = ctx.wrap_socket
    return connect(**kw)


def _safe(fn, default=None):
    try:
        return fn()
    except Exception:
        return default


def _q(api, path, props, key, value):
    return list(api.path(*path).select(*[Key(p) for p in props]).where(Key(key) == value))


def _flag(v):
    return str(v).lower() in ("true", "yes", "1")


def parse_uptime(s):
    if not s:
        return None
    mult = dict(w=604800, d=86400, h=3600, m=60, s=1)
    return sum(int(n) * mult[u] for n, u in re.findall(r"(\d+)([wdhms])", str(s))) or 0


def test(r):
    api = _connect(r)
    try:
        return list(api.path("system", "identity"))[0]["name"]
    finally:
        api.close()


def fetch_secrets(r):
    api = _connect(r, timeout=12)
    try:
        return list(api.path("ppp", "secret"))
    finally:
        api.close()


def status(user_id, routers):
    """Light status check across routers."""
    answered = False
    for r in routers:
        if not r.get("api_enabled", True):
            continue
        try:
            api = _connect(r)
        except Exception:
            continue
        try:
            answered = True
            act = _q(api, ("ppp", "active"), ["name", "address", "uptime", "caller-id"], "name", user_id)
            if act:
                return {
                    "state": "online",
                    "ip": act[0].get("address", ""),
                    "uptime": act[0].get("uptime", ""),
                    "mac": act[0].get("caller-id", ""),
                    "router": r.get("name", ""),
                }
            sec = _q(api, ("ppp", "secret"), ["name", "disabled"], "name", user_id)
            if sec:
                return {"state": "disabled" if _flag(sec[0].get("disabled")) else "offline", "router": r.get("name", "")}
        except Exception:
            pass
        finally:
            try:
                api.close()
            except Exception:
                pass
    return {"state": "notfound" if answered else "unknown"}


def find_by_mac(mac, routers):
    norm = snmp.norm_mac(mac) or mac
    for r in routers:
        if not r.get("api_enabled", True):
            continue
        try:
            api = _connect(r)
        except Exception:
            continue
        try:
            a = _safe(lambda: _q(api, ("ppp", "active"), ["name", "caller-id"], "caller-id", norm), [])
            if not a and norm != mac:
                a = _safe(lambda: _q(api, ("ppp", "active"), ["name", "caller-id"], "caller-id", mac), [])
            if not a:
                # Case-insensitive fallback scan on active caller-ids
                for row in _safe(lambda: list(api.path("ppp", "active").select(Key("name"), Key("caller-id"))), []):
                    if snmp.norm_mac(row.get("caller-id")) == norm:
                        return row.get("name")
            if a:
                return a[0]["name"]
            # Also check last-caller-id in ppp/secret if offline
            for row in _safe(lambda: list(api.path("ppp", "secret").select(Key("name"), Key("last-caller-id"), Key("caller-id"))), []):
                if snmp.norm_mac(row.get("last-caller-id")) == norm or snmp.norm_mac(row.get("caller-id")) == norm:
                    return row.get("name")
        except Exception:
            pass
        finally:
            try:
                api.close()
            except Exception:
                pass
    return None


SEC = ["name", "service", "profile", "disabled", "comment", "last-logged-out", "last-caller-id",
       "last-disconnect-reason", "caller-id", "remote-address", "local-address"]
ACT = ["name", "address", "caller-id", "uptime", "service", "encoding", "session-id", "comment"]


def _pool_by_ip(api, ip):
    """Name of the /ip pool whose ranges contain the IP (works for RADIUS users too)."""
    if not ip:
        return None
    try:
        a = ipaddress.ip_address(ip)
        for p in api.path("ip", "pool"):
            for rg in str(p.get("ranges", "")).split(","):
                rg = rg.strip()
                if not rg:
                    continue
                if "-" in rg:
                    lo, hi = rg.split("-", 1)
                    if ipaddress.ip_address(lo.strip()) <= a <= ipaddress.ip_address(hi.strip()):
                        return p.get("name")
                elif "/" in rg:
                    if a in ipaddress.ip_network(rg, strict=False):
                        return p.get("name")
                elif a == ipaddress.ip_address(rg):
                    return p.get("name")
    except Exception:
        return None
    return None


def _pair(s):
    try:
        a, b = str(s).split("/")[:2]
        return int(a), int(b)
    except Exception:
        return None, None


def diagnose(uid, routers):
    """Everything useful for troubleshooting one PPPoE user, via RouterOS API."""
    errs = []
    for r in routers:
        if not r.get("api_enabled", True):
            continue
        try:
            api = _connect(r)
        except Exception as e:
            errs.append(f"{r.get('name')}: {e}")
            continue
        try:
            sec = _safe(lambda: _q(api, ("ppp", "secret"), SEC, "name", uid), [])
            act = _safe(lambda: _q(api, ("ppp", "active"), ACT, "name", uid), [])
            # Case-insensitive fallback if exact match didn't trigger
            if not sec and not act and uid:
                ul = uid.lower()
                act = [x for x in _safe(lambda: list(api.path("ppp", "active").select(*[Key(k) for k in ACT])), [])
                       if (x.get("name") or "").lower() == ul]
                sec = [x for x in _safe(lambda: list(api.path("ppp", "secret").select(*[Key(k) for k in SEC])), [])
                       if (x.get("name") or "").lower() == ul]
                if act:
                    uid = act[0].get("name") or uid
                elif sec:
                    uid = sec[0].get("name") or uid
            if not sec and not act:
                continue
            s, a = (sec[0] if sec else {}), (act[0] if act else None)
            ifname = f"<pppoe-{uid}>"
            prof_name = s.get("profile")
            prof = _safe(lambda: _q(api, ("ppp", "profile"), ["name", "rate-limit", "local-address", "remote-address",
                                                              "parent-queue"], "name", prof_name), []) if prof_name else []
            all_profiles = _safe(lambda: [p.get("name") for p in api.path("ppp", "profile") if p.get("name")], [])
            pool_ip = _pool_by_ip(api, (a or {}).get("address")) if a else None
            iface = _safe(lambda: _q(api, ("interface",), ["name", "running", "rx-byte", "tx-byte", "rx-error",
                                                           "tx-error", "rx-drop", "tx-drop", "link-downs"],
                                     "name", ifname), []) if a else []
            queue = _safe(lambda: _q(api, ("queue", "simple"), ["name", "max-limit", "rate", "bytes", "dropped"],
                                     "name", ifname), []) if a else []
            traffic = _safe(lambda: list(api.rawCmd("/interface/monitor-traffic", f"=interface={ifname}",
                                                    "=once=")), []) if a else []
            lists = _safe(lambda: _q(api, ("ip", "firewall", "address-list"), ["list", "address"], "address",
                                     a["address"]), []) if a and a.get("address") else []
            logs = _safe(lambda: [l for l in list(api.path("log"))[-600:] if uid.lower() in (l.get("message") or "").lower()], [])
            mac = (a or {}).get("caller-id") or s.get("last-caller-id") or s.get("caller-id")
            mac_users = [x["name"] for x in _safe(lambda: _q(api, ("ppp", "active"), ["name"], "caller-id", mac), [])
                         if x.get("name") != uid] if mac else []
            lm = [(l.get("message") or "").lower() for l in logs]
            q = queue[0] if queue else {}
            up_r, down_r = _pair(q.get("rate"))
            t = traffic[0] if traffic else {}
            i = iface[0] if iface else {}
            state = "online" if a else ("disabled" if _flag(s.get("disabled")) else "offline")
            return dict(
                found=True,
                router=r.get("name"),
                router_id=r.get("id"),
                state=state,
                ip=(a or {}).get("address") or s.get("remote-address"),
                uptime=(a or {}).get("uptime"),
                uptime_sec=parse_uptime((a or {}).get("uptime")),
                mac=mac,
                mac_source="active session (CCR caller-id)" if a and a.get("caller-id") else "last known (PPP secret)",
                profile=s.get("profile") or ("RADIUS" if a and not s else None),
                available_profiles=all_profiles,
                rate_limit=(prof[0].get("rate-limit") if prof else None),
                profile_pool=(prof[0].get("remote-address") if prof else None) or s.get("remote-address"),
                profile_local=(prof[0].get("local-address") if prof else None) or s.get("local-address"),
                parent_queue=(prof[0].get("parent-queue") if prof else None),
                pool_by_ip=pool_ip,
                radius=bool(a and not s),
                has_secret=bool(s),
                session=dict(down_bytes=int(i.get("tx-byte") or 0), up_bytes=int(i.get("rx-byte") or 0)) if i else None,
                service=(a or s).get("service"),
                comment=s.get("comment") or (a or {}).get("comment"),
                disabled=_flag(s.get("disabled")),
                last_logged_out=s.get("last-logged-out"),
                last_disconnect_reason=s.get("last-disconnect-reason"),
                queue=dict(max_limit=q.get("max-limit"), rate_up=up_r, rate_down=down_r, dropped=q.get("dropped"),
                           bytes=q.get("bytes")) if q else None,
                iface=dict(running=_flag(i.get("running")), rx_error=i.get("rx-error"), tx_error=i.get("tx-error"),
                           rx_drop=i.get("rx-drop"), tx_drop=i.get("tx-drop"), link_downs=i.get("link-downs"),
                           rx_byte=i.get("rx-byte"), tx_byte=i.get("tx-byte")) if i else None,
                traffic=dict(down_bps=int(t["tx-bits-per-second"]), up_bps=int(t["rx-bits-per-second"]))
                if t.get("tx-bits-per-second") is not None else None,
                lists=[x.get("list") for x in lists],
                mac_users=mac_users,
                log_logins=sum("logged in" in m for m in lm),
                log_logouts=sum("logged out" in m for m in lm),
                logs=[dict(time=l.get("time"), message=l.get("message")) for l in logs[-15:]],
            )
        finally:
            try:
                api.close()
            except Exception:
                pass
    return dict(found=False, errors=errs)


def _ms(s):
    m = re.fullmatch(r"(?:(\d+)ms)?(?:(\d+)us)?", str(s or ""))
    if not m or not (m[1] or m[2]):
        try:
            return float(str(s).replace("ms", "").strip())
        except Exception:
            return None
    return int(m[1] or 0) + int(m[2] or 0) / 1000


def ping(uid, routers, count=20, interval="100ms", size=None, df=False):
    """Ping the customer's PPPoE address from the router. Returns per-packet RTTs + stats."""
    for r in routers:
        if not r.get("api_enabled", True):
            continue
        try:
            api = _connect(r)
        except Exception:
            continue
        try:
            a = _q(api, ("ppp", "active"), ["address"], "name", uid)
            if not a:
                continue
            ip = a[0]["address"]
            words = [f"=address={ip}", f"=count={count}", f"=interval={interval}"]
            if size:
                words.append(f"=size={int(size)}")
            if df:
                words.append("=do-not-fragment=yes")
            rows = list(api.rawCmd("/ping", *words))
            times = [None] * count
            for k, row in enumerate(rows[:count]):
                try:
                    seq = int(row.get("seq", k))
                except Exception:
                    seq = k
                if 0 <= seq < count:
                    times[seq] = _ms(row.get("time"))
            got = [t for t in times if t is not None]
            jit = [abs(got[k] - got[k - 1]) for k in range(1, len(got))]
            return dict(
                ok=True, ip=ip, sent=count, received=len(got), loss=round(100 * (count - len(got)) / count),
                min=min(got) if got else None, avg=round(sum(got) / len(got), 2) if got else None,
                max=max(got) if got else None, jitter=round(sum(jit) / len(jit), 2) if jit else None,
                times=times, interval=interval, size=size, df=df,
            )
        except Exception as e:
            return dict(ok=False, error=str(e))
        finally:
            try:
                api.close()
            except Exception:
                pass
    return dict(ok=False, error="User is not online on any router")


def session_live(uid, routers):
    """Fast counters for the live graph (rate is computed from deltas by the browser)."""
    for r in routers:
        if not r.get("api_enabled", True):
            continue
        try:
            api = _connect(r)
        except Exception:
            continue
        try:
            a = _q(api, ("ppp", "active"), ["address", "uptime"], "name", uid)
            if not a:
                continue
            i = _safe(lambda: _q(api, ("interface",), ["rx-byte", "tx-byte"], "name", f"<pppoe-{uid}>"), [])
            if not i:
                continue
            return dict(
                found=True, router=r.get("name"), ip=a[0].get("address"), uptime=a[0].get("uptime"),
                down_bytes=int(i[0].get("tx-byte") or 0), up_bytes=int(i[0].get("rx-byte") or 0),
                ts=time.time(),
            )
        except Exception as e:
            return dict(found=False, error=str(e))
        finally:
            try:
                api.close()
            except Exception:
                pass
    return dict(found=False)


def disconnect(uid, routers):
    """Remove the active PPP session so the customer router redials."""
    for r in routers:
        if not r.get("api_enabled", True):
            continue
        try:
            api = _connect(r)
        except Exception:
            continue
        try:
            a = list(api.path("ppp", "active").select(Key(".id"), Key("name")).where(Key("name") == uid))
            if a:
                api.path("ppp", "active").remove(a[0][".id"])
                return dict(ok=True, router=r.get("name"))
        except Exception as e:
            return dict(ok=False, error=str(e))
        finally:
            try:
                api.close()
            except Exception:
                pass
    return dict(ok=False, error="No active session found for this user")


def l2_info(r, mac, vlan):
    """MikroTik side of the L2 path: VLAN interfaces, PPPoE servers, bridge host entry."""
    api = _connect(r)
    try:
        all_vlans = _safe(lambda: [dict(name=x.get("name"), parent=x.get("interface"), vid=x.get("vlan-id"))
                                   for x in api.path("interface", "vlan")], [])
        vlans = [v for v in all_vlans if vlan and str(v.get("vid")) == str(vlan)] if vlan else []
        servers = _safe(lambda: [dict(service=x.get("service-name"), interface=x.get("interface"),
                                      disabled=_flag(x.get("disabled")))
                                 for x in api.path("interface", "pppoe-server", "server")], [])
        names = {v["name"] for v in vlans}
        matched = [s_ for s_ in servers if s_["interface"] in names] if names else []
        host = _safe(lambda: [dict(interface=x.get("on-interface"), vid=x.get("vid"), bridge=x.get("bridge"))
                              for x in _q(api, ("interface", "bridge", "host"),
                                          ["mac-address", "on-interface", "vid", "bridge"], "mac-address", mac)], []) if mac else []
        return dict(router=r.get("name"), vlan_ifaces=vlans, all_vlans=all_vlans[:30],
                    servers=matched or servers, servers_matched=bool(matched), bridge_host=host)
    finally:
        try:
            api.close()
        except Exception:
            pass


def system_stats(r):
    """Router health for the dashboard: CPU, memory, uptime, version, active PPPoE users."""
    out = dict(ok=False, error="", cpu=None, mem_pct=None, uptime=None, version=None, board=None, identity=None,
               active=None, via=None)
    if r.get("api_enabled", True):
        try:
            api = _connect(r)
        except Exception as e:
            out["error"] = str(e)[:150]
            api = None
        if api:
            try:
                res = list(api.path("system", "resource"))[0]
                out.update(ok=True, via="api", cpu=int(res.get("cpu-load", 0)), uptime=res.get("uptime"),
                           version=res.get("version"), board=res.get("board-name"))
                tm, fm = int(res.get("total-memory", 0)), int(res.get("free-memory", 0))
                out["mem_pct"] = round(100 * (tm - fm) / tm) if tm else None
                out["identity"] = _safe(lambda: list(api.path("system", "identity"))[0]["name"])
                cnt = _safe(lambda: list(api.rawCmd("/ppp/active/print", "=count-only=")), [])
                n = next((int(x["ret"]) for x in cnt if isinstance(x, dict) and str(x.get("ret", "")).isdigit()), None)
                if n is None:
                    n = len(_safe(lambda: list(api.path("ppp", "active").select(Key("name"))), []))
                out["active"] = n
                return out
            except Exception as e:
                out["error"] = str(e)[:150]
            finally:
                try:
                    api.close()
                except Exception:
                    pass
    if r.get("snmp_enabled"):
        try:
            d = snmp_dev(r)
            g = snmp.get(d, ["1.3.6.1.2.1.1.5.0", "1.3.6.1.2.1.1.3.0"])
            loads = [snmp.num(v) for _, _, v in snmp.walk(d, "1.3.6.1.2.1.25.3.3.1.2", timeout=15)]
            loads = [x for x in loads if x is not None]
            ticks = snmp.num((g.get("1.3.6.1.2.1.1.3.0") or (0, ""))[1])
            out.update(ok=True, via="snmp", error="", identity=(g.get("1.3.6.1.2.1.1.5.0") or (0, ""))[1],
                       cpu=round(sum(loads) / len(loads)) if loads else None,
                       uptime=f"{int(ticks / 8640000)}d" if ticks else None)
        except Exception as e:
            out["error"] = (out["error"] + " | " if out["error"] else "") + str(e)[:100]
    return out


# ------------------------------------------------------------------ PPPoE user management (needs write permission)
def list_profiles(r):
    api = _connect(r)
    try:
        return [p["name"] for p in api.path("ppp", "profile") if p.get("name")]
    finally:
        api.close()


def secret_get(r, name):
    api = _connect(r)
    try:
        s = _q(api, ("ppp", "secret"), ["name", "service", "profile", "disabled", "comment", "remote-address",
                                         "last-logged-out", "last-caller-id"], "name", name)
        return s[0] if s else None
    finally:
        api.close()


def create_secret(r, name, password, profile, comment="", service="pppoe"):
    api = _connect(r)
    try:
        if _q(api, ("ppp", "secret"), ["name"], "name", name):
            raise ValueError("A PPP secret with this name already exists on the router")
        api.path("ppp", "secret").add(name=name, password=password, profile=profile, service=service, comment=comment)
    finally:
        api.close()


def secret_set(r, name, **kw):
    api = _connect(r)
    try:
        s = list(api.path("ppp", "secret").select(Key(".id")).where(Key("name") == name))
        if not s:
            raise ValueError("Secret not found on this router")
        api.path("ppp", "secret").update(**{".id": s[0][".id"], **kw})
    finally:
        api.close()


def secret_remove(r, name):
    api = _connect(r)
    try:
        s = list(api.path("ppp", "secret").select(Key(".id")).where(Key("name") == name))
        if not s:
            raise ValueError("Secret not found on this router")
        api.path("ppp", "secret").remove(s[0][".id"])
    finally:
        api.close()


# ------------------------------------------------------------------ SNMP side of the router
def snmp_dev(r):
    return dict(host=r["host"], port=r.get("snmp_port") or 161, community=r.get("snmp_community") or "public",
                version="2c")


def snmp_test(r):
    g = snmp.get(snmp_dev(r), ["1.3.6.1.2.1.1.5.0", "1.3.6.1.2.1.1.3.0"])
    return dict(name=(g.get("1.3.6.1.2.1.1.5.0") or (0, "?"))[1], uptime=(g.get("1.3.6.1.2.1.1.3.0") or (0, "?"))[1])


_ifcache = {}


def _ifindex(dev, host, name):
    c = _ifcache.get(host)
    if c and name in c[1]:
        return c[1][name]
    if c and time.time() - c[0] < 20:
        return None
    m = {}
    for o, _, v in snmp.walk(dev, "1.3.6.1.2.1.31.1.1.1.1", timeout=60):
        m[v] = o.rsplit(".", 1)[1]
    _ifcache[host] = (time.time(), m)
    return m.get(name)


def snmp_ppp(r, uid):
    """PPPoE interface counters + live rate over SNMP (needs the user online)."""
    dev = snmp_dev(r)
    try:
        ix = _ifindex(dev, r["host"], f"<pppoe-{uid}>")
        if not ix:
            return dict(ok=False, error="PPPoE interface not found over SNMP (user offline?)")
        ino, outo = f"1.3.6.1.2.1.31.1.1.1.6.{ix}", f"1.3.6.1.2.1.31.1.1.1.10.{ix}"
        a = snmp.get(dev, [ino, outo, f"1.3.6.1.2.1.2.2.1.8.{ix}", f"1.3.6.1.2.1.2.2.1.14.{ix}",
                           f"1.3.6.1.2.1.2.2.1.20.{ix}", f"1.3.6.1.2.1.2.2.1.13.{ix}", f"1.3.6.1.2.1.2.2.1.19.{ix}"])
        t0 = time.time()
        time.sleep(1.2)
        b = snmp.get(dev, [ino, outo])
        dt = time.time() - t0
        n = lambda d, k: snmp.num((d.get(k) or (0, ""))[1])
        di, do = (n(b, ino) or 0) - (n(a, ino) or 0), (n(b, outo) or 0) - (n(a, outo) or 0)
        pick = lambda base: n(a, f"{base}.{ix}")
        return dict(
            ok=True, router=r.get("name"), down_bps=max(do, 0) * 8 / dt, up_bps=max(di, 0) * 8 / dt,
            oper={1: "up", 2: "down"}.get(int(pick("1.3.6.1.2.1.2.2.1.8") or 0)),
            in_errors=pick("1.3.6.1.2.1.2.2.1.14"), out_errors=pick("1.3.6.1.2.1.2.2.1.20"),
            in_discards=pick("1.3.6.1.2.1.2.2.1.13"), out_discards=pick("1.3.6.1.2.1.2.2.1.19"),
        )
    except Exception as e:
        return dict(ok=False, error=str(e))


# ------------------------------------------------------------------ user directory & live CCR active search
def list_users(r):
    """Fetch active PPPoE connections FIRST (so RADIUS/large routers never fail), then PPP secrets."""
    api = _connect(r, timeout=10)
    try:
        act = _safe(
            lambda: list(api.path("ppp", "active").select(
                Key("name"), Key("address"), Key("caller-id"), Key("uptime"), Key("service"), Key("comment")
            )),
            [],
        )
        sec = _safe(
            lambda: list(api.path("ppp", "secret").select(
                Key("name"), Key("comment"), Key("disabled"), Key("profile"), Key("last-caller-id"), Key("remote-address")
            )),
            [],
        )
    finally:
        try:
            api.close()
        except Exception:
            pass
    return sec, act


def search_active_live(q, routers, limit=15):
    """Real-time live search across all enabled MikroTik/CCR routers' /ppp/active and /ppp/secret tables."""
    ql = (q or "").strip().lower()
    if not ql:
        return []
    digits = util.norm_phone(q)
    norm_q_mac = re.sub(r"[^0-9a-f]", "", ql)

    def _search_router(r):
        if not r.get("api_enabled", True):
            return []
        try:
            api = _connect(r, timeout=5)
        except Exception:
            return []
        hits = {}
        try:
            # 1. Search active PPPoE connections on this CCR
            act_rows = _safe(
                lambda: list(api.path("ppp", "active").select(
                    Key("name"), Key("address"), Key("caller-id"), Key("uptime"), Key("comment")
                )),
                [],
            )
            for a in act_rows:
                uid = a.get("name") or ""
                if not uid:
                    continue
                ip = a.get("address") or ""
                mac = a.get("caller-id") or ""
                mac_clean = re.sub(r"[^0-9a-f]", "", mac.lower())
                comm = a.get("comment") or ""
                name, phone = util.parse_comment(comm)
                if (
                    ql in uid.lower()
                    or (ip and ql in ip.lower())
                    or (mac and (ql in mac.lower() or (len(norm_q_mac) >= 4 and norm_q_mac in mac_clean)))
                    or (comm and ql in comm.lower())
                    or (len(digits) >= 4 and digits in phone)
                ):
                    hits[uid] = dict(
                        uid=uid,
                        name=name,
                        phone=phone,
                        ip=ip,
                        mac=mac,
                        uptime=a.get("uptime") or "",
                        router_id=r["id"],
                        router=r["name"],
                        profile="",
                        online=True,
                        disabled=False,
                        source=f"CCR Active · {r['name']}",
                    )
            # 2. Enrich or search PPP secrets if needed
            if len(hits) < limit:
                sec_rows = _safe(
                    lambda: list(api.path("ppp", "secret").select(
                        Key("name"), Key("comment"), Key("disabled"), Key("profile"), Key("last-caller-id"), Key("remote-address")
                    )),
                    [],
                )
                for s in sec_rows:
                    uid = s.get("name") or ""
                    if not uid:
                        continue
                    comm = s.get("comment") or ""
                    name, phone = util.parse_comment(comm)
                    last_mac = s.get("last-caller-id") or ""
                    mac_clean = re.sub(r"[^0-9a-f]", "", last_mac.lower())
                    if uid in hits:
                        hits[uid]["name"] = hits[uid]["name"] or name
                        hits[uid]["phone"] = hits[uid]["phone"] or phone
                        hits[uid]["profile"] = s.get("profile") or ""
                        hits[uid]["disabled"] = _flag(s.get("disabled"))
                    elif len(hits) < limit * 2 and (
                        ql in uid.lower()
                        or (comm and ql in comm.lower())
                        or (len(digits) >= 4 and digits in phone)
                        or (last_mac and (ql in last_mac.lower() or (len(norm_q_mac) >= 4 and norm_q_mac in mac_clean)))
                    ):
                        hits[uid] = dict(
                            uid=uid,
                            name=name,
                            phone=phone,
                            ip=s.get("remote-address") or "",
                            mac=last_mac,
                            uptime="",
                            router_id=r["id"],
                            router=r["name"],
                            profile=s.get("profile") or "",
                            online=False,
                            disabled=_flag(s.get("disabled")),
                            source=f"CCR Secret · {r['name']}",
                        )
        finally:
            try:
                api.close()
            except Exception:
                pass
        return list(hits.values())

    active_routers = [r for r in routers if r.get("api_enabled", True)]
    if not active_routers:
        return []
    out = []
    with ThreadPoolExecutor(max_workers=min(6, len(active_routers))) as ex:
        for res in ex.map(_search_router, active_routers):
            out.extend(res)
    out.sort(key=lambda u: (not u.get("online"), not u["uid"].lower().startswith(ql), u["uid"].lower()))
    return out[:limit]


def lookup(uid, routers):
    """Live check whether a PPPoE user exists (secret or active session)."""
    for r in routers:
        if not r.get("api_enabled", True):
            continue
        try:
            api = _connect(r)
        except Exception:
            continue
        try:
            sec = _safe(lambda: _q(api, ("ppp", "secret"), ["name", "comment"], "name", uid), [])
            act = _safe(lambda: _q(api, ("ppp", "active"), ["name", "comment"], "name", uid), [])
            if sec or act:
                comm = (sec[0].get("comment") if sec else None) or (act[0].get("comment") if act else "") or ""
                return dict(router_id=r["id"], comment=comm)
        finally:
            try:
                api.close()
            except Exception:
                pass
    return None


def mtu_probe(uid, routers):
    """Largest packet that passes with DF set (detects PPPoE/MTU problems)."""
    out = []
    for size in (1500, 1492, 1480, 1472, 1400, 1280):
        p = ping(uid, routers, count=3, interval="200ms", size=size, df=True)
        if not p.get("ok"):
            return dict(ok=False, error=p.get("error"))
        out.append(dict(size=size, received=p["received"], sent=p["sent"]))
    best = next((o["size"] for o in out if o["received"] > 0), None)
    return dict(ok=True, tests=out, max_ok=best)


# ------------------------------------------------------------------ VLAN interface counters (Interface Watch + Device View)
def is_vlan_iface(name, itype=""):
    t = str(itype or "").lower()
    n = str(name or "").lower()
    return t in ("vlan", "l2vlan", "l3ipvlan", "135", "136") or "vlan" in t or n.startswith("vlan") or ".vlan" in n


def iface_counters(r, vlan_only=False):
    """name -> counters for router interfaces. Enriches VLAN interfaces with VLAN ID (vid) and parent interface."""
    api = _connect(r)
    try:
        rows = list(api.path("interface").select(
            Key("name"), Key("type"), Key("running"), Key("disabled"),
            Key("rx-byte"), Key("tx-byte"), Key("rx-error"), Key("tx-error"),
            Key("rx-drop"), Key("tx-drop"), Key("comment")
        ))
        vlan_rows = _safe(
            lambda: list(api.path("interface", "vlan").select(
                Key("name"), Key("vlan-id"), Key("interface"), Key("comment"), Key("disabled"), Key("running")
            )),
            [],
        )
    finally:
        api.close()

    vlan_map = {v.get("name"): v for v in vlan_rows if v.get("name")}
    out = {}
    for x in rows:
        n = x.get("name")
        if not n or n.startswith("<"):
            continue
        itype = x.get("type", "")
        vinfo = vlan_map.get(n)
        is_vlan = bool(vinfo) or is_vlan_iface(n, itype)
        if vlan_only and not is_vlan:
            continue
        g = lambda k: int(x.get(k) or 0)
        vid = (vinfo or {}).get("vlan-id")
        parent = (vinfo or {}).get("interface")
        kind_str = f"vlan · VID {vid} on {parent}" if vid and parent else (f"vlan · VID {vid}" if vid else ("vlan" if is_vlan else itype))
        out[n] = dict(
            type="vlan" if is_vlan else itype,
            kind=kind_str,
            is_vlan=is_vlan,
            vid=vid,
            parent=parent,
            running=_flag(x.get("running")),
            disabled=_flag(x.get("disabled")),
            rx=g("rx-byte"),
            tx=g("tx-byte"),
            err=g("rx-error") + g("tx-error"),
            drop=g("rx-drop") + g("tx-drop"),
            comment=x.get("comment") or (vinfo or {}).get("comment") or "",
        )
    # Ensure any VLAN from /interface/vlan that wasn't in generic /interface is included
    for vn, vinfo in vlan_map.items():
        if vn not in out:
            vid = vinfo.get("vlan-id")
            parent = vinfo.get("interface")
            kind_str = f"vlan · VID {vid} on {parent}" if vid and parent else "vlan"
            out[vn] = dict(
                type="vlan",
                kind=kind_str,
                is_vlan=True,
                vid=vid,
                parent=parent,
                running=_flag(vinfo.get("running")),
                disabled=_flag(vinfo.get("disabled")),
                rx=0, tx=0, err=0, drop=0,
                comment=vinfo.get("comment") or "",
            )
    return out


def iface_counters_snmp(r, vlan_only=False):
    d = snmp_dev(r)
    names = {o.rsplit(".", 1)[1]: v for o, _, v in snmp.walk(d, "1.3.6.1.2.1.31.1.1.1.1", timeout=40)}
    types = {o.rsplit(".", 1)[1]: int(snmp.num(v) or 0) for o, _, v in snmp.walk(d, "1.3.6.1.2.1.2.2.1.3", timeout=40)}
    oper = {o.rsplit(".", 1)[1]: int(snmp.num(v) or 0) for o, _, v in snmp.walk(d, "1.3.6.1.2.1.2.2.1.8", timeout=40)}
    hin = {o.rsplit(".", 1)[1]: int(snmp.num(v) or 0) for o, _, v in snmp.walk(d, "1.3.6.1.2.1.31.1.1.1.6", timeout=40)}
    hout = {o.rsplit(".", 1)[1]: int(snmp.num(v) or 0) for o, _, v in snmp.walk(d, "1.3.6.1.2.1.31.1.1.1.10", timeout=40)}
    err = {o.rsplit(".", 1)[1]: int(snmp.num(v) or 0) for o, _, v in snmp.walk(d, "1.3.6.1.2.1.2.2.1.14", timeout=40)}
    out = {}
    for ix, n in names.items():
        if n.startswith("<"):
            continue
        if_type_num = types.get(ix, 0)
        is_vlan = if_type_num in (135, 136, 137) or is_vlan_iface(n, "")
        if vlan_only and not is_vlan:
            continue
        out[n] = dict(
            type="vlan" if is_vlan else "snmp",
            kind="vlan" if is_vlan else "snmp",
            is_vlan=is_vlan,
            vid=None,
            parent=None,
            running=oper.get(ix) == 1,
            disabled=False,
            rx=hin.get(ix, 0),
            tx=hout.get(ix, 0),
            err=err.get(ix, 0),
            drop=0,
            comment="",
        )
    return out


def get_iface_counters(r, vlan_only=False):
    """API first, SNMP fallback. Returns (dict, via)."""
    if r.get("api_enabled", True):
        try:
            return iface_counters(r, vlan_only=vlan_only), "api"
        except Exception:
            if not r.get("snmp_enabled"):
                raise
    return iface_counters_snmp(r, vlan_only=vlan_only), "snmp"


def device_info(r):
    """Everything useful about a router for its detail page."""
    api = _connect(r)
    try:
        res = _safe(lambda: list(api.path("system", "resource"))[0], {})
        health_rows = _safe(lambda: list(api.path("system", "health")), [])
        health = []
        for h in health_rows:
            if "name" in h and "value" in h:
                health.append((h["name"], f"{h['value']} {h.get('type', '')}".strip()))
            else:
                health += [(k, str(v)) for k, v in h.items() if not k.startswith(".")]
        rb = _safe(lambda: list(api.path("system", "routerboard"))[0], {})
        ident = _safe(lambda: list(api.path("system", "identity"))[0]["name"])
        ifs = _safe(lambda: list(api.path("interface").select(
            Key("name"), Key("type"), Key("running"), Key("disabled"),
            Key("rx-byte"), Key("tx-byte"), Key("rx-error"), Key("tx-error"),
            Key("mtu"), Key("mac-address"), Key("comment")
        )), [])
        vlans = _safe(lambda: [dict(name=x.get("name"), vid=x.get("vlan-id"), parent=x.get("interface"),
                                    running=_flag(x.get("running"))) for x in api.path("interface", "vlan")], [])
        servers = _safe(lambda: [dict(service=x.get("service-name"), interface=x.get("interface"),
                                      disabled=_flag(x.get("disabled"))) for x in api.path("interface", "pppoe-server", "server")], [])
        pools = _safe(lambda: [dict(name=x.get("name"), ranges=x.get("ranges")) for x in api.path("ip", "pool")], [])
        for p in pools[:12]:
            pname = p["name"]
            c = _safe(lambda pn=pname: list(api.rawCmd("/ip/pool/used/print", "=count-only=", f"?pool={pn}")), [])
            p["used"] = next((int(x["ret"]) for x in c if isinstance(x, dict) and str(x.get("ret", "")).isdigit()), None)
        addrs = _safe(lambda: [dict(address=x.get("address"), interface=x.get("interface")) for x in api.path("ip", "address")], [])
        cnt = _safe(lambda: list(api.rawCmd("/ppp/active/print", "=count-only=")), [])
        active = next((int(x["ret"]) for x in cnt if isinstance(x, dict) and str(x.get("ret", "")).isdigit()), None)
        logs = _safe(lambda: [dict(time=l.get("time"), topics=l.get("topics"), message=l.get("message"))
                              for l in list(api.path("log"))[-40:]], [])
        tm, fm = int(res.get("total-memory", 0) or 0), int(res.get("free-memory", 0) or 0)
        th, fh = int(res.get("total-hdd-space", 0) or 0), int(res.get("free-hdd-space", 0) or 0)
        return dict(
            identity=ident, version=res.get("version"), board=res.get("board-name"), arch=res.get("architecture-name"),
            cpu=res.get("cpu"), cpu_count=res.get("cpu-count"), cpu_load=res.get("cpu-load"), uptime=res.get("uptime"),
            mem_pct=round(100 * (tm - fm) / tm) if tm else None, mem_total=tm,
            disk_pct=round(100 * (th - fh) / th) if th else None, model=rb.get("model"), serial=rb.get("serial-number"),
            firmware=rb.get("current-firmware"), health=health, active=active, vlans=vlans, servers=servers,
            pools=pools, addrs=addrs, logs=logs,
            ifaces=[dict(
                name=x.get("name"), type=x.get("type"), running=_flag(x.get("running")),
                disabled=_flag(x.get("disabled")), rx=int(x.get("rx-byte") or 0), tx=int(x.get("tx-byte") or 0),
                err=int(x.get("rx-error") or 0) + int(x.get("tx-error") or 0), mtu=x.get("mtu"),
                mac=x.get("mac-address"), comment=x.get("comment") or ""
            ) for x in ifs if x.get("name") and not str(x.get("name")).startswith("<")],
        )
    finally:
        api.close()
