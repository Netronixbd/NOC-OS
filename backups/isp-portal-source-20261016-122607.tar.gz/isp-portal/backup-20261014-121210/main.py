import csv
import hashlib
import hmac
import io
import json
import logging
import os
import re
import secrets
import time
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from fastapi import BackgroundTasks, Depends, FastAPI, File, Form, Request, UploadFile
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import func
from starlette.middleware.sessions import SessionMiddleware

import diag
import mikrotik
import olt as oltlib
import oui
import snmp
import ctx
import rusers
import telegram_bot
import util
from ctx import olt_dict, olt_dicts, profile_dict, router_dicts
from starlette.concurrency import run_in_threadpool
from util import looks_mac, mask_name, mask_phone, mask_uid, norm_phone, parse_comment
from db import (OLT, STATUS_LABEL, Admin, Complaint, Customer, OltProfile, Router, SessionLocal,
                apply_action, get_setting, init_db, set_setting)

log = logging.getLogger("portal")
app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
app.add_middleware(SessionMiddleware, secret_key=os.getenv("SECRET_KEY") or secrets.token_hex(32),
                   same_site="strict", max_age=8 * 3600)
templates = Jinja2Templates(directory="templates")
DHAKA = ZoneInfo("Asia/Dhaka")
templates.env.filters["dt"] = lambda d: (d.replace(tzinfo=ZoneInfo("UTC")).astimezone(DHAKA)
                                         .strftime("%d %b %Y, %I:%M %p") if d else "-")
templates.env.globals["STATUS_LABEL"] = STATUS_LABEL
CATEGORIES = ["No internet", "Slow speed", "Frequent disconnect", "Billing / payment", "Other"]
VENDORS = ["BDCOM", "VSOL", "C-Data", "Other"]


# ---------------------------------------------------------------- helpers
def hash_pw(p, salt=None):
    salt = salt or secrets.token_hex(16)
    return f"{salt}${hashlib.pbkdf2_hmac('sha256', p.encode(), salt.encode(), 200000).hex()}"


def check_pw(p, stored):
    salt, h = stored.split("$")
    return hmac.compare_digest(hash_pw(p, salt).split("$")[1], h)


_hits = {}


def limited(key, n, window):
    now = time.time()
    l = [t for t in _hits.get(key, []) if now - t < window]
    if len(l) >= n:
        _hits[key] = l
        return True
    l.append(now)
    _hits[key] = l
    return False


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def flash(request, msg, kind="ok"):
    f = request.session.get("flash", [])
    f.append([kind, msg])
    request.session["flash"] = f


def render(request, name, **ctx):
    ctx["flash"] = request.session.pop("flash", [])
    ctx["site_title"] = get_setting("site_title", "Customer Support Portal")
    ctx["is_admin"] = bool(request.session.get("admin"))
    return templates.TemplateResponse(request, name, ctx)


class NeedLogin(Exception):
    pass


@app.exception_handler(NeedLogin)
def _need_login(request, exc):
    return RedirectResponse("/admin/login", 303)


def admin_required(request: Request):
    if not request.session.get("admin"):
        raise NeedLogin()


ADMIN = [Depends(admin_required)]


@app.on_event("startup")
def startup():
    init_db()
    with SessionLocal() as db:
        if not db.query(Admin).count():
            user = os.getenv("ADMIN_USER", "admin")
            pw = os.getenv("ADMIN_PASS") or secrets.token_urlsafe(9)
            db.add(Admin(username=user, password_hash=hash_pw(pw)))
            db.commit()
            log.warning("Admin created: %s / %s", user, pw)
    oui.background_init()
    rusers.start(ctx.all_routers_fresh)
    telegram_bot.start_poller()


# ================================================================ public portal
@app.get("/")
def home(request: Request):
    return render(request, "index.html", results=None, q="")


def adopt_router_user(db, uid):
    """Customer typed a PPPoE user ID that is not in our customer table: build the record from the router."""
    if not re.fullmatch(r"\S{3,64}", uid):
        return None
    u = rusers.exact(uid)
    if u:
        name, phone, rid, canon = u["name"], u["phone"], u["router_id"], u["uid"]
    else:
        info = mikrotik.lookup(uid, router_dicts(db))
        if not info:
            return None
        (name, phone), rid, canon = parse_comment(info["comment"]), info["router_id"], uid
    c = db.query(Customer).filter_by(user_id=canon).first()
    if not c:
        c = Customer(user_id=canon, token=secrets.token_hex(8), name=name or canon, phone=norm_phone(phone), router_id=rid)
        db.add(c)
        db.commit()
        db.refresh(c)
    return c


@app.post("/search")
def search(request: Request, q: str = Form(""), db=Depends(get_db)):
    q = q.strip()
    if limited(f"s:{request.client.host}", 25, 600):
        flash(request, "Too many searches. Please wait a few minutes.", "err")
        return RedirectResponse("/", 303)
    if len(q) < 3:
        flash(request, "Please enter at least 3 characters.", "err")
        return RedirectResponse("/", 303)
    qs = db.query(Customer)
    found = qs.filter(func.lower(Customer.user_id) == q.lower()).all()
    digits = norm_phone(q)
    if not found and len(digits) >= 10:
        found = qs.filter(Customer.phone == digits).all()
    if not found:
        c = adopt_router_user(db, q)
        if c:
            return RedirectResponse(f"/c/{c.token}", 303)
    if len(found) == 1:
        return RedirectResponse(f"/c/{found[0].token}", 303)
    if not found:
        found = qs.filter(Customer.name.ilike(f"%{q}%")).limit(10).all()
    return render(request, "index.html", results=[
        dict(token=c.token, name=c.name or "-", uid=mask_uid(c.user_id), phone=mask_phone(c.phone))
        for c in found], q=q)


@app.get("/api/suggest")
def api_suggest(request: Request, q: str = "", db=Depends(get_db)):
    q = q.strip()
    if get_setting("public_suggest", "1") != "1" or len(q) < 3 or limited(f"sg:{request.client.host}", 80, 600):
        return JSONResponse([])
    return JSONResponse([dict(uid=i["uid"], name=mask_name(i["name"])) for i in ctx.suggest(db, q, 6)])


def get_cust(db, token):
    return db.query(Customer).filter_by(token=token).first()


@app.get("/c/{token}")
def customer_page(request: Request, token: str, db=Depends(get_db)):
    c = get_cust(db, token)
    if not c:
        return RedirectResponse("/", 303)
    st = mikrotik.status(c.user_id, router_dicts(db, c.router_id))
    return render(request, "customer.html", c=c, phone=mask_phone(c.phone), st=st,
                  cats=CATEGORIES, complaints=c.complaints[:10])


_pon_alerts = {}


def notify_new(cid):
    """Background: collect full diagnostics, store snapshot, post to Telegram."""
    with SessionLocal() as db:
        c = db.get(Complaint, cid)
        cust = c.customer
        lines, same = [], 0
        try:
            d = ctx.diagnose(cust.user_id, None, exclude=cid)
            opt = d.get("optical") or {}
            if opt.get("found"):
                c.olt_name, c.pon = opt.get("olt") or "", opt.get("pon") or ""
            lines = list(d["report"])
            if c.pon:
                same = db.query(Complaint).filter(
                    Complaint.olt_name == c.olt_name, Complaint.pon == c.pon, Complaint.status != "closed",
                    Complaint.created_at >= datetime.utcnow() - timedelta(hours=1), Complaint.id != c.id).count()
            if same >= 2:
                lines.append(f"🚨 {same} other open complaints on {c.olt_name} PON {c.pon} in the last hour: possible PON / fiber outage")
            c.diag_json = json.dumps(dict(lines=lines), ensure_ascii=False)
        except Exception as e:
            log.warning("diag failed: %s", e)
        try:
            res = telegram_bot.send(telegram_bot.complaint_text(c, cust, lines), buttons=telegram_bot.buttons_for(c.id))
            c.tg_message_id = res["message_id"]
            key = (c.olt_name, c.pon)
            if same >= 2 and time.time() - _pon_alerts.get(key, 0) > 3600:
                _pon_alerts[key] = time.time()
                telegram_bot.send(f"🚨 <b>Possible PON outage</b>\n{same + 1} open complaints on {c.olt_name} PON {c.pon} within 1 hour.")
        except Exception as e:
            c.notify_error = str(e)[:250]
            log.warning("Telegram notify failed: %s", e)
        db.commit()


@app.post("/c/{token}/complaint")
def complaint_submit(request: Request, bg: BackgroundTasks, token: str, category: str = Form(...),
                     message: str = Form(""), contact_phone: str = Form(""), db=Depends(get_db)):
    c = get_cust(db, token)
    if not c:
        return RedirectResponse("/", 303)
    back = RedirectResponse(f"/c/{token}", 303)
    if category not in CATEGORIES:
        category = "Other"
    open_n = db.query(Complaint).filter(Complaint.customer_id == c.id, Complaint.status != "closed").count()
    if open_n >= 3 or limited(f"c:{c.id}", 3, 3600):
        flash(request, "You already have open complaints. Our team is working on them.", "err")
        return back
    cm = Complaint(customer_id=c.id, category=category, message=message.strip()[:1000],
                   contact_phone=norm_phone(contact_phone)[:15])
    db.add(cm)
    db.commit()
    db.refresh(cm)
    bg.add_task(notify_new, cm.id)
    flash(request, f"Your complaint #{cm.id} has been received. We will fix it as soon as possible.")
    return back


@app.post("/c/{token}/followup/{cid}")
def customer_followup(request: Request, token: str, cid: int, message: str = Form(""), db=Depends(get_db)):
    c = get_cust(db, token)
    cm = db.get(Complaint, cid)
    back = RedirectResponse(f"/c/{token}", 303)
    if not c or not cm or cm.customer_id != c.id or cm.status == "closed" or not message.strip():
        return back
    if limited(f"f:{c.id}", 6, 3600):
        flash(request, "Too many messages. Please wait.", "err")
        return back
    apply_action(db, cid, "reply", c.name or c.user_id, message, "customer")
    try:
        if cm.tg_message_id:
            from html import escape
            telegram_bot.send(f"💬 <b>Customer follow-up on #{cid}</b>\n{escape(message.strip()[:600])}",
                              reply_to=cm.tg_message_id)
    except Exception:
        pass
    flash(request, "Your message was sent to our team.")
    return back


# ================================================================ admin auth
@app.get("/admin/login")
def login_page(request: Request):
    return render(request, "admin_login.html")


@app.post("/admin/login")
def login(request: Request, username: str = Form(""), password: str = Form(""), db=Depends(get_db)):
    if limited(f"l:{request.client.host}", 8, 600):
        flash(request, "Too many attempts. Try again later.", "err")
        return RedirectResponse("/admin/login", 303)
    a = db.query(Admin).filter_by(username=username).first()
    if a and check_pw(password, a.password_hash):
        request.session["admin"] = a.username
        return RedirectResponse("/admin", 303)
    flash(request, "Wrong username or password.", "err")
    return RedirectResponse("/admin/login", 303)


@app.get("/admin/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/admin/login", 303)


# ================================================================ admin: complaints
@app.get("/admin", dependencies=ADMIN)
@app.get("/admin/complaints", dependencies=ADMIN)
def admin_home(request: Request, status: str = "active", db=Depends(get_db)):
    q = db.query(Complaint)
    if status == "active":
        q = q.filter(Complaint.status != "closed")
    elif status in STATUS_LABEL:
        q = q.filter(Complaint.status == status)
    since = datetime.utcnow() - timedelta(hours=24)
    stats = dict(active=db.query(Complaint).filter(Complaint.status != "closed").count(),
                 today=db.query(Complaint).filter(Complaint.created_at >= since).count(),
                 closed=db.query(Complaint).filter_by(status="closed").count(),
                 customers=db.query(Customer).count())
    items = q.order_by(Complaint.id.desc()).limit(200).all()
    snaps = {}
    for x in items:
        try:
            snaps[x.id] = json.loads(x.diag_json or "{}").get("lines", [])
        except ValueError:
            snaps[x.id] = []
    return render(request, "admin_complaints.html", items=items, status=status, stats=stats, snaps=snaps)


@app.post("/admin/complaints/{cid}/act", dependencies=ADMIN)
def complaint_act(request: Request, cid: int, action: str = Form(...), message: str = Form(""),
                  db=Depends(get_db)):
    by = request.session["admin"]
    back = RedirectResponse(request.headers.get("referer") or "/admin", 303)
    if action not in ("wait", "reply", "close"):
        return back
    if action == "reply" and not message.strip():
        flash(request, "Write a reply message first.", "err")
        return back
    c = apply_action(db, cid, action, by, message)
    if not c:
        flash(request, "Complaint not found or already closed.", "err")
        return back
    from html import escape
    txt = {"wait": f"⏳ #{cid} → Waiting for update (by {escape(by)})",
           "reply": f"💬 #{cid} reply by {escape(by)}:\n{escape(message.strip()[:500])}",
           "close": f"✅ #{cid} closed by {escape(by)}" + (f"\n📝 {escape(message.strip()[:300])}" if message.strip() else "")}[action]
    try:
        telegram_bot.send(txt, reply_to=c.tg_message_id)
        if action == "close" and c.tg_message_id:
            telegram_bot._remove_buttons(get_setting("tg_chat_id"), c.tg_message_id)
    except Exception:
        pass
    flash(request, f"Complaint #{cid} updated.")
    return back


# ================================================================ admin: diagnose
@app.get("/admin/diagnose", dependencies=ADMIN)
def diagnose_search(request: Request, q: str = "", db=Depends(get_db)):
    q = q.strip()
    results = None
    if q:
        results = ctx.find(db, q)
        if len(results) == 1:
            r = results[0]
            return RedirectResponse(f"/admin/d?uid={r['uid']}&mac={r.get('mac', '')}", 303)
    recent = db.query(Complaint).filter(Complaint.status != "closed").order_by(Complaint.id.desc()).limit(8).all()
    return render(request, "admin_diagnose.html", q=q, results=results, recent=recent)


@app.get("/admin/api/suggest", dependencies=ADMIN)
def admin_suggest(q: str = "", db=Depends(get_db)):
    q = q.strip()
    if len(q) < 2:
        return JSONResponse([])
    return JSONResponse(ctx.suggest(db, q, 10))


@app.get("/admin/d", dependencies=ADMIN)
def diag_page(request: Request, uid: str = "", mac: str = "", db=Depends(get_db)):
    cust = db.query(Customer).filter_by(user_id=uid).first() if uid else None
    return render(request, "admin_diag.html", uid=uid, mac=mac, cust=cust)


@app.get("/admin/api/diag", dependencies=ADMIN)
async def api_diag(uid: str = "", mac: str = ""):
    try:
        return JSONResponse(await run_in_threadpool(ctx.diagnose, uid, mac or None))
    except Exception as e:
        log.exception("diag failed")
        return JSONResponse(dict(error=str(e)), status_code=500)


@app.get("/admin/api/ping", dependencies=ADMIN)
def api_ping(uid: str, db=Depends(get_db)):
    return JSONResponse(mikrotik.ping(uid, router_dicts(db)))


# ================================================================ admin: customers
@app.get("/admin/customers", dependencies=ADMIN)
def admin_customers(request: Request, q: str = "", db=Depends(get_db)):
    qs = db.query(Customer)
    if q:
        like = f"%{q}%"
        qs = qs.filter(Customer.user_id.ilike(like) | Customer.name.ilike(like) | Customer.phone.ilike(like))
    return render(request, "admin_customers.html", items=qs.order_by(Customer.id.desc()).limit(300).all(),
                  q=q, total=db.query(Customer).count())


def upsert_customer(db, user_id, name="", phone="", address="", router_id=None, overwrite=True):
    user_id = user_id.strip()
    if not user_id:
        return None
    c = db.query(Customer).filter_by(user_id=user_id).first()
    if not c:
        db.add(Customer(user_id=user_id, token=secrets.token_hex(8), name=name, phone=norm_phone(phone),
                        address=address, router_id=router_id))
        return "new"
    if overwrite or not c.name:
        c.name = name or c.name
    if (overwrite or not c.phone) and phone:
        c.phone = norm_phone(phone)
    if address:
        c.address = address
    if router_id and not c.router_id:
        c.router_id = router_id
    return "updated"


@app.post("/admin/customers/add", dependencies=ADMIN)
def customer_add(request: Request, user_id: str = Form(...), name: str = Form(""), phone: str = Form(""),
                 address: str = Form(""), db=Depends(get_db)):
    r = upsert_customer(db, user_id, name, phone, address)
    db.commit()
    flash(request, "Customer added." if r == "new" else "Customer updated.")
    return RedirectResponse("/admin/customers", 303)


@app.post("/admin/customers/import", dependencies=ADMIN)
async def customer_import(request: Request, file: UploadFile = File(...), db=Depends(get_db)):
    text = (await file.read()).decode("utf-8-sig", errors="ignore")
    n = 0
    for row in csv.DictReader(io.StringIO(text)):
        row = {(k or "").strip().lower(): (v or "").strip() for k, v in row.items()}
        if upsert_customer(db, row.get("user_id", ""), row.get("name", ""), row.get("phone", ""), row.get("address", "")):
            n += 1
    db.commit()
    flash(request, f"{n} rows imported.")
    return RedirectResponse("/admin/customers", 303)


@app.get("/admin/customers/{cid}", dependencies=ADMIN)
def customer_edit_page(request: Request, cid: int, db=Depends(get_db)):
    c = db.get(Customer, cid)
    if not c:
        return RedirectResponse("/admin/customers", 303)
    fields = [fld("name", "Name", c.name), fld("phone", "Phone", c.phone), fld("address", "Address", c.address),
              fld("onu_mac", "ONU MAC (optional, used if router MAC lookup fails)", c.onu_mac)]
    return render(request, "admin_form.html", title=f"Edit {c.user_id}", fields=fields, back="/admin/customers",
                  action=f"/admin/customers/{cid}")


@app.post("/admin/customers/{cid}", dependencies=ADMIN)
async def customer_edit(request: Request, cid: int, db=Depends(get_db)):
    f = await request.form()
    c = db.get(Customer, cid)
    if c:
        c.name, c.phone, c.address = f.get("name", "").strip(), norm_phone(f.get("phone", "")), f.get("address", "").strip()
        c.onu_mac = snmp.norm_mac(f.get("onu_mac", "")) or ""
        db.commit()
        flash(request, "Saved.")
    return RedirectResponse("/admin/customers", 303)


@app.post("/admin/customers/{cid}/delete", dependencies=ADMIN)
def customer_delete(request: Request, cid: int, db=Depends(get_db)):
    c = db.get(Customer, cid)
    if c:
        db.delete(c)
        db.commit()
        flash(request, "Customer removed.")
    return RedirectResponse("/admin/customers", 303)


# ================================================================ admin: devices (routers / OLTs / profiles)
def fld(name, label, value="", type="text", options=None, help=""):
    return dict(name=name, label=label, value=value if value is not None else "", type=type, options=options or [], help=help)


@app.get("/admin/devices", dependencies=ADMIN)
def devices_page(request: Request, db=Depends(get_db)):
    profs = db.query(OltProfile).all()
    pn = {p.id: p.name for p in profs}
    pc = {p.id: sum(1 for c in profile_dict(p)["oids"].values() if c.get("oid")) for p in profs}
    return render(request, "admin_devices.html", routers=db.query(Router).all(), olts=db.query(OLT).all(),
                  profiles=profs, pn=pn, pc=pc)


def router_fields(r=None):
    r = r or Router(name="", host="", api_enabled=True, port=8728, username="", password="", use_ssl=False,
                    snmp_enabled=False, snmp_port=161, snmp_community="public")
    return [fld("name", "Name", r.name), fld("host", "IP / host", r.host),
            fld("api_enabled", "Enable API (user details, session, logs)", r.api_enabled is not False, "checkbox"),
            fld("port", "API port (8728 / 8729 SSL)", r.port, "number"), fld("use_ssl", "Use SSL (api-ssl)", r.use_ssl, "checkbox"),
            fld("username", "API user", r.username),
            fld("password", "API password", "", "password", help="Leave blank to keep the saved password" if r.id else ""),
            fld("snmp_enabled", "Enable SNMP (live interface rate, errors)", r.snmp_enabled, "checkbox"),
            fld("snmp_port", "SNMP port", r.snmp_port or 161, "number"),
            fld("snmp_community", "SNMP community", r.snmp_community or "public")]


@app.get("/admin/devices/router/new", dependencies=ADMIN)
def router_new(request: Request):
    return render(request, "admin_form.html", title="Add MikroTik router", fields=router_fields(), back="/admin/devices",
                  action="/admin/devices/router/new")


@app.get("/admin/devices/router/{rid}", dependencies=ADMIN)
def router_edit_page(request: Request, rid: int, db=Depends(get_db)):
    r = db.get(Router, rid)
    if not r:
        return RedirectResponse("/admin/devices", 303)
    return render(request, "admin_form.html", title=f"Edit router {r.name}", fields=router_fields(r),
                  back="/admin/devices", action=f"/admin/devices/router/{rid}")


async def _save_router(request, db, r):
    f = await request.form()
    r.name, r.host = f.get("name", "").strip(), f.get("host", "").strip()
    r.api_enabled, r.use_ssl, r.snmp_enabled = bool(f.get("api_enabled")), bool(f.get("use_ssl")), bool(f.get("snmp_enabled"))
    r.port, r.snmp_port = int(f.get("port") or 8728), int(f.get("snmp_port") or 161)
    r.username, r.snmp_community = f.get("username", "").strip(), f.get("snmp_community", "").strip() or "public"
    if f.get("password"):
        r.password = f["password"]
    db.add(r)
    db.commit()


@app.post("/admin/devices/router/new", dependencies=ADMIN)
async def router_create(request: Request, db=Depends(get_db)):
    await _save_router(request, db, Router(password=""))
    rusers.refresh_async()
    flash(request, "Router added. Use Test API / Test SNMP / Sync to verify.")
    return RedirectResponse("/admin/devices", 303)


@app.post("/admin/devices/router/{rid}", dependencies=ADMIN)
async def router_update(request: Request, rid: int, db=Depends(get_db)):
    r = db.get(Router, rid)
    if r:
        await _save_router(request, db, r)
        rusers.refresh_async()
        flash(request, "Router saved.")
    return RedirectResponse("/admin/devices", 303)


@app.post("/admin/devices/router/{rid}/delete", dependencies=ADMIN)
def router_delete(request: Request, rid: int, db=Depends(get_db)):
    r = db.get(Router, rid)
    if r:
        db.query(Customer).filter_by(router_id=rid).update({"router_id": None})
        db.delete(r)
        db.commit()
        flash(request, "Router removed.")
    return RedirectResponse("/admin/devices", 303)


@app.post("/admin/devices/router/{rid}/test", dependencies=ADMIN)
def router_test(request: Request, rid: int, db=Depends(get_db)):
    try:
        flash(request, f"API connected. Router identity: {mikrotik.test(router_dicts(db, rid)[0])}")
    except Exception as e:
        flash(request, f"API connection failed: {e}", "err")
    return RedirectResponse("/admin/devices", 303)


@app.post("/admin/devices/router/{rid}/snmp-test", dependencies=ADMIN)
def router_snmp_test(request: Request, rid: int, db=Depends(get_db)):
    try:
        r = mikrotik.snmp_test(router_dicts(db, rid)[0])
        flash(request, f"SNMP OK. Name: {r['name']}, uptime ticks: {r['uptime']}")
    except Exception as e:
        flash(request, f"SNMP failed: {e}", "err")
    return RedirectResponse("/admin/devices", 303)


@app.post("/admin/devices/router/{rid}/sync", dependencies=ADMIN)
def router_sync(request: Request, rid: int, overwrite: str = Form(""), db=Depends(get_db)):
    try:
        secs = mikrotik.fetch_secrets(router_dicts(db, rid)[0])
    except Exception as e:
        flash(request, f"Sync failed: {e}", "err")
        return RedirectResponse("/admin/devices", 303)
    new = upd = 0
    for s in secs:
        uid = s.get("name")
        if not uid:
            continue
        name, phone = parse_comment(s.get("comment", ""))
        r = upsert_customer(db, uid, name or uid, phone, router_id=rid, overwrite=bool(overwrite))
        new += r == "new"
        upd += r == "updated"
    db.commit()
    rusers.refresh_async()
    flash(request, f"Sync done: {new} new, {upd} existing users from {len(secs)} PPPoE secrets.")
    return RedirectResponse("/admin/devices", 303)


# ---- OLTs
def olt_fields(o, db):
    o = o or OLT(name="", vendor="BDCOM", host="", snmp_port=161, community="public", snmp_version="2c", vlans="",
                 enabled=True)
    profs = [(str(p.id), p.name) for p in db.query(OltProfile).all()]
    return [fld("name", "OLT name", o.name), fld("vendor", "Vendor", o.vendor, "select", [(v, v) for v in VENDORS]),
            fld("host", "OLT IP", o.host), fld("snmp_port", "SNMP port", o.snmp_port or 161, "number"),
            fld("community", "SNMP community (read)", o.community),
            fld("snmp_version", "SNMP version", o.snmp_version, "select", [("2c", "v2c"), ("1", "v1")]),
            fld("profile_id", "OID profile", str(o.profile_id or ""), "select", profs),
            fld("vlans", "PPPoE VLAN IDs (optional, comma separated)", o.vlans,
                help="Only needed if the OLT FDB lookup requires community@vlan"),
            fld("enabled", "Enabled", o.enabled is not False, "checkbox")]


async def _save_olt(request, db, o):
    f = await request.form()
    o.name, o.vendor, o.host = f.get("name", "").strip(), f.get("vendor", "Other"), f.get("host", "").strip()
    o.snmp_port, o.community = int(f.get("snmp_port") or 161), f.get("community", "").strip() or "public"
    o.snmp_version = f.get("snmp_version", "2c")
    o.profile_id = int(f["profile_id"]) if f.get("profile_id") else None
    o.vlans, o.enabled = f.get("vlans", "").strip(), bool(f.get("enabled"))
    db.add(o)
    db.commit()


@app.get("/admin/devices/olt/new", dependencies=ADMIN)
def olt_new(request: Request, db=Depends(get_db)):
    return render(request, "admin_form.html", title="Add OLT", fields=olt_fields(None, db), back="/admin/devices",
                  action="/admin/devices/olt/new")


@app.post("/admin/devices/olt/new", dependencies=ADMIN)
async def olt_create(request: Request, db=Depends(get_db)):
    await _save_olt(request, db, OLT())
    flash(request, "OLT added. Test SNMP, then open Tools to set up OIDs.")
    return RedirectResponse("/admin/devices", 303)


@app.get("/admin/devices/olt/{oid}", dependencies=ADMIN)
def olt_edit_page(request: Request, oid: int, db=Depends(get_db)):
    o = db.get(OLT, oid)
    if not o:
        return RedirectResponse("/admin/devices", 303)
    return render(request, "admin_form.html", title=f"Edit OLT {o.name}", fields=olt_fields(o, db),
                  back="/admin/devices", action=f"/admin/devices/olt/{oid}")


@app.post("/admin/devices/olt/{oid}", dependencies=ADMIN)
async def olt_update(request: Request, oid: int, db=Depends(get_db)):
    o = db.get(OLT, oid)
    if o:
        await _save_olt(request, db, o)
        flash(request, "OLT saved.")
    return RedirectResponse("/admin/devices", 303)


@app.post("/admin/devices/olt/{oid}/delete", dependencies=ADMIN)
def olt_delete(request: Request, oid: int, db=Depends(get_db)):
    o = db.get(OLT, oid)
    if o:
        db.delete(o)
        db.commit()
        flash(request, "OLT removed.")
    return RedirectResponse("/admin/devices", 303)


@app.post("/admin/devices/olt/{oid}/test", dependencies=ADMIN)
def olt_test(request: Request, oid: int, db=Depends(get_db)):
    profs = {p.id: p for p in db.query(OltProfile)}
    try:
        i = oltlib.sys_info(olt_dict(db.get(OLT, oid), profs))
        flash(request, f"SNMP OK: {i['name']} | {i['descr']}")
    except Exception as e:
        flash(request, f"SNMP failed: {e}", "err")
    return RedirectResponse("/admin/devices", 303)


@app.get("/admin/devices/olt/{oid}/tools", dependencies=ADMIN)
def olt_tools(request: Request, oid: int, db=Depends(get_db)):
    o = db.get(OLT, oid)
    if not o:
        return RedirectResponse("/admin/devices", 303)
    return render(request, "admin_olt_tools.html", o=o, prof=db.get(OltProfile, o.profile_id), result=None,
                  fields=oltlib.FIELDS, form={})


def _tools_work(action, dev, prof, f):
    if action == "walk":
        rows = snmp.walk(dev, (f.get("oid_in") or "1.3.6.1.2.1.1").strip(), timeout=90)
        return dict(kind="walk", total=len(rows), rows=rows[:400])
    if action == "locate":
        m = snmp.norm_mac(f.get("mac", ""))
        if not m:
            raise ValueError("Enter a valid MAC address")
        return dict(kind="locate", data=oltlib.locate_one(dev, prof, m) or dict(found=False))
    if action == "discover":
        suf, name = (f.get("suffix") or "").strip(), None
        if not suf:
            m = snmp.norm_mac(f.get("mac", ""))
            if not m:
                raise ValueError("Enter a customer router MAC, or the ONU index suffix")
            suf, name = oltlib.resolve_suffix(dev, prof, m)
            if not suf:
                raise ValueError("MAC not found in the OLT MAC table (is that customer online?)")
        st = (f.get("start") or "").strip() or prof["enterprise_oid"] or "1.3.6.1.4.1"
        rows, total = oltlib.discover(dev, st, suf)
        known = {k[6:]: v for k, v in f.items() if k.startswith("known_") and str(v).strip()}
        best = oltlib.match_known(rows, known) if known else []
        return dict(kind="discover", rows=rows, total=total, suffix=suf, ifname=name, start=st, best=best)
    raise ValueError("Unknown action")


@app.post("/admin/devices/olt/{oid}/tools", dependencies=ADMIN)
async def olt_tools_run(request: Request, oid: int, db=Depends(get_db)):
    f = dict((await request.form()).items())
    o = db.get(OLT, oid)
    profs = {p.id: p for p in db.query(OltProfile)}
    dev = olt_dict(o, profs)
    try:
        result = await run_in_threadpool(_tools_work, f.get("action", ""), dev, dev["profile"], f)
    except Exception as e:
        flash(request, f"{f.get('action')} failed: {e}", "err")
        result = None
    return render(request, "admin_olt_tools.html", o=o, prof=db.get(OltProfile, o.profile_id), result=result,
                  fields=oltlib.FIELDS, form=f)


@app.post("/admin/devices/olt/{oid}/scan", dependencies=ADMIN)
async def olt_scan(request: Request, oid: int, db=Depends(get_db)):
    o = db.get(OLT, oid)
    dev = olt_dict(o, {p.id: p for p in db.query(OltProfile)})
    try:
        res = await run_in_threadpool(oltlib.scan, dev, dev["profile"])
    except Exception as e:
        flash(request, f"Scan failed: {e}", "err")
        return RedirectResponse(f"/admin/devices/olt/{oid}/tools", 303)
    return render(request, "admin_olt_scan.html", o=o, res=res)


@app.post("/admin/devices/profile/{pid}/assign-many", dependencies=ADMIN)
async def profile_assign_many(request: Request, pid: int, db=Depends(get_db)):
    f = await request.form()
    p = db.get(OltProfile, pid)
    if p:
        oids = profile_dict(p)["oids"]
        n = 0
        for fld_, col, div, unit in zip(f.getlist("field"), f.getlist("oid_col"), f.getlist("div"), f.getlist("unit")):
            if fld_ in dict(oltlib.FIELDS):
                oids[fld_] = dict(oid=col.strip("."), div=float(div or 1), unit=unit or "dbm")
                n += 1
        p.oids = json.dumps(oids)
        db.commit()
        flash(request, f"{n} OIDs saved to profile. Verify with Locate by MAC.")
    return RedirectResponse(f.get("back") if str(f.get("back", "")).startswith("/admin/") else "/admin/devices", 303)


# ---- profiles
@app.get("/admin/devices/profile/{pid}", dependencies=ADMIN)
def profile_page(request: Request, pid: int, db=Depends(get_db)):
    p = db.get(OltProfile, pid)
    if not p:
        return RedirectResponse("/admin/devices", 303)
    return render(request, "admin_profile.html", p=p, oids=profile_dict(p)["oids"], fields=oltlib.FIELDS)


@app.post("/admin/devices/profile/{pid}", dependencies=ADMIN)
async def profile_save(request: Request, pid: int, db=Depends(get_db)):
    p = db.get(OltProfile, pid)
    f = await request.form()
    p.name, p.vendor = f.get("name", p.name).strip(), f.get("vendor", p.vendor)
    p.enterprise_oid, p.index_template = f.get("enterprise_oid", "").strip(), f.get("index_template", "").strip() or "{ifindex}"
    p.status_map, p.notes = f.get("status_map", "").strip(), f.get("notes", "")
    oids = {}
    for key, _ in oltlib.FIELDS:
        o = f.get(f"oid_{key}", "").strip().strip(".")
        if o:
            oids[key] = dict(oid=o, div=float(f.get(f"div_{key}") or 1), unit=f.get(f"unit_{key}") or "dbm")
    p.oids = json.dumps(oids)
    db.commit()
    flash(request, "Profile saved. Use OLT → Tools → Locate by MAC to verify.")
    return RedirectResponse(f"/admin/devices/profile/{pid}", 303)


@app.post("/admin/devices/profile/{pid}/assign", dependencies=ADMIN)
def profile_assign(request: Request, pid: int, field: str = Form(...), oid_col: str = Form(...),
                   div: float = Form(1), unit: str = Form("dbm"), back: str = Form("/admin/devices"),
                   db=Depends(get_db)):
    p = db.get(OltProfile, pid)
    if p and field in dict(oltlib.FIELDS):
        oids = profile_dict(p)["oids"]
        oids[field] = dict(oid=oid_col.strip("."), div=div or 1, unit=unit)
        p.oids = json.dumps(oids)
        db.commit()
        flash(request, f"Saved '{field}' → {oid_col}")
    return RedirectResponse(back if back.startswith("/admin/") else "/admin/devices", 303)


@app.post("/admin/devices/profile-new", dependencies=ADMIN)
def profile_new(request: Request, name: str = Form("New profile"), db=Depends(get_db)):
    p = OltProfile(name=name.strip() or "New profile", vendor="Other", index_template="{ifindex}", oids="{}",
                   status_map="1=Online,2=Offline")
    db.add(p)
    db.commit()
    return RedirectResponse(f"/admin/devices/profile/{p.id}", 303)


@app.post("/admin/devices/profile/{pid}/delete", dependencies=ADMIN)
def profile_delete(request: Request, pid: int, db=Depends(get_db)):
    p = db.get(OltProfile, pid)
    if p:
        db.query(OLT).filter_by(profile_id=pid).update({"profile_id": None})
        db.delete(p)
        db.commit()
        flash(request, "Profile deleted.")
    return RedirectResponse("/admin/devices", 303)


# ================================================================ admin: settings
@app.get("/admin/settings", dependencies=ADMIN)
def settings_page(request: Request):
    tok = get_setting("tg_token")
    return render(request, "admin_settings.html", tg_token_masked=(tok[:6] + "…" + tok[-4:]) if tok else "",
                  tg_chat=get_setting("tg_chat_id"), seen=telegram_bot.seen_chats, oui_n=oui.size(),
                  title=get_setting("site_title", "Customer Support Portal"),
                  public_suggest=get_setting("public_suggest", "1") == "1", ru_n=rusers.size())


@app.post("/admin/settings/general", dependencies=ADMIN)
def set_general(request: Request, site_title: str = Form(""), public_suggest: str = Form("")):
    set_setting("site_title", site_title.strip()[:80] or "Customer Support Portal")
    set_setting("public_suggest", "1" if public_suggest else "0")
    flash(request, "Saved.")
    return RedirectResponse("/admin/settings", 303)


@app.post("/admin/settings/password", dependencies=ADMIN)
def set_password(request: Request, old: str = Form(""), new: str = Form(""), db=Depends(get_db)):
    a = db.query(Admin).filter_by(username=request.session["admin"]).first()
    if not check_pw(old, a.password_hash) or len(new) < 8:
        flash(request, "Old password wrong, or new password shorter than 8 characters.", "err")
    else:
        a.password_hash = hash_pw(new)
        db.commit()
        flash(request, "Password changed.")
    return RedirectResponse("/admin/settings", 303)


@app.post("/admin/settings/oui", dependencies=ADMIN)
async def set_oui(request: Request, file: UploadFile = File(None)):
    try:
        if file is not None and file.filename:
            n = oui.save_upload(await file.read())
        else:
            n = oui.update()
        flash(request, f"OUI database loaded: {n} vendors.")
    except Exception as e:
        flash(request, f"OUI update failed: {e}", "err")
    return RedirectResponse("/admin/settings", 303)


@app.post("/admin/settings/telegram", dependencies=ADMIN)
def set_telegram(request: Request, action: str = Form("save"), token: str = Form(""), chat_id: str = Form("")):
    if action == "remove":
        set_setting("tg_token", "")
        set_setting("tg_chat_id", "")
        flash(request, "Telegram settings removed.")
    else:
        if token.strip():
            set_setting("tg_token", token.strip())
        if chat_id.strip():
            set_setting("tg_chat_id", chat_id.strip())
        if action == "test":
            try:
                telegram_bot.send("✅ Test message from the support portal.")
                flash(request, "Test message sent. Check your Telegram group.")
            except Exception as e:
                flash(request, f"Telegram error: {e}", "err")
        else:
            flash(request, "Telegram settings saved.")
    return RedirectResponse("/admin/settings", 303)
