"""Multi-vendor EPON/GPON OLT correlation engine:
Matches CCR PPPoE Router WAN MAC -> OLT FDB / ONU MAC table -> PON Port & ONU Index -> Rx/Tx Power, Distance, Brand & Status."""
import re
import time
from concurrent.futures import ThreadPoolExecutor

import oui
import snmp

FDB_PORT = "1.3.6.1.2.1.17.4.3.1.2"          # dot1dTpFdbPort
QFDB_PORT = "1.3.6.1.2.1.17.7.1.2.2.1.2"     # dot1qTpFdbPort  (index: <fdbId/vlan>.<mac>)
BASEPORT_IF = "1.3.6.1.2.1.17.1.4.1.2"       # dot1dBasePortIfIndex
BDCOM_FDB = "1.3.6.1.4.1.3320.152.1.1.3"     # BDCOM nmsEponFdbMacAddress (index: <ifindex>.<vlan>.<mac_dec>)
IF_DESCR, IF_OPER, IF_NAME, IF_ALIAS = (
    "1.3.6.1.2.1.2.2.1.2",
    "1.3.6.1.2.1.2.2.1.8",
    "1.3.6.1.2.1.31.1.1.1.1",
    "1.3.6.1.2.1.31.1.1.1.18",
)

FIELDS = [
    ("status", "ONU status"),
    ("rx", "ONU Rx power (dBm)"),
    ("tx", "ONU Tx power (dBm)"),
    ("olt_rx", "OLT Rx power of this ONU (dBm)"),
    ("distance", "Distance (m)"),
    ("mac", "ONU MAC / Serial (SN)"),
    ("model", "ONU model"),
    ("vendor", "ONU vendor / brand"),
    ("name", "ONU name / description"),
    ("temp", "Temperature"),
    ("voltage", "Voltage"),
    ("uptime", "Online time / last event"),
    ("uni_speed", "ONU LAN port speed (Mbps)"),
    ("uni_status", "ONU LAN port status"),
]
KIND = {
    "rx": "power", "tx": "power", "olt_rx": "power",
    "distance": "num", "temp": "num", "voltage": "num", "uni_speed": "num",
    "status": "status", "mac": "mac",
}
UNITS = {"distance": "m", "temp": "°C", "voltage": "V", "uni_speed": "Mbps"}
ONLINE_WORDS = ("online", "up", "active", "working", "registered", "authenticated", "auth", "1")
NUMTYPES = ("INTEGER", "Integer32", "Gauge32", "Unsigned32", "Counter32", "Counter64")
SKIP_NAME = re.compile(r'(?i)^(gi|ge|xe|te|ten|gigabit|fast|ethernet|port-?channel|trunk|vlan|uplink|eth|ae|bridge|lo|null| tg|xge)')
ONU_IF = re.compile(r'^(?P<pre>.*?)(?P<pon>\d+(?:/\d+)+)[:.](?P<onu>\d+)$')
PON_IF = re.compile(r'^(?P<pre>[A-Za-z][A-Za-z_\- ]*?)\s*(?P<pon>\d+(?:/\d+)+)$')


def parse_status_map(s):
    d = {}
    for part in (s or "").split(","):
        if "=" in part:
            k, v = part.split("=", 1)
            d[k.strip()] = v.strip()
    return d


def parse_port(name):
    """Extract slot, pon, onu from interface names like EPON0/1:12, GPON 0/2/3:5, epon0/4.8, etc."""
    if not name:
        return None
    m = re.search(r'(\d+)/(\d+)/(\d+)[:.](\d+)', name)
    if m:
        return dict(slot=int(m[2]), pon=int(m[3]), onu=int(m[4]), frame=int(m[1]))
    m = re.search(r'(\d+)/(\d+)[:.](\d+)', name)
    if m:
        return dict(slot=int(m[1]), pon=int(m[2]), onu=int(m[3]))
    m = re.search(r'(\d+)/(\d+)/(\d+)', name)
    if m:
        return dict(slot=int(m[1]), pon=int(m[2]), onu=int(m[3]))
    m = re.search(r'(?i)pon\s*(\d+)[:./](\d+)', name)
    if m:
        return dict(slot=0, pon=int(m[1]), onu=int(m[2]))
    return None


def parse_pon_only(name):
    """Extract slot and pon when an FDB entry points to a PON port (e.g. EPON0/1) instead of EPON0/1:12."""
    if not name:
        return None
    m = re.search(r'(\d+)/(\d+)/(\d+)$', name.strip())
    if m:
        return dict(slot=int(m[2]), pon=int(m[3]))
    m = re.search(r'(\d+)/(\d+)$', name.strip())
    if m:
        return dict(slot=int(m[1]), pon=int(m[2]))
    return None


# ------------------------------------------------------------------ L2: MAC -> port (+VLAN)
def fdb_port(dev, mac):
    """Locate customer router MAC in OLT FDB / Bridge MIB / Q-Bridge MIB / BDCOM FDB.
    Returns (bridge_port_or_ifindex, vlan_id_or_None, is_direct_ifindex)."""
    dec = snmp.mac_dec(mac)
    if not dec:
        return None, None, False
    variants = [dev] + [dict(dev, community=f"{dev['community']}@{v}") for v in dev.get("vlans", [])]
    # 1. Direct dot1dTpFdbPort GET
    for idx, d in enumerate(variants):
        try:
            res = snmp.get(d, [f"{FDB_PORT}.{dec}"], timeout=8)
        except Exception:
            res = {}
        for _, (_, v) in res.items():
            n = snmp.num(v)
            if n and n > 0:
                vlan_hint = int(dev["vlans"][idx - 1]) if idx > 0 and dev["vlans"][idx - 1].isdigit() else None
                return int(n), vlan_hint, False
    # 2. Q-BRIDGE-MIB dot1qTpFdbPort walk (<vlan>.<mac_dec>)
    try:
        for o, _, v in snmp.walk(dev, QFDB_PORT, timeout=25):
            if o.endswith("." + dec):
                n = snmp.num(v)
                if n and n > 0:
                    rest = o[len(QFDB_PORT) + 1:-(len(dec) + 1)]
                    return int(n), (int(rest) if rest.isdigit() else None), False
    except Exception:
        pass
    # 3. BDCOM Enterprise FDB table (1.3.6.1.4.1.3320.152.1.1.3) where index is <ifIndex>.<vlan>.<mac_dec>
    if (dev.get("vendor") or "").upper() in ("BDCOM", "DBC/HSGQ", "OTHER") or "3320" in (dev.get("profile", {}).get("enterprise_oid") or ""):
        try:
            for o, t, v in snmp.walk(dev, BDCOM_FDB, timeout=25):
                if o.endswith("." + dec):
                    rest = o[len(BDCOM_FDB) + 1:-(len(dec) + 1)].split(".")
                    if len(rest) >= 2 and rest[0].isdigit():
                        ix = int(rest[0])
                        vl = int(rest[1]) if rest[1].isdigit() else None
                        return ix, vl, True
                elif snmp.val_mac(t, v) == mac:
                    rest = o[len(BDCOM_FDB) + 1:].split(".")
                    if rest and rest[0].isdigit():
                        ix = int(rest[0])
                        vl = int(rest[1]) if len(rest) > 1 and rest[1].isdigit() else None
                        return ix, vl, True
        except Exception:
            pass
    return None, None, False


def port_ifindex(dev, port):
    try:
        for _, (_, v) in snmp.get(dev, [f"{BASEPORT_IF}.{port}"], timeout=8).items():
            n = snmp.num(v)
            if n:
                return int(n)
    except Exception:
        pass
    return port


def if_info(dev, ix):
    try:
        r = snmp.get(dev, [f"{IF_NAME}.{ix}", f"{IF_DESCR}.{ix}", f"{IF_OPER}.{ix}", f"{IF_ALIAS}.{ix}"], timeout=10)
    except Exception:
        r = {}
    g = lambda base: (r.get(f"{base}.{ix}") or (None, ""))[1]
    oper = snmp.num(g(IF_OPER))
    return dict(
        name=g(IF_NAME) or g(IF_DESCR) or f"ifIndex.{ix}",
        alias=g(IF_ALIAS),
        link={1: "up", 2: "down"}.get(int(oper)) if oper else None,
    )


def suffix_for(tpl, ix, pp):
    ctx = dict(
        ifindex=ix or 0,
        slot=(pp or {}).get("slot", 0),
        pon=(pp or {}).get("pon", 0),
        onu=(pp or {}).get("onu", 0),
    )
    try:
        return (tpl or "{ifindex}").format(**ctx)
    except Exception:
        return str(ix or 0)


_ifn_cache = {}


def _ifname_map(dev):
    k = (dev["host"], dev.get("port", 161))
    c = _ifn_cache.get(k)
    if c and time.time() - c[0] < 600:
        return c[1]
    m = {}
    try:
        for o, _, v in snmp.walk(dev, IF_NAME, timeout=60):
            m[v.lower()] = o.rsplit(".", 1)[1]
        if not m:
            for o, _, v in snmp.walk(dev, IF_DESCR, timeout=60):
                m[v.lower()] = o.rsplit(".", 1)[1]
    except Exception:
        pass
    _ifn_cache[k] = (time.time(), m)
    return m


def pon_ifindex(dev, slot, pon):
    m = _ifname_map(dev)
    for pre in ("epon", "pon", "gpon", "xpon"):
        for sep in ("", " ", "0/"):
            ix = m.get(f"{pre}{sep}{slot}/{pon}") or m.get(f"{pre}{sep}{pon}")
            if ix:
                return ix
    for name, ix in m.items():
        if ":" not in name and "pon" in name and (name.endswith(f"{slot}/{pon}") or name.endswith(f"/{pon}")):
            return ix
    return None


def _mac_close(m1, m2):
    """Check if two MAC addresses are identical or within ±3 on the last byte (HGU ONU WAN MAC vs PON MAC)."""
    m1, m2 = snmp.norm_mac(m1), snmp.norm_mac(m2)
    if not m1 or not m2:
        return False
    if m1 == m2:
        return True
    if m1[:14] == m2[:14]:
        try:
            return abs(int(m1[15:17], 16) - int(m2[15:17], 16)) <= 3
        except Exception:
            return False
    return False


def _decode_onu_suffix(dev, prof, suf):
    """Given an OID index suffix from an ONU MAC table walk (e.g. '100663564' or '2.5' or '16777217.3'),
    resolve (ifindex, info_dict, pp_dict, suffix_override)."""
    parts = [p for p in str(suf).strip(".").split(".") if p.isdigit()]
    if len(parts) == 1:
        ix = int(parts[0])
        info = if_info(dev, ix)
        pp = parse_port(info["name"])
        if not pp:
            # C-Data / Huawei / BDCOM bit-packed ONU index fallback
            if ix > 0x01000000:
                pon = (ix >> 8) & 0xFF
                onu = ix & 0xFF
                if 1 <= pon <= 32 and 1 <= onu <= 128:
                    pp = dict(slot=0, pon=pon, onu=onu)
                    if info["name"].startswith("ifIndex"):
                        info["name"] = f"PON0/{pon}:{onu}"
        return ix, info, pp, str(ix)
    elif len(parts) == 2:
        p1, p2 = int(parts[0]), int(parts[1])
        if p1 <= 32 and p2 <= 128:
            # V-SOL style {pon}.{onu}
            pp = dict(slot=0, pon=p1, onu=p2)
            return p1 * 1000 + p2, dict(name=f"PON0/{p1}:{p2}", alias="", link="up"), pp, f"{p1}.{p2}"
        else:
            # Huawei / ZTE style {pon_ifindex}.{onu}
            info = if_info(dev, p1)
            pon_pp = parse_pon_only(info["name"]) or dict(slot=0, pon=1)
            pp = dict(slot=pon_pp["slot"], pon=pon_pp["pon"], onu=p2)
            info["name"] = f"{info['name']}:{p2}"
            return p1, info, pp, f"{p1}.{p2}"
    elif len(parts) >= 3:
        s, p, o = int(parts[-3]), int(parts[-2]), int(parts[-1])
        pp = dict(slot=s, pon=p, onu=o)
        return o, dict(name=f"PON{s}/{p}:{o}", alias="", link="up"), pp, str(suf)
    return None, None, None, None


# ------------------------------------------------------------------ per-ONU values
def _conv(f, c, typ, v, smap):
    if v is None or str(v).strip() == "":
        return None
    div = float(c.get("div") or 1)
    kind = KIND.get(f, "str")
    conf = c.get("conf") or ""
    if kind == "power":
        unit = c.get("unit") or "dbm"
        if unit == "dbm_str":
            dbm = snmp.parse_dbm_str(v)
        else:
            n = snmp.num(v)
            dbm = snmp.to_dbm(n, div, unit) if n is not None else snmp.parse_dbm_str(v)
        if dbm is None:
            return None
        return dict(value=dbm, unit="dBm", conf=conf, quality=snmp.rx_quality(dbm) if f in ("rx", "olt_rx") else None)
    if kind == "num":
        n = snmp.num(v)
        if n is None or n < 0 or n in (2147483647, 65535):
            return None
        x = round(n / div, 2)
        return dict(value=int(x) if x == int(x) else x, unit=UNITS.get(f, ""), conf=conf)
    if kind == "status":
        n = snmp.num(v)
        txt = smap.get(str(int(n)) if n is not None else str(v).strip(), str(v).strip())
        return dict(value=txt, conf=conf, online=any(w in txt.lower() for w in ONLINE_WORDS))
    if kind == "mac":
        m = snmp.val_mac(typ, v) or str(v).strip()
        return dict(value=m, conf=conf) if m else None
    return dict(value=str(v).strip(), conf=conf)


def onu_details(dev, prof, ix, pp, suffix_override=None):
    """Fetch all optical/hardware metrics for a located ONU, trying primary + fallback index templates & alt OIDs."""
    tpl = prof.get("index_template") or "{ifindex}"
    primary_suffix = suffix_override or suffix_for(tpl, ix, pp)
    candidate_suffixes = [primary_suffix]
    if ix and str(ix) not in candidate_suffixes:
        candidate_suffixes.append(str(ix))
    if pp:
        for alt_s in (f"{pp['pon']}.{pp['onu']}", f"{pp['slot']}.{pp['pon']}.{pp['onu']}", f"{ix}.{pp['onu']}"):
            if alt_s not in candidate_suffixes:
                candidate_suffixes.append(alt_s)

    cfg = {f: c for f, c in (prof.get("oids") or {}).items() if (c or {}).get("oid")}
    smap = prof.get("status_map") or {}
    out, raw = {}, []

    # 1. Try candidate suffixes on primary OIDs
    for sfx in candidate_suffixes:
        missing = {f: c for f, c in cfg.items() if f not in out and c.get("index") != "pon_mac"}
        if not missing:
            break
        req = {f"{c['oid'].strip('.')}.{sfx}": f for f, c in missing.items()}
        try:
            vals = snmp.get(dev, list(req), timeout=10) if req else {}
        except Exception:
            vals = {}
        for oid, f in req.items():
            if oid in vals:
                e = _conv(f, cfg[f], vals[oid][0], vals[oid][1], smap)
                if e is not None and e.get("value") is not None:
                    out[f] = e
                    raw.append(dict(field=f, oid=oid, raw=vals[oid][1], conf=e.get("conf")))
        if "rx" in out and "mac" in out:
            primary_suffix = sfx
            break

    # 2. Try fallback/alternate OIDs ('alt' list) for any still-missing fields
    missing_alt = {f: c for f, c in cfg.items() if f not in out and c.get("alt")}
    if missing_alt:
        alt_req = {}
        for f, c in missing_alt.items():
            for alt_oid in c.get("alt") or []:
                for sfx in candidate_suffixes[:2]:
                    alt_req[f"{alt_oid.strip('.')}.{sfx}"] = (f, c)
        try:
            vals_alt = snmp.get(dev, list(alt_req), timeout=10) if alt_req else {}
        except Exception:
            vals_alt = {}
        for oid, (f, c) in alt_req.items():
            if f not in out and oid in vals_alt:
                e = _conv(f, c, vals_alt[oid][0], vals_alt[oid][1], smap)
                if e is not None and e.get("value") is not None:
                    out[f] = e
                    raw.append(dict(field=f, oid=oid, raw=vals_alt[oid][1], conf=e.get("conf")))

    # 3. Tables indexed by <PON ifIndex>.<ONU MAC> (e.g. BDCOM distance fallback .101.11.1.1.7)
    need_pm = {f: c for f, c in cfg.items() if c.get("index") in ("pon_mac", "auto") and f not in out}
    onu_mac_val = (out.get("mac") or {}).get("value")
    if need_pm and onu_mac_val and pp:
        pi = pon_ifindex(dev, pp["slot"], pp["pon"])
        mdec = snmp.mac_dec(onu_mac_val)
        if pi and mdec:
            sfx2 = f"{pi}.{mdec}"
            req2 = {}
            for f, c in need_pm.items():
                req2[f"{c['oid'].strip('.')}.{sfx2}"] = (f, c)
                for ao in c.get("alt") or []:
                    req2[f"{ao.strip('.')}.{sfx2}"] = (f, c)
            try:
                vals2 = snmp.get(dev, list(req2), timeout=10)
            except Exception:
                vals2 = {}
            for oid, (f, c) in req2.items():
                if f not in out and oid in vals2:
                    e = _conv(f, c, vals2[oid][0], vals2[oid][1], smap)
                    if e is not None and e.get("value") is not None:
                        out[f] = e
                        raw.append(dict(field=f, oid=oid, raw=vals2[oid][1], conf=e.get("conf")))

    return dict(fields=out, suffix=primary_suffix, raw=raw)


def locate_one(dev, prof, mac, onu_mac=None):
    """Correlate CCR PPPoE Router WAN MAC (or manual ONU MAC) against this OLT."""
    ix = info = pp = suffix_override = None
    vlan = None
    target_mac = snmp.norm_mac(mac) if mac else None
    target_onu_mac = snmp.norm_mac(onu_mac) if onu_mac else None

    # Step 1: FDB / Bridge MAC table lookup for Customer Router WAN MAC
    if target_mac:
        port, vlan, is_direct = fdb_port(dev, target_mac)
        if port:
            ix = port if is_direct else port_ifindex(dev, port)
            info = if_info(dev, ix)
            pp = parse_port(info["name"])
            if not pp and SKIP_NAME.match(info["name"] or ""):
                # Learned on an uplink/trunk port, ignore
                ix = info = None

    # Step 2: Walk ONU MAC table if FDB was not found, or if FDB only gave a PON port without ONU ID
    mac_cfg_obj = (prof.get("oids") or {}).get("mac") or {}
    mac_oids = [mac_cfg_obj.get("oid")] + (mac_cfg_obj.get("alt") or [])
    mac_oids = [o.strip(".") for o in mac_oids if o and o.strip(".")]

    if (ix is None or pp is None) and (target_onu_mac or target_mac) and mac_oids:
        pon_filter = parse_pon_only(info["name"]) if info else None
        for m_oid in mac_oids:
            try:
                rows = snmp.walk(dev, m_oid, timeout=35)
            except Exception:
                continue
            if not rows:
                continue
            for o, t, v in rows:
                vmac = snmp.val_mac(t, v)
                if not vmac:
                    continue
                matched = (
                    (target_onu_mac and vmac == target_onu_mac)
                    or (target_mac and _mac_close(vmac, target_mac))
                )
                if matched:
                    suf = o[len(m_oid) + 1:]
                    cand_ix, cand_info, cand_pp, cand_suf = _decode_onu_suffix(dev, prof, suf)
                    if pon_filter and cand_pp and cand_pp.get("pon") != pon_filter.get("pon"):
                        continue
                    ix, info, pp, suffix_override = cand_ix, cand_info, cand_pp, cand_suf
                    break
            if ix is not None and pp is not None:
                break

    if ix is None:
        return None

    det = onu_details(dev, prof, ix, pp, suffix_override=suffix_override)
    f = det["fields"]

    # Enrich ONU Brand & Vendor from both SNMP Vendor/Model OIDs and OUI lookup of ONU MAC/SN
    onu_hw_mac = (f.get("mac") or {}).get("value") or target_onu_mac
    oui_info = oui.describe(onu_hw_mac) if onu_hw_mac else None
    oui_brand = (oui_info or {}).get("short") or (oui_info or {}).get("vendor")
    snmp_vendor = (f.get("vendor") or {}).get("value")
    snmp_model = (f.get("model") or {}).get("value")
    brand_parts = [x for x in (snmp_vendor or oui_brand, snmp_model) if x]
    onu_brand_full = " · ".join(dict.fromkeys(brand_parts)) or oui_brand or dev.get("vendor") or "Standard ONU"

    return dict(
        found=True,
        olt=dev["name"],
        olt_id=dev.get("id"),
        vendor=dev.get("vendor"),
        host=dev.get("host"),
        profile=prof.get("name"),
        ifindex=ix,
        ifname=info["name"] if info else f"ONU-{ix}",
        alias=(info or {}).get("alias") or (f.get("name") or {}).get("value") or "",
        link=(info or {}).get("link") or ("up" if (f.get("status") or {}).get("online") else None),
        vlan=vlan,
        pon=f"{pp['slot']}/{pp['pon']}" if pp else None,
        onu=pp["onu"] if pp else None,
        onu_mac=onu_hw_mac,
        onu_brand=oui_brand or snmp_vendor,
        onu_brand_full=onu_brand_full,
        rx_dbm=(f.get("rx") or {}).get("value"),
        tx_dbm=(f.get("tx") or {}).get("value"),
        olt_rx_dbm=(f.get("olt_rx") or {}).get("value"),
        distance_m=(f.get("distance") or {}).get("value"),
        fields=f,
        suffix=det["suffix"],
        raw=det["raw"],
        configured=bool(prof.get("oids")) and any((c or {}).get("oid") for c in prof["oids"].values()),
    )


def locate(olts, mac, onu_mac=None):
    if not olts:
        return None

    def work(o):
        try:
            r = locate_one(o, o["profile"], mac, onu_mac)
            return r, None
        except Exception as e:
            return None, str(e)

    with ThreadPoolExecutor(max_workers=min(6, len(olts))) as ex:
        res = list(ex.map(work, olts))
    checked = [
        dict(
            olt=o["name"],
            olt_id=o.get("id"),
            vendor=o.get("vendor"),
            host=o.get("host"),
            state="found" if r else ("error" if e else "not_found"),
            detail=e or "",
        )
        for o, (r, e) in zip(olts, res)
    ]
    errs = [f"{c['olt']}: {c['detail']}" for c in checked if c["detail"]]
    hits = [r for r, _ in res if r]
    if hits:
        # Prefer hit that resolved a specific PON/ONU over generic interface
        hits.sort(key=lambda h: (h.get("pon") is None, h.get("rx_dbm") is None))
        r = hits[0]
        r["errors"], r["checked"] = errs, checked
        if len(hits) > 1:
            r["multi"] = [f"{h['olt']} {h['ifname']}" for h in hits]
        return r
    return dict(found=False, errors=errs, searched=len(olts), checked=checked)


def sys_info(dev):
    r = snmp.get(dev, ["1.3.6.1.2.1.1.5.0", "1.3.6.1.2.1.1.1.0", "1.3.6.1.2.1.1.3.0"])
    g = lambda k: (r.get(k) or (None, ""))[1]
    return dict(name=g("1.3.6.1.2.1.1.5.0"), descr=g("1.3.6.1.2.1.1.1.0")[:120], uptime=g("1.3.6.1.2.1.1.3.0"))


# ------------------------------------------------------------------ dashboard snapshot (standard IF-MIB + enterprise fallback)
def _pon_sort(p):
    return [int(x) for x in re.findall(r"\d+", str(p.get("pon") or "0"))]


def snapshot(dev):
    """ONU online counts per PON from ifOperStatus of the logical ONU interfaces (EPON0/1:24) and PON port state."""
    names = {o.rsplit(".", 1)[1]: v for o, _, v in snmp.walk(dev, IF_NAME, timeout=60)}
    oper = {o.rsplit(".", 1)[1]: int(snmp.num(v) or 0) for o, _, v in snmp.walk(dev, IF_OPER, timeout=60)}
    s = snmp.get(dev, ["1.3.6.1.2.1.1.3.0", "1.3.6.1.2.1.1.5.0"])
    ticks = snmp.num((s.get("1.3.6.1.2.1.1.3.0") or (0, ""))[1])
    pons, total, online = {}, 0, 0
    for ix, name in names.items():
        m = ONU_IF.match(name)
        if m:
            p = pons.setdefault(m["pon"], dict(pon=m["pon"], up=None, total=0, online=0))
            p["total"] += 1
            on = oper.get(ix) == 1
            p["online"] += on
            total += 1
            online += on
            continue
        m = PON_IF.match(name)
        if m and "pon" in m["pre"].lower():
            p = pons.setdefault(m["pon"], dict(pon=m["pon"], up=None, total=0, online=0))
            p["up"] = oper.get(ix) == 1
    for p in pons.values():
        if p["up"] is None:
            p["up"] = p["online"] > 0
    return dict(
        ok=True,
        sysname=(s.get("1.3.6.1.2.1.1.5.0") or (0, ""))[1],
        uptime=int(ticks / 100) if ticks else None,
        onu_total=total,
        onu_online=online,
        onu_supported=total > 0,
        pons=sorted(pons.values(), key=_pon_sort),
        if_count=len(names),
    )


# ------------------------------------------------------------------ Discover tools
def guess(typ, v):
    if snmp.val_mac(typ, v) and typ in ("Hex-STRING", "STRING"):
        return "MAC address / SN"
    if typ == "STRING" and "dbm" in v.lower():
        return "power as text (use 'dBm from text')"
    n = snmp.num(v) if typ in NUMTYPES else None
    if n is None:
        return "text" if typ == "STRING" else ""
    if -6000 <= n <= -500:
        return f"power? ÷100 = {n/100:.2f} dBm"
    if -600 < n <= -50:
        return f"power? ÷10 = {n/10:.1f} dBm"
    if -60 < n < -5:
        return f"power? = {n:.0f} dBm"
    if 5 <= n <= 40000:
        return "distance(m) / power in µW / other"
    if 0 <= n <= 10:
        return "status / enum?"
    return ""


def discover(dev, start_oid, suffix):
    rows = snmp.walk(dev, start_oid, timeout=120)
    res = []
    for o, t, v in rows:
        if o.endswith("." + suffix):
            res.append(dict(column=o[:-len(suffix) - 1], type=t, value=v, guess=guess(t, v)))
    return res, len(rows)


def resolve_suffix(dev, prof, mac):
    port, _, is_direct = fdb_port(dev, mac)
    if not port:
        return None, None
    ix = port if is_direct else port_ifindex(dev, port)
    info = if_info(dev, ix)
    pp = parse_port(info["name"])
    return suffix_for(prof.get("index_template"), ix, pp), info["name"]


def _fl(x):
    try:
        return float(str(x).lower().replace("dbm", "").replace("m", "").strip())
    except Exception:
        return None


def match_known(rows, known):
    """Mark discover rows whose value equals a value the admin read from the OLT CLI."""
    kn = {k: _fl(known.get(k)) for k in ("rx", "tx", "olt_rx", "distance", "temp", "voltage", "uni_speed")}
    kmac = snmp.norm_mac(known.get("mac", "")) if known.get("mac") else None
    best = {}

    def add(r, field, div, unit="dbm"):
        r.setdefault("matches", []).append(dict(field=field, div=div, unit=unit))
        best.setdefault(field, dict(field=field, col=r["column"], div=div, unit=unit, value=r["value"]))

    for r in rows:
        t, v = r["type"], r["value"]
        n = snmp.num(v) if t in NUMTYPES else None
        dtext = snmp.parse_dbm_str(v) if t == "STRING" else None
        for f in ("rx", "tx", "olt_rx"):
            if dtext is not None and kn[f] is not None and abs(dtext - kn[f]) <= 0.06:
                add(r, f, 1, "dbm_str")
        if n is not None:
            for f in ("rx", "tx", "olt_rx"):
                x = kn[f]
                if x is None or (x * n < 0) or n == 0:
                    continue
                hit = False
                for div in (1, 10, 100, 1000):
                    if abs(n / div - x) <= (0.51 if div == 1 else 0.051):
                        add(r, f, div, "dbm")
                        hit = True
                        break
                if not hit and x >= -40:
                    uw = 1000 * 10 ** (x / 10)
                    for div in (1, 10, 100):
                        if n > 0 and abs(n / div - uw) <= max(0.03 * uw, 0.5):
                            add(r, f, div, "uw")
                            break
            if kn["distance"] is not None and n > 0:
                for div in (1, 10):
                    if abs(n / div - kn["distance"]) <= 2:
                        add(r, "distance", div)
                        break
            if kn["temp"] is not None:
                for div in (1, 10, 100, 256):
                    if abs(n / div - kn["temp"]) <= (0.6 if div == 1 else 0.06):
                        add(r, "temp", div)
                        break
            if kn["voltage"] is not None:
                for div in (1, 10, 100, 1000, 10000):
                    if abs(n / div - kn["voltage"]) <= 0.02:
                        add(r, "voltage", div)
                        break
            if kn["uni_speed"] is not None and n == kn["uni_speed"]:
                add(r, "uni_speed", 1)
        if kmac and snmp.val_mac(t, v) == kmac:
            add(r, "mac", 1)
        if n is None and t in ("STRING", "Hex-STRING"):
            for f in ("model", "vendor"):
                k = (known.get(f) or "").strip().lower()
                if k and k in v.lower():
                    add(r, f, 1)
    return list(best.values())


# ------------------------------------------------------------------ weak-ONU scan
def scan(dev, prof):
    cfg = prof.get("oids") or {}
    rx = cfg.get("rx") or {}
    if not rx.get("oid"):
        raise ValueError("Set the 'ONU Rx power' OID in the profile first.")
    base = rx["oid"].strip(".")
    names = {o.rsplit(".", 1)[1]: v for o, _, v in snmp.walk(dev, IF_NAME, timeout=90)}
    oper = {o.rsplit(".", 1)[1]: int(snmp.num(v) or 0) for o, _, v in snmp.walk(dev, IF_OPER, timeout=90)}
    st, smap = {}, prof.get("status_map") or {}
    sc = cfg.get("status") or {}
    if sc.get("oid"):
        sb = sc["oid"].strip(".")
        try:
            for o, _, v in snmp.walk(dev, sb, timeout=90):
                n = snmp.num(v)
                txt = smap.get(str(int(n)) if n is not None else v, v)
                st[o[len(sb) + 1:]] = (txt, any(w in txt.lower() for w in ONLINE_WORDS))
        except Exception:
            pass
    rows = []
    for o, _, v in snmp.walk(dev, base, timeout=120):
        suf = o[len(base) + 1:]
        name = names.get(suf)
        if not name:
            _, inf, pp, _ = _decode_onu_suffix(dev, prof, suf)
            name = (inf or {}).get("name") or f"ONU-{suf}"
        m = ONU_IF.match(name)
        n = snmp.num(v)
        unit = rx.get("unit") or "dbm"
        if unit == "dbm_str":
            dbm = snmp.parse_dbm_str(v)
        else:
            dbm = snmp.to_dbm(n, rx.get("div") or 1, unit) if n is not None else snmp.parse_dbm_str(v)
        s = st.get(suf)
        online = s[1] if s else (oper.get(suf) == 1 if suf in oper else (dbm is not None))
        rows.append(dict(
            name=name,
            pon=m["pon"] if m else "?",
            rx=dbm,
            quality=snmp.rx_quality(dbm),
            status=s[0] if s else ({True: "up", False: "down"}.get(online)),
            online=online,
        ))
    rows.sort(key=lambda r: (r["rx"] is None, r["rx"] if r["rx"] is not None else 0))
    pons = {}
    for r in rows:
        p = pons.setdefault(r["pon"], dict(pon=r["pon"], total=0, weak=0, bad=0, nodata=0, offline=0))
        p["total"] += 1
        p["bad"] += r["quality"] == "bad"
        p["weak"] += r["quality"] == "weak"
        p["nodata"] += r["rx"] is None
        p["offline"] += r["online"] is False
    return dict(rows=rows[:500], total=len(rows), pons=sorted(pons.values(), key=_pon_sort))


# ------------------------------------------------------------------ OLT detail page
IF_HIGHSPEED, IF_HCIN, IF_HCOUT = "1.3.6.1.2.1.31.1.1.1.15", "1.3.6.1.2.1.31.1.1.1.6", "1.3.6.1.2.1.31.1.1.1.10"


def _col(dev, base, timeout=60):
    return {o.rsplit(".", 1)[1]: v for o, _, v in snmp.walk(dev, base, timeout=timeout)}


def details(dev):
    names, oper, alias = _col(dev, IF_NAME), _col(dev, IF_OPER), _col(dev, IF_ALIAS)
    speed = _col(dev, IF_HIGHSPEED)
    s = snmp.get(dev, ["1.3.6.1.2.1.1.5.0", "1.3.6.1.2.1.1.1.0", "1.3.6.1.2.1.1.3.0"])
    g = lambda k: (s.get(k) or (None, ""))[1]
    ticks = snmp.num(g("1.3.6.1.2.1.1.3.0"))
    ports, onus, pons = [], [], {}
    for ix, name in sorted(names.items(), key=lambda kv: int(kv[0]) if kv[0].isdigit() else 0):
        up = int(snmp.num(oper.get(ix)) or 0) == 1
        m = ONU_IF.match(name)
        if m:
            onus.append(dict(name=name, pon=m["pon"], onu=int(m["onu"]), up=up, alias=alias.get(ix, ""), ix=ix))
            p = pons.setdefault(m["pon"], dict(pon=m["pon"], up=None, total=0, online=0))
            p["total"] += 1
            p["online"] += up
            continue
        m = PON_IF.match(name)
        if m and "pon" in m["pre"].lower():
            p = pons.setdefault(m["pon"], dict(pon=m["pon"], up=None, total=0, online=0))
            p["up"] = up
            p["ix"] = ix
            continue
        if SKIP_NAME.match(name) or "ge" in name.lower() or "xe" in name.lower():
            ports.append(dict(name=name, up=up, speed=int(snmp.num(speed.get(ix)) or 0), alias=alias.get(ix, ""), ix=ix))
    for p in pons.values():
        if p["up"] is None:
            p["up"] = p["online"] > 0
    return dict(
        sysname=g("1.3.6.1.2.1.1.5.0"),
        descr=g("1.3.6.1.2.1.1.1.0")[:160],
        uptime=int(ticks / 100) if ticks else None,
        ports=ports,
        onus=onus,
        pons=sorted(pons.values(), key=_pon_sort),
        if_count=len(names),
    )


def counters(dev, ixs):
    out = {}
    ixs = list(ixs)
    for k in range(0, len(ixs), 10):
        chunk = ixs[k:k + 10]
        oids = [f"{IF_HCIN}.{i}" for i in chunk] + [f"{IF_HCOUT}.{i}" for i in chunk]
        r = snmp.get(dev, oids)
        for i in chunk:
            a, b = r.get(f"{IF_HCIN}.{i}"), r.get(f"{IF_HCOUT}.{i}")
            out[i] = (int(snmp.num(a[1]) or 0) if a else 0, int(snmp.num(b[1]) or 0) if b else 0)
    return out
