"""Shared web helpers: templates, flash, rendering, password hashing, rate limiting, roles."""
import hashlib
import hmac
import re as _re
import secrets
import time
from zoneinfo import ZoneInfo

from fastapi import Request
from fastapi.templating import Jinja2Templates

from db import STATUS_LABEL, Alarm, SessionLocal, get_setting

templates = Jinja2Templates(directory="templates")
DHAKA = ZoneInfo("Asia/Dhaka")
templates.env.filters["dt"] = lambda d: (d.replace(tzinfo=ZoneInfo("UTC")).astimezone(DHAKA)
                                         .strftime("%d %b %Y, %I:%M %p") if d else "-")
templates.env.globals["STATUS_LABEL"] = STATUS_LABEL
ROLES = {"read": 1, "admin": 2, "super": 3}
ROLE_LABEL = {"super": "Super admin", "admin": "Admin", "read": "Read only"}
templates.env.globals["ROLE_LABEL"] = ROLE_LABEL
CATEGORIES = ["No internet", "Slow speed", "Frequent disconnect", "Billing / payment", "Other"]
VENDORS = ["BDCOM", "VSOL", "C-Data", "DBC/HSGQ", "Huawei", "ZTE", "FiberHome", "Nokia", "Ubiquiti", "Other"]


def hash_pw(p, salt=None):
    salt = salt or secrets.token_hex(16)
    return f"{salt}${hashlib.pbkdf2_hmac('sha256', p.encode(), salt.encode(), 200000).hex()}"


def check_pw(p, stored):
    try:
        salt, h = stored.split("$")
    except ValueError:
        return False
    return hmac.compare_digest(hash_pw(p, salt).split("$")[1], h)


_hits = {}


def limited(key, n, window):
    now = time.time()
    l = [t for t in _hits.get(key, []) if now - t < window]
    if len(l) >= n:
        _hits[key] = l
        return True
    l.append(now)
    _hits[key] = l
    return False


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def flash(request, msg, kind="ok"):
    f = request.session.get("flash", [])
    f.append([kind, msg])
    request.session["flash"] = f


def logo_url():
    ts = get_setting("logo_ts", "")
    return f"/branding/logo?v={ts}" if ts else None


TITLES = (
    ("/admin/devices/router", "Router details"),
    ("/admin/devices/olt", "OLT details"),
    ("/admin/devices", "Devices & OLT OIDs"),
    ("/admin/tickets", "Support Tickets"),
    ("/admin/complaints", "Support Tickets"),
    ("/admin/diagnose", "Diagnose Subscriber"),
    ("/admin/d", "Live Subscriber Diagnosis"),
    ("/admin/alarms", "Network Alarms"),
    ("/admin/audit", "Activity Audit Log"),
    ("/admin/settings", "Portal Settings"),
    ("/admin/staff", "Staff Accounts"),
    ("/admin/account", "My Account"),
    ("/admin/interfaces", "VLAN Interface Watch"),
    ("/admin/tunnels", "VPN Tunnels"),
    ("/admin/integrations", "Alert Integrations"),
    ("/admin", "NOC Dashboard"),
)


def render(request, name, **ctx):
    user = getattr(request.state, "user", None)
    role = (user or {}).get("role")
    ctx["flash"] = request.session.pop("flash", [])
    ctx["site_title"] = get_setting("site_title", "Network Operations")
    ctx["logo_url"] = logo_url()
    ctx["user"], ctx["role"] = user, role
    ctx["can_write"] = ROLES.get(role, 0) >= 2
    ctx["is_super"] = role == "super"
    ctx["is_admin"] = bool(user)
    ctx["path"] = request.url.path
    ctx["sound_default"] = get_setting("sound_enabled", "1")
    ctx["VENDORS"] = VENDORS
    ctx["CATEGORIES"] = CATEGORIES
    if user:
        with SessionLocal() as _db:
            ctx["alarm_count"] = _db.query(Alarm).filter(Alarm.cleared_at.is_(None)).count()
        ctx["admin_name"] = user["username"]
    if not ctx.get("title"):
        for pre, ttl in TITLES:
            if request.url.path.startswith(pre):
                ctx["title"] = ttl
                break
    return templates.TemplateResponse(request, name, ctx)


SUPER_PREFIX = ("/admin/settings", "/admin/staff", "/admin/integrations", "/admin/tunnels", "/admin/devices")
_VIEW_OK = _re.compile(r"^/admin/devices/(router|olt)/\d+/view$")


def required_role(path, method):
    if _VIEW_OK.match(path) or path.startswith("/admin/api/device/") or path.startswith("/admin/api/olt/"):
        return "read"
    if path.startswith("/admin/account") or path in ("/admin/api/layout", "/admin/api/alarm-state"):
        return "read"
    if path.startswith(SUPER_PREFIX):
        return "super"
    if method != "GET" and path.startswith("/admin/api/") and path in ("/admin/api/ping-custom",):
        return "read"
    if method != "GET":
        return "admin"
    return "read"
