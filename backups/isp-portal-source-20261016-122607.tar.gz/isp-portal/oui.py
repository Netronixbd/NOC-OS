"""MAC vendor lookup from the IEEE OUI list (data/oui.csv) + comprehensive built-in ISP Router/ONU OUI table."""
import csv
import os
import re
import threading

import httpx

PATH = "data/oui.csv"
URL = "https://standards-oui.ieee.org/oui/oui.csv"

# Built-in fallback OUI prefixes for common ISP Customer Routers & ONUs (TP-Link, Tenda, Netis, Mercusys,
# D-Link, Huawei, ZTE, BDCOM, V-SOL, C-Data, Nokia, FiberHome, MikroTik, Xiaomi, Cudy, Totolink, Asus, etc.)
BUILTIN_OUI = {
    # TP-Link
    "000AEB": "TP-Link", "001478": "TP-Link", "0019E0": "TP-Link", "001D0F": "TP-Link",
    "002127": "TP-Link", "0023CD": "TP-Link", "002586": "TP-Link", "002719": "TP-Link",
    "003192": "TP-Link", "005F67": "TP-Link", "0C8063": "TP-Link", "10FEED": "TP-Link",
    "14CC20": "TP-Link", "14CF92": "TP-Link", "14EBB6": "TP-Link", "18A6F7": "TP-Link",
    "18D6C7": "TP-Link", "1C3BF3": "TP-Link", "1C61B4": "TP-Link", "20DCE6": "TP-Link",
    "246968": "TP-Link", "2887BA": "TP-Link", "2C4D54": "TP-Link", "30B49E": "TP-Link",
    "30B5C2": "TP-Link", "34E894": "TP-Link", "388345": "TP-Link", "3C46D8": "TP-Link",
    "3C52A1": "TP-Link", "3C846A": "TP-Link", "40169F": "TP-Link", "403F8C": "TP-Link",
    "44B32D": "TP-Link", "480E73": "TP-Link", "503EAA": "TP-Link", "50C7BF": "TP-Link",
    "50D4F7": "TP-Link", "54A703": "TP-Link", "54AF97": "TP-Link", "54C80F": "TP-Link",
    "54E6FC": "TP-Link", "58D9D5": "TP-Link", "5C628B": "TP-Link", "5CA6E6": "TP-Link",
    "6032B1": "TP-Link", "60A4B7": "TP-Link", "60E327": "TP-Link", "645601": "TP-Link",
    "6466B3": "TP-Link", "647002": "TP-Link", "68FF7B": "TP-Link", "6C5AB0": "TP-Link",
    "704F57": "TP-Link", "74DA38": "TP-Link", "74DA88": "TP-Link", "784476": "TP-Link",
    "788CB5": "TP-Link", "7C8BCA": "TP-Link", "808917": "TP-Link", "8416F9": "TP-Link",
    "882593": "TP-Link", "8C210A": "TP-Link", "90F652": "TP-Link", "940C6D": "TP-Link",
    "94D9B3": "TP-Link", "98254A": "TP-Link", "984827": "TP-Link", "98DA55": "TP-Link",
    "98DAC4": "TP-Link", "9C216A": "TP-Link", "9CA2F4": "TP-Link", "A0F3C1": "TP-Link",
    "A42BB0": "TP-Link", "A84041": "TP-Link", "A8574E": "TP-Link", "AC15A2": "TP-Link",
    "AC84C6": "TP-Link", "B04E26": "TP-Link", "B09575": "TP-Link", "B0A7B9": "TP-Link",
    "B0BE76": "TP-Link", "B4B024": "TP-Link", "B8F883": "TP-Link", "BC4699": "TP-Link",
    "C006C3": "TP-Link", "C025E9": "TP-Link", "C04A00": "TP-Link", "C46E1F": "TP-Link",
    "C47154": "TP-Link", "C4E984": "TP-Link", "C83A35": "TP-Link", "CC32E5": "TP-Link",
    "D46E0E": "TP-Link", "D807B6": "TP-Link", "D80D17": "TP-Link", "D84732": "TP-Link",
    "DC6279": "TP-Link", "E005C5": "TP-Link", "E4C32A": "TP-Link", "E848B8": "TP-Link",
    "E865D4": "TP-Link", "E894F6": "TP-Link", "E8DE27": "TP-Link", "EC086B": "TP-Link",
    "EC172F": "TP-Link", "EC888F": "TP-Link", "F09FC2": "TP-Link", "F4EC38": "TP-Link",
    "F4F26D": "TP-Link", "F81A67": "TP-Link", "F8D111": "TP-Link", "FCECD8": "TP-Link",
    # Tenda
    "00B00C": "Tenda", "0440A9": "Tenda", "0495E6": "Tenda", "0840F3": "Tenda",
    "1869D8": "Tenda", "28F366": "Tenda", "500FF5": "Tenda", "58D56E": "Tenda",
    "B0DFC1": "Tenda", "C83A35": "Tenda", "CC2D21": "Tenda", "D83214": "Tenda",
    "E865D4": "Tenda", "EC3DFD": "Tenda",
    # Netis / Netcore
    "000AE2": "Netis", "048D38": "Netis", "081079": "Netis", "14CF8D": "Netis",
    "20F41B": "Netis", "44334C": "Netis", "647033": "Netis", "E4BEED": "Netis",
    # Mercusys
    "00E04C": "Realtek / Mercusys", "78A351": "Mercusys", "A86E84": "Mercusys",
    "C0C9E3": "Mercusys", "E848B8": "Mercusys",
    # Cudy / Totolink / Xiaomi / D-Link / Asus
    "7085C2": "Cudy", "88C397": "Cudy", "7844FD": "Totolink", "F42853": "Totolink",
    "00EC0A": "Xiaomi", "286C07": "Xiaomi", "34CE00": "Xiaomi", "640980": "Xiaomi",
    "7811DC": "Xiaomi", "8CBEBE": "Xiaomi", "F0B429": "Xiaomi", "F8A45F": "Xiaomi",
    "00055D": "D-Link", "00179A": "D-Link", "14D64D": "D-Link", "1C7EE5": "D-Link",
    "28107B": "D-Link", "78542E": "D-Link", "C8D3A3": "D-Link", "F07D68": "D-Link",
    "049226": "ASUS", "08606E": "ASUS", "107B44": "ASUS", "2C56DC": "ASUS",
    "38D547": "ASUS", "74D02B": "ASUS", "AC9E17": "ASUS", "F07959": "ASUS",
    # BDCOM (OLT & ONU)
    "00E00F": "BDCOM", "047503": "BDCOM", "1C8779": "BDCOM", "38E2DD": "BDCOM",
    "500BD6": "BDCOM", "807871": "BDCOM", "847973": "BDCOM", "9CE895": "BDCOM",
    "A0C6EC": "BDCOM", "B4B362": "BDCOM", "C850CE": "BDCOM", "E067B3": "BDCOM",
    "F8F082": "BDCOM",
    # V-SOL (Guangzhou V-Solution)
    "18022D": "V-SOL", "285132": "V-SOL", "38D82F": "V-SOL", "44F971": "V-SOL",
    "689E29": "V-SOL", "70A56A": "V-SOL", "84900A": "V-SOL", "A091C8": "V-SOL",
    "C470AB": "V-SOL", "E0E8E6": "V-SOL",
    # C-Data
    "000F4B": "C-Data", "207693": "C-Data", "383A21": "C-Data", "58696C": "C-Data",
    "600810": "C-Data", "745B62": "C-Data", "90671C": "C-Data", "D05F64": "C-Data",
    "E06066": "C-Data",
    # Huawei (OLT & HG/EG ONUs)
    "001882": "Huawei", "001E10": "Huawei", "002568": "Huawei", "00259E": "Huawei",
    "00464B": "Huawei", "00664B": "Huawei", "00E0FC": "Huawei", "04B0E7": "Huawei",
    "04C06F": "Huawei", "0819A6": "Huawei", "101B54": "Huawei", "14B968": "Huawei",
    "200BC7": "Huawei", "240995": "Huawei", "283152": "Huawei", "286ED4": "Huawei",
    "346BD3": "Huawei", "4846FB": "Huawei", "488EEF": "Huawei", "548998": "Huawei",
    "60DE44": "Huawei", "70723C": "Huawei", "80FB06": "Huawei", "8853D4": "Huawei",
    "9C28EF": "Huawei", "AC853D": "Huawei", "C8D15E": "Huawei", "D46AA8": "Huawei",
    "E0247F": "Huawei", "F4559C": "Huawei", "F898B9": "Huawei",
    # ZTE (OLT & F601/F660/F670 ONUs)
    "0015EB": "ZTE", "0019C6": "ZTE", "001E73": "ZTE", "002293": "ZTE",
    "002512": "ZTE", "0026ED": "ZTE", "0C1262": "ZTE", "146080": "ZTE",
    "208986": "ZTE", "2C957F": "ZTE", "344B50": "ZTE", "38D82F": "ZTE",
    "48282F": "ZTE", "5422F8": "ZTE", "601888": "ZTE", "681AB2": "ZTE",
    "749781": "ZTE", "789682": "ZTE", "84742A": "ZTE", "98F537": "ZTE",
    "A0EC80": "ZTE", "B4B362": "ZTE", "C864C7": "ZTE", "D0154A": "ZTE",
    "D437D7": "ZTE", "E0C3F3": "ZTE", "F8DF5D": "ZTE",
    # FiberHome / Nokia / DBC / HSGQ / Corelink / Netlink
    "000AC2": "FiberHome", "107BEF": "FiberHome", "244BF1": "FiberHome",
    "3891D5": "FiberHome", "5C63BF": "FiberHome", "88CEFA": "FiberHome",
    "00197D": "Nokia", "0C7C28": "Nokia", "40B034": "Nokia", "6854ED": "Nokia",
    "A86B7C": "HSGQ", "E43A6E": "HSGQ", "D49AA0": "DBC", "C0A00D": "Corelink",
    # MikroTik
    "000C42": "MikroTik", "085531": "MikroTik", "18FD74": "MikroTik", "2C91AB": "MikroTik",
    "488F5A": "MikroTik", "4C5E0C": "MikroTik", "64D154": "MikroTik", "6C3B6B": "MikroTik",
    "744D28": "MikroTik", "789A18": "MikroTik", "B869F4": "MikroTik", "C4AD34": "MikroTik",
    "CC2DE0": "MikroTik", "D401C3": "MikroTik", "DC2C6E": "MikroTik", "E48D8C": "MikroTik",
}

_db = dict(BUILTIN_OUI)


def load():
    global _db
    d = dict(BUILTIN_OUI)
    if os.path.exists(PATH):
        with open(PATH, encoding="utf-8", errors="ignore", newline="") as f:
            for row in csv.reader(f):
                if len(row) >= 3 and re.fullmatch(r"[0-9A-Fa-f]{6}", row[1].strip()):
                    d[row[1].strip().upper()] = row[2].strip()
    _db = d
    return len(d)


def update():
    r = httpx.get(URL, timeout=90, follow_redirects=True, headers={"User-Agent": "Mozilla/5.0 isp-portal"})
    r.raise_for_status()
    if "Assignment" not in r.text[:200]:
        raise RuntimeError("Unexpected OUI file format")
    os.makedirs(os.path.dirname(PATH) or ".", exist_ok=True)
    with open(PATH, "w", encoding="utf-8") as f:
        f.write(r.text)
    return load()


def save_upload(data: bytes):
    os.makedirs(os.path.dirname(PATH) or ".", exist_ok=True)
    with open(PATH, "wb") as f:
        f.write(data)
    return load()


def size():
    return len(_db)


def short(name):
    s = re.sub(r"(?i)[,.\s]*(co\.?,?\s*ltd\.?|technolog\w*|corporation|corp\.?|inc\.?|limited|ltd\.?|"
               r"international|electronics?|communications?|group|telecom\w*|networks?|systems?).*$", "", name or "").strip(" ,.-")
    return s or name


def describe(mac):
    if not mac:
        return None
    h = re.sub(r"[^0-9A-Fa-f]", "", str(mac)).upper()
    if len(h) < 6:
        return None
    name = _db.get(h[:6])
    # Also check ASCII GPON Serial Prefix (e.g. HWTC..., ZTEG..., BDCM..., VSOL..., CDAT..., ALCL..., FHTT...)
    if not name and len(str(mac)) >= 4:
        pre = str(mac)[:4].upper()
        gpon_map = {
            "HWTC": "Huawei", "HWTG": "Huawei", "ZTEG": "ZTE", "BDCM": "BDCOM",
            "VSOL": "V-SOL", "MONU": "V-SOL", "CDAT": "C-Data", "CMSZ": "C-Data",
            "ALCL": "Nokia (Alcatel-Lucent)", "FHTT": "FiberHome", "TPLG": "TP-Link",
            "UBNT": "Ubiquiti", "HSGQ": "HSGQ", "DBCT": "DBC", "CRLK": "Corelink",
        }
        name = gpon_map.get(pre)
    return dict(mac=mac, vendor=name, short=short(name) if name else None,
                local=bool(int(h[:2], 16) & 2) if len(h) >= 2 else False)


def background_init():
    load()
    if len(_db) <= len(BUILTIN_OUI):
        threading.Thread(target=lambda: _try(update), daemon=True).start()


def _try(fn):
    try:
        fn()
    except Exception:
        pass
