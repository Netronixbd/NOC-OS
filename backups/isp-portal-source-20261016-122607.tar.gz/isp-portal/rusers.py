"""In-memory directory of PPPoE users & active CCR sessions (for instant live search suggestions)."""
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import mikrotik
import util

TTL = 30
_users = {}          # replaced atomically or updated via merge_live
_last_refresh = 0.0
_getter = None
_lock = threading.Lock()


def _build(routers):
    users = {}
    active_routers = [r for r in routers if r.get("api_enabled", True)]
    if not active_routers:
        return users

    def _fetch_one(r):
        try:
            return r, mikrotik.list_users(r)
        except Exception:
            return r, ([], [])

    with ThreadPoolExecutor(max_workers=min(6, len(active_routers))) as ex:
        results = list(ex.map(_fetch_one, active_routers))

    for r, (sec, act) in results:
        for s in sec:
            n = s.get("name")
            if n:
                name, phone = util.parse_comment(s.get("comment", ""))
                users[n] = dict(
                    uid=n,
                    name=name,
                    phone=phone,
                    ip=s.get("remote-address") or "",
                    mac=s.get("last-caller-id") or "",
                    uptime="",
                    router_id=r["id"],
                    router=r["name"],
                    profile=s.get("profile") or "",
                    online=False,
                    disabled=mikrotik._flag(s.get("disabled")),
                )
        for a in act:
            n = a.get("name")
            if not n:
                continue
            act_name, act_phone = util.parse_comment(a.get("comment", ""))
            u = users.setdefault(
                n,
                dict(
                    uid=n,
                    name=act_name,
                    phone=act_phone,
                    ip="",
                    mac="",
                    uptime="",
                    router_id=r["id"],
                    router=r["name"],
                    profile="Active PPPoE",
                    disabled=False,
                ),
            )
            u["online"] = True
            u["router_id"] = r["id"]
            u["router"] = r["name"]
            u["ip"] = a.get("address") or u.get("ip") or ""
            u["mac"] = a.get("caller-id") or u.get("mac") or ""
            u["uptime"] = a.get("uptime") or ""
            if act_name and not u.get("name"):
                u["name"] = act_name
            if act_phone and not u.get("phone"):
                u["phone"] = act_phone
    return users


def refresh():
    global _users, _last_refresh
    if not _getter:
        return
    try:
        users = _build(_getter())
    except Exception:
        return
    if users:
        with _lock:
            _users = users
            _last_refresh = time.time()


def merge_live(items):
    """Merge live-queried CCR active sessions into the in-memory directory."""
    if not items:
        return
    with _lock:
        for it in items:
            uid = it.get("uid")
            if not uid:
                continue
            cur = _users.get(uid, {})
            _users[uid] = dict(
                uid=uid,
                name=it.get("name") or cur.get("name") or "",
                phone=it.get("phone") or cur.get("phone") or "",
                ip=it.get("ip") or cur.get("ip") or "",
                mac=it.get("mac") or cur.get("mac") or "",
                uptime=it.get("uptime") or cur.get("uptime") or "",
                router_id=it.get("router_id") or cur.get("router_id"),
                router=it.get("router") or cur.get("router") or "",
                profile=it.get("profile") or cur.get("profile") or "",
                online=it.get("online") if it.get("online") is not None else cur.get("online", False),
                disabled=it.get("disabled") if it.get("disabled") is not None else cur.get("disabled", False),
            )


def refresh_async():
    threading.Thread(target=refresh, daemon=True).start()


def start(getter):
    global _getter
    _getter = getter

    def loop():
        while True:
            refresh()
            time.sleep(TTL)
    threading.Thread(target=loop, daemon=True).start()


def size():
    return len(_users)


def last_age():
    return time.time() - _last_refresh if _last_refresh else 999999


def get(uid):
    return _users.get(uid)


def exact(q):
    ql = (q or "").lower()
    for uid, u in _users.items():
        if uid.lower() == ql:
            return u
    return None


def search(q, limit=12):
    ql = (q or "").strip().lower()
    if not ql:
        return []
    digits = util.norm_phone(q)
    norm_q_mac = re.sub(r"[^0-9a-f]", "", ql)
    pre_online, pre_off, con_online, con_off = [], [], [], []
    for uid, u in list(_users.items()):
        l = uid.lower()
        ip = (u.get("ip") or "").lower()
        mac = (u.get("mac") or "").lower()
        mac_clean = re.sub(r"[^0-9a-f]", "", mac)
        uname = (u.get("name") or "").lower()
        uphone = u.get("phone") or ""
        is_on = bool(u.get("online"))
        if l.startswith(ql):
            (pre_online if is_on else pre_off).append(u)
        elif (
            ql in l
            or (uname and ql in uname)
            or (len(digits) >= 4 and digits in uphone)
            or (ip and ql in ip)
            or (mac and (ql in mac or (len(norm_q_mac) >= 4 and norm_q_mac in mac_clean)))
        ):
            (con_online if is_on else con_off).append(u)
    key = lambda u: u["uid"].lower()
    for grp in (pre_online, pre_off, con_online, con_off):
        grp.sort(key=key)
    return (pre_online + con_online + pre_off + con_off)[:limit]


def all_users():
    return list(_users.values())
