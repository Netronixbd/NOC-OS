# ISP Network Operations & Automated Support Console (Commercial Edition)

Commercial-grade, automated ISP support & NOC portal featuring:
- **Automated CCR ↔ OLT ↔ ONU Correlation (`L2 & Fiber`)**: Automatically correlates MikroTik CCR PPPoE `caller-id` (Customer Router WAN MAC) against OLT FDB / ONU MAC tables across all connected OLTs to identify the exact OLT, PON port, ONU ID, **ONU Rx/Tx/OLT-Rx Optical Power (dBm)**, **ONU Hardware MAC/SN**, **ONU Brand/Model**, and **Fiber Distance (m / km)**.
- **Pre-Configured Multi-Vendor OLT MIB / OID Profiles**: Ready out-of-the-box for BDCOM (EPON & GPON), V-SOL (EPON & GPON), C-Data (EPON & GPON), DBC / Corelink / HSGQ, Huawei (MA5600/MA5800), ZTE (C300/C320), FiberHome, Nokia, and Ubiquiti UFiber.
- **VLAN-Only Interface Watch with Multi-CCR Filtering**: Strictly monitors Router VLAN interfaces (`vlan`) with instant filtering by CCR Router, VLAN name/ID search, and link/watch status.
- **Live CCR Active Connection Autocomplete**: Real-time search suggestions streamed from MikroTik CCR `/ppp/active` and `/ppp/secret` tables (matching username, MAC, IP, name, or phone) + global `Ctrl+K` quick-diagnose bar.
- **Alarm-Only Sound Engine**: Zero click sounds; plays distinct **Issue Alarm** (when a fault occurs) and **Resolve Alarm** (ascending chime when an issue resolves).
- **100% In-Place Modification**: Modify PPPoE status, profiles, passwords, ONU MACs, VLAN thresholds, Routers, OLTs, OID profiles, Tunnels, and Tickets directly in-place without switching tabs.
- **Commercial Security**: Same-origin CSRF protection, strict security headers, PBKDF2-HMAC-SHA256 (200k iterations), persistent session keys, login brute-force rate limiting, and full audit logging.

## Installation / Upgrade (Ubuntu 22.04 / 24.04)
```bash
sudo bash install.sh
```
Default URL: `http://SERVER_IP:8000` · Login: `admin` / `Amir@2647`
