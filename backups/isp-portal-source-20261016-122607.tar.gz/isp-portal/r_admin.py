"""Administration routes: staff accounts, own account, settings, logo, integrations, PPTP tunnels, tickets."""
import json
import os
from datetime import datetime

from fastapi import APIRouter, BackgroundTasks, Depends, File, Form, Request, UploadFile
from fastapi.responses import JSONResponse, RedirectResponse
from sqlalchemy import func
from starlette.concurrency import run_in_threadpool

import cases
import ctx
import notify
import oui
import rusers
import snmp
import telegram_bot
import vpn
from core import CATEGORIES, ROLE_LABEL, ROLES, check_pw, flash, get_db, hash_pw, render
from db import Admin, Customer, Integration, Router, SessionLocal, Tunnel, audit, get_setting, set_setting

router = APIRouter()


def _is_ajax(request: Request) -> bool:
    return (
        request.headers.get("x-requested-with") == "fetch"
        or "application/json" in (request.headers.get("accept") or "")
    )


def fld(name, label, value="", type="text", options=None, help=""):
    return dict(name=name, label=label, value=value if value is not None else "", type=type, options=options or [], help=help)


# ------------------------------------------------------------------ staff accounts (super admin)
@router.get("/admin/staff")
def staff_page(request: Request, db=Depends(get_db)):
    return render(request, "admin_staff.html", items=db.query(Admin).order_by(Admin.id).all(), roles=ROLE_LABEL)


@router.post("/admin/staff/new")
async def staff_new(request: Request, db=Depends(get_db)):
    f = await request.form()
    u, pw, role = (f.get("username") or "").strip(), f.get("password") or "", f.get("role") or "read"
    if not u or len(u) > 40 or " " in u or role not in ROLES or len(pw) < 8:
        flash(request, "Username (no spaces), a role and a password of 8+ characters are required.", "err")
    elif db.query(Admin).filter(func.lower(Admin.username) == u.lower()).first():
        flash(request, "That username already exists.", "err")
    else:
        db.add(Admin(username=u, full_name=(f.get("full_name") or "").strip()[:64], password_hash=hash_pw(pw), role=role, active=True))
        db.commit()
        audit(db, request.session["admin"], "staff_create", u, role)
        flash(request, f"Account '{u}' created as {ROLE_LABEL[role]}.")
    return RedirectResponse("/admin/staff", 303)


@router.post("/admin/staff/{aid}")
async def staff_update(request: Request, aid: int, db=Depends(get_db)):
    f = await request.form()
    a = db.get(Admin, aid)
    if not a:
        return RedirectResponse("/admin/staff", 303)
    role, active = f.get("role") or a.role, bool(f.get("active"))
    supers = db.query(Admin).filter(Admin.role == "super", Admin.active.is_(True), Admin.id != a.id).count()
    if role not in ROLES or ((role != "super" or not active) and a.role == "super" and not supers):
        flash(request, "There must be at least one active super admin.", "err")
        return RedirectResponse("/admin/staff", 303)
    if a.id == request.state.user["id"] and not active:
        flash(request, "You cannot disable your own account.", "err")
        return RedirectResponse("/admin/staff", 303)
    a.role, a.active, a.full_name = role, active, (f.get("full_name") or "").strip()[:64]
    if f.get("password"):
        if len(f["password"]) < 8:
            flash(request, "Password must be at least 8 characters.", "err")
            return RedirectResponse("/admin/staff", 303)
        a.password_hash = hash_pw(f["password"])
    db.commit()
    audit(db, request.session["admin"], "staff_update", a.username, f"role={role} active={active}")
    if _is_ajax(request):
        return JSONResponse(dict(ok=True, message=f"Account '{a.username}' updated."))
    flash(request, f"Account '{a.username}' updated.")
    return RedirectResponse("/admin/staff", 303)


@router.post("/admin/staff/{aid}/delete")
def staff_delete(request: Request, aid: int, db=Depends(get_db)):
    a = db.get(Admin, aid)
    if a and a.id != request.state.user["id"]:
        if a.role == "super" and not db.query(Admin).filter(Admin.role == "super", Admin.active.is_(True), Admin.id != a.id).count():
            flash(request, "There must be at least one active super admin.", "err")
        else:
            db.delete(a)
            db.commit()
            audit(db, request.session["admin"], "staff_delete", a.username)
            flash(request, "Account deleted.")
    else:
        flash(request, "You cannot delete your own account.", "err")
    return RedirectResponse("/admin/staff", 303)


# ------------------------------------------------------------------ own account
@router.get("/admin/account")
def account_page(request: Request):
    return render(request, "admin_account.html")


@router.post("/admin/account/password")
def account_password(request: Request, old: str = Form(""), new: str = Form(""), db=Depends(get_db)):
    a = db.get(Admin, request.state.user["id"])
    if not check_pw(old, a.password_hash) or len(new) < 8:
        flash(request, "Current password is wrong, or the new password is shorter than 8 characters.", "err")
    else:
        a.password_hash = hash_pw(new)
        db.commit()
        audit(db, a.username, "password_change")
        flash(request, "Password changed.")
    return RedirectResponse("/admin/account", 303)


# ------------------------------------------------------------------ settings (tabs) + branding
@router.get("/admin/settings")
def settings_page(request: Request, db=Depends(get_db)):
    tok = get_setting("tg_token")
    return render(
        request,
        "admin_settings.html",
        tg_token_masked=(tok[:6] + "…" + tok[-4:]) if tok else "",
        tg_chat=get_setting("tg_chat_id"),
        seen=telegram_bot.seen_chats,
        oui_n=oui.size(),
        ru_n=rusers.size(),
        title_val=get_setting("site_title", "Network Operations"),
        sound=get_setting("sound_enabled", "1") == "1",
        daily=get_setting("daily_report_hour", "-1"),
        tg_dc=get_setting("tg_allow_disconnect", "1") == "1",
        mon={k: get_setting(k, d) for k, d in (
            ("mon_interval", "30"), ("mon_cpu_warn", "85"), ("mon_cpu_crit", "95"),
            ("mon_drop_pct", "20"), ("mon_pon_drop_pct", "50")
        )},
        integrations=db.query(Integration).count(),
    )


@router.post("/admin/settings/general")
async def set_general(request: Request):
    f = await request.form()
    set_setting("site_title", (f.get("site_title") or "").strip()[:80] or "Network Operations")
    set_setting("sound_enabled", "1" if f.get("sound_enabled") else "0")
    set_setting("tg_allow_disconnect", "1" if f.get("tg_allow_disconnect") else "0")
    dh = (f.get("daily_report_hour") or "").strip()
    set_setting("daily_report_hour", dh if dh.isdigit() and 0 <= int(dh) <= 23 else "-1")
    flash(request, "Saved.")
    return RedirectResponse("/admin/settings", 303)


@router.post("/admin/settings/logo")
async def set_logo(request: Request, file: UploadFile = File(...)):
    data = await file.read()
    ctype = (file.content_type or "").lower()
    if ctype not in ("image/png", "image/jpeg", "image/webp", "image/gif", "image/svg+xml") or not data or len(data) > 1_000_000:
        flash(request, "Upload a PNG, JPG, WEBP, GIF or SVG logo up to 1 MB.", "err")
    else:
        os.makedirs("data", exist_ok=True)
        with open(os.path.join("data", "logo.bin"), "wb") as fh:
            fh.write(data)
        set_setting("logo_type", ctype)
        set_setting("logo_ts", str(int(datetime.utcnow().timestamp())))
        flash(request, "Logo updated. It is now used on the login page and across the panel.")
    return RedirectResponse("/admin/settings", 303)


@router.post("/admin/settings/logo/remove")
def remove_logo(request: Request):
    try:
        os.remove(os.path.join("data", "logo.bin"))
    except OSError:
        pass
    set_setting("logo_ts", "")
    flash(request, "Logo removed.")
    return RedirectResponse("/admin/settings", 303)


# ------------------------------------------------------------------ integrations (email / webhook / SMS / extra Telegram)
SECRET_KEYS = ("token", "password", "auth")


def _cfg(i):
    try:
        return json.loads(i.config or "{}") if i else {}
    except ValueError:
        return {}


@router.get("/admin/integrations")
def integrations_page(request: Request, db=Depends(get_db)):
    items = db.query(Integration).order_by(Integration.id).all()
    cfg_map = {}
    for i in items:
        c = _cfg(i)
        cfg_map[i.id] = dict(
            id=i.id,
            name=i.name,
            kind=i.kind,
            enabled=bool(i.enabled),
            events=i.events or "alarm,ticket",
            cfg={k: ("" if k in SECRET_KEYS else v) for k, v in c.items()},
        )
    return render(request, "admin_integrations.html", items=items, cfg_json=json.dumps(cfg_map))


@router.get("/admin/integrations/new")
def integration_new(request: Request):
    return render(request, "admin_integration.html", i=None, cfg={}, kind=request.query_params.get("kind", "email"))


@router.get("/admin/integrations/{iid}")
def integration_edit(request: Request, iid: int, db=Depends(get_db)):
    i = db.get(Integration, iid)
    if not i:
        return RedirectResponse("/admin/integrations", 303)
    c = _cfg(i)
    masked = {k: ("" if k in SECRET_KEYS else v) for k, v in c.items()}
    return render(request, "admin_integration.html", i=i, cfg=masked, kind=i.kind)


async def _save_integration(request, db, i):
    f = await request.form()
    kind = f.get("kind") or i.kind or "email"
    old = _cfg(i) if i.id else {}
    keys = {
        "telegram": ["token", "chat_id"],
        "email": ["host", "port", "security", "user", "password", "from", "to"],
        "webhook": ["url", "method", "auth"],
        "sms": ["url", "method", "body", "content_type", "to"],
    }[kind]
    cfg = {}
    for k in keys:
        v = (f.get(k) or "").strip()
        cfg[k] = v if (v or k not in SECRET_KEYS) else old.get(k, "")
    i.name, i.kind, i.config = (f.get("name") or kind).strip()[:64], kind, json.dumps(cfg)
    i.enabled = bool(f.get("enabled"))
    i.events = ",".join(e for e in ("alarm", "ticket", "report") if f.get("ev_" + e)) or "alarm"
    db.add(i)
    db.commit()


@router.post("/admin/integrations/new")
async def integration_create(request: Request, db=Depends(get_db)):
    i = Integration()
    await _save_integration(request, db, i)
    audit(db, request.session["admin"], "integration_add", i.name, i.kind)
    if _is_ajax(request):
        return JSONResponse(dict(ok=True, id=i.id, message="Integration added."))
    flash(request, "Integration added. Use Test to verify.")
    return RedirectResponse("/admin/integrations", 303)


@router.post("/admin/integrations/{iid}")
async def integration_update(request: Request, iid: int, db=Depends(get_db)):
    i = db.get(Integration, iid)
    if i:
        await _save_integration(request, db, i)
        if _is_ajax(request):
            return JSONResponse(dict(ok=True, id=i.id, message="Integration saved."))
        flash(request, "Integration saved.")
    return RedirectResponse("/admin/integrations", 303)


@router.post("/admin/integrations/{iid}/delete")
def integration_delete(request: Request, iid: int, db=Depends(get_db)):
    i = db.get(Integration, iid)
    if i:
        db.delete(i)
        db.commit()
        if _is_ajax(request):
            return JSONResponse(dict(ok=True, message="Integration removed."))
        flash(request, "Integration removed.")
    return RedirectResponse("/admin/integrations", 303)


@router.post("/admin/integrations/{iid}/test")
async def integration_test(request: Request, iid: int):
    ok, err = await run_in_threadpool(notify.test, iid)
    if _is_ajax(request):
        return JSONResponse(dict(ok=ok, message="Test message sent ✅" if ok else f"Test failed: {err}", error=err))
    flash(request, "Test message sent ✅" if ok else f"Test failed: {err}", "ok" if ok else "err")
    return RedirectResponse("/admin/integrations", 303)


# ------------------------------------------------------------------ PPTP tunnels
def _tdict(t):
    return dict(id=t.id, name=t.name, server=t.server, username=t.username, password=t.password, mppe=t.mppe,
                routes=t.routes or "", auto=t.auto, note=t.note or "")


def _tfields(t=None):
    t = t or Tunnel(name="", server="", username="", password="", mppe=True, routes="", auto=True, note="")
    return [
        fld("name", "Name", t.name),
        fld("server", "MikroTik public IP / hostname (PPTP server)", t.server),
        fld("username", "PPP username", t.username),
        fld("password", "PPP password", "", "password", help="Leave blank to keep the saved password" if t.id else ""),
        fld("routes", "Private subnets reachable through this tunnel (comma separated)", t.routes,
            help="e.g. 172.16.99.0/24, 10.10.0.0/16. These routes are added when the tunnel connects."),
        fld("mppe", "Require MPPE-128 encryption (RouterOS default)", t.mppe is not False, "checkbox"),
        fld("auto", "Connect automatically and keep the tunnel up", t.auto is not False, "checkbox"),
        fld("note", "Note", t.note),
    ]


@router.get("/admin/tunnels")
def tunnels_page(request: Request, db=Depends(get_db)):
    items = []
    tun_json = {}
    for t in db.query(Tunnel).all():
        try:
            s = vpn.status(_tdict(t)) if vpn.available() else dict(up=False, daemon=False, local=None, remote=None)
        except Exception:
            s = dict(up=False, daemon=False, local=None, remote=None)
        items.append((t, s))
        tun_json[t.id] = dict(id=t.id, name=t.name, server=t.server, username=t.username,
                              routes=t.routes or "", mppe=t.mppe is not False, auto=t.auto is not False, note=t.note or "")
    return render(request, "admin_tunnels.html", items=items, available=vpn.available(), tun_json=json.dumps(tun_json))


@router.get("/admin/tunnels/new")
def tunnel_new(request: Request):
    return render(request, "admin_form.html", title="Add PPTP tunnel", fields=_tfields(), back="/admin/tunnels", action="/admin/tunnels/new")


@router.get("/admin/tunnels/{tid}/edit")
def tunnel_edit_page(request: Request, tid: int, db=Depends(get_db)):
    t = db.get(Tunnel, tid)
    if not t:
        return RedirectResponse("/admin/tunnels", 303)
    return render(request, "admin_form.html", title=f"Edit tunnel {t.name}", fields=_tfields(t), back="/admin/tunnels", action=f"/admin/tunnels/{tid}")


async def _save_tunnel(request, db, t):
    f = await request.form()
    t.name, t.server, t.username = (f.get("name") or "").strip(), (f.get("server") or "").strip(), (f.get("username") or "").strip()
    if f.get("password"):
        t.password = f["password"]
    t.routes, t.note = (f.get("routes") or "").strip(), (f.get("note") or "")[:250]
    t.mppe, t.auto = bool(f.get("mppe")), bool(f.get("auto"))
    vpn.validate(_tdict(t))
    db.add(t)
    db.commit()
    try:
        vpn.write_all([_tdict(x) for x in db.query(Tunnel).all()])
    except Exception as e:
        flash(request, f"Saved, but could not write ppp config: {e}", "err")


@router.post("/admin/tunnels/new")
async def tunnel_create(request: Request, db=Depends(get_db)):
    try:
        t = Tunnel(password="")
        await _save_tunnel(request, db, t)
        if _is_ajax(request):
            return JSONResponse(dict(ok=True, id=t.id, message="Tunnel added."))
        flash(request, "Tunnel added. Press Connect.")
    except Exception as e:
        if _is_ajax(request):
            return JSONResponse(dict(ok=False, error=f"Invalid settings: {e}"), status_code=400)
        flash(request, f"Invalid settings: {e}", "err")
    return RedirectResponse("/admin/tunnels", 303)


@router.post("/admin/tunnels/{tid}")
async def tunnel_update(request: Request, tid: int, db=Depends(get_db)):
    t = db.get(Tunnel, tid)
    if t:
        try:
            await _save_tunnel(request, db, t)
            if _is_ajax(request):
                return JSONResponse(dict(ok=True, id=t.id, message="Tunnel saved."))
            flash(request, "Tunnel saved. Reconnect to apply.")
        except Exception as e:
            if _is_ajax(request):
                return JSONResponse(dict(ok=False, error=f"Invalid settings: {e}"), status_code=400)
            flash(request, f"Invalid settings: {e}", "err")
    return RedirectResponse("/admin/tunnels", 303)


@router.post("/admin/tunnels/{tid}/connect")
async def tunnel_connect(request: Request, tid: int, db=Depends(get_db)):
    t = db.get(Tunnel, tid)
    try:
        allt = [_tdict(x) for x in db.query(Tunnel).all()]
        vpn.write_all(allt)
        s = await run_in_threadpool(vpn.connect, _tdict(t))
        flash(request, f"Connected: local {s['local']} ↔ remote {s['remote']}" if s["up"] else "Dial started but the tunnel is not up yet. Check the log.", "ok" if s["up"] else "err")
        audit(db, request.session["admin"], "tunnel_connect", t.name)
    except Exception as e:
        flash(request, f"Connect failed: {e}", "err")
    return RedirectResponse("/admin/tunnels", 303)


@router.post("/admin/tunnels/{tid}/disconnect")
async def tunnel_disconnect(request: Request, tid: int, db=Depends(get_db)):
    t = db.get(Tunnel, tid)
    if t:
        await run_in_threadpool(vpn.disconnect, _tdict(t))
        t.auto = False
        db.commit()
        flash(request, "Tunnel stopped and auto-connect turned off.")
    return RedirectResponse("/admin/tunnels", 303)


@router.post("/admin/tunnels/{tid}/delete")
async def tunnel_delete(request: Request, tid: int, db=Depends(get_db)):
    t = db.get(Tunnel, tid)
    if t:
        try:
            await run_in_threadpool(vpn.disconnect, _tdict(t))
        except Exception:
            pass
        db.delete(t)
        db.commit()
        try:
            vpn.write_all([_tdict(x) for x in db.query(Tunnel).all()])
        except Exception:
            pass
        flash(request, "Tunnel removed.")
    return RedirectResponse("/admin/tunnels", 303)


@router.get("/admin/tunnels/{tid}/log")
def tunnel_log(tid: int, db=Depends(get_db)):
    t = db.get(Tunnel, tid)
    return JSONResponse(dict(log=vpn.log_tail(_tdict(t)) if t else ""))


# ------------------------------------------------------------------ tickets creation (with auto-adoption)
@router.post("/admin/tickets/new")
async def ticket_new(request: Request, bg: BackgroundTasks, db=Depends(get_db)):
    f = await request.form()
    uid = (f.get("uid") or "").strip()
    cat = f.get("category") if f.get("category") in CATEGORIES else "Other"
    note = f.get("note") or ""
    cm = cases.create_ticket(db, uid, cat, note, request.session["admin"])
    if not cm:
        # Even if router is temporarily unreachable, allow creating ticket by adopting/creating customer record
        if uid:
            upsert_customer(db, uid, uid)
            db.commit()
            cm = cases.create_ticket(db, uid, cat, note, request.session["admin"])
    if not cm:
        if _is_ajax(request):
            return JSONResponse(dict(ok=False, error="User ID is required."), status_code=400)
        flash(request, "User not found on the routers.", "err")
    else:
        bg.add_task(cases.notify_new, cm.id)
        audit(db, request.session["admin"], "ticket_create", uid, f"#{cm.id}")
        if _is_ajax(request):
            return JSONResponse(dict(ok=True, id=cm.id, message=f"Ticket #{cm.id} created & auto-diagnosis queued."))
        flash(request, f"Ticket #{cm.id} created. Diagnosis is being posted to Telegram.")
    return RedirectResponse("/admin/tickets", 303)
