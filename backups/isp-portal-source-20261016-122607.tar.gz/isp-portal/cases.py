"""Tickets (cases) and user adoption: build a record from router data and open a ticket with auto-diagnosis posted to Telegram."""
import json
import logging
import re
import secrets
import time
from datetime import datetime, timedelta

import ctx
import diag
import mikrotik
import rusers
import telegram_bot
from db import Complaint, Customer, SessionLocal
from util import norm_phone, parse_comment

log = logging.getLogger("cases")
_pon_alerts = {}


def upsert_customer(db, user_id, name="", phone="", address="", router_id=None, overwrite=True):
    user_id = user_id.strip()
    if not user_id:
        return None
    c = db.query(Customer).filter_by(user_id=user_id).first()
    if not c:
        db.add(Customer(user_id=user_id, token=secrets.token_hex(8), name=name, phone=norm_phone(phone),
                        address=address, router_id=router_id))
        return "new"
    if overwrite or not c.name:
        c.name = name or c.name
    if (overwrite or not c.phone) and phone:
        c.phone = norm_phone(phone)
    if address:
        c.address = address
    if router_id and not c.router_id:
        c.router_id = router_id
    return "updated"


def adopt_router_user(db, uid):
    """Return the Customer record for a PPPoE user, creating it from router data when it does not exist."""
    uid = (uid or "").strip()
    c = db.query(Customer).filter_by(user_id=uid).first()
    if c:
        return c
    if not re.fullmatch(r"\S{1,64}", uid):
        return None
    u = rusers.exact(uid)
    if u:
        name, phone, rid, canon = u["name"], u["phone"], u["router_id"], u["uid"]
    else:
        info = mikrotik.lookup(uid, ctx.router_dicts(db))
        if not info:
            return None
        (name, phone), rid, canon = parse_comment(info["comment"]), info["router_id"], uid
    c = db.query(Customer).filter_by(user_id=canon).first()
    if not c:
        c = Customer(user_id=canon, token=secrets.token_hex(8), name=name or canon, phone=norm_phone(phone), router_id=rid)
        db.add(c)
        db.commit()
        db.refresh(c)
    return c


def create_ticket(db, uid, category, note, by):
    c = adopt_router_user(db, uid)
    if not c:
        return None
    cm = Complaint(customer_id=c.id, category=category or "Other", message=(note or "").strip()[:1000])
    db.add(cm)
    db.commit()
    db.refresh(cm)
    return cm


def notify_new(cid):
    """Post the ticket, then a threaded auto-diagnosis (verdict + likely cause + draft reply) to Telegram."""
    with SessionLocal() as db:
        c = db.get(Complaint, cid)
        cust = c.customer
        d, same = None, 0
        try:
            d = ctx.diagnose(cust.user_id, None, exclude=cid)
            opt = d.get("optical") or {}
            if opt.get("found"):
                c.olt_name, c.pon = opt.get("olt") or "", opt.get("pon") or ""
            lines = list(d["report"])
            if c.pon:
                same = db.query(Complaint).filter(
                    Complaint.olt_name == c.olt_name, Complaint.pon == c.pon, Complaint.status != "closed",
                    Complaint.created_at >= datetime.utcnow() - timedelta(hours=1), Complaint.id != c.id).count()
            if same >= 2:
                lines.append(f"🚨 {same} other open tickets on {c.olt_name} PON {c.pon} in the last hour: possible PON / fiber outage")
                d["report"] = lines
            c.diag_json = json.dumps(dict(lines=lines, reply_bn=d["reply_bn"], reply_en=d["reply_en"]), ensure_ascii=False)
        except Exception as e:
            log.warning("diag failed: %s", e)
        try:
            res = telegram_bot.send(telegram_bot.complaint_text(c, cust), buttons=telegram_bot.buttons_for(c.id))
            c.tg_message_id = res["message_id"]
            if d:
                r2 = telegram_bot.send(telegram_bot.diag_reply_text(c, d), rows=telegram_bot.draft_rows(c.id), reply_to=c.tg_message_id)
                c.tg_diag_message_id = r2["message_id"]
            key = (c.olt_name, c.pon)
            if same >= 2 and time.time() - _pon_alerts.get(key, 0) > 3600:
                _pon_alerts[key] = time.time()
                telegram_bot.send(f"🚨 <b>Possible PON outage</b>\n{same + 1} open tickets on {c.olt_name} PON {c.pon} within 1 hour.")
        except Exception as e:
            c.notify_error = str(e)[:250]
            log.warning("Telegram notify failed: %s", e)
        db.commit()
