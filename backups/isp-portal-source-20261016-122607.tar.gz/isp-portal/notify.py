"""Alert dispatcher: sends to the primary Telegram group + every enabled integration (email / webhook / SMS / extra Telegram)."""
import json
import re
import smtplib
import ssl
import time
import urllib.parse
from datetime import datetime
from email.message import EmailMessage
from html import unescape

import httpx

from db import Integration, SessionLocal


def plain(html):
    return unescape(re.sub(r"<[^>]+>", "", html or ""))


def _cfg(i):
    try:
        return json.loads(i.config or "{}")
    except ValueError:
        return {}


def _send(i, level, title, text, html):
    c, k = _cfg(i), i.kind
    if k == "telegram":
        r = httpx.post(f"https://api.telegram.org/bot{c['token']}/sendMessage", timeout=15,
                       json=dict(chat_id=c["chat_id"], text=html[:4000], parse_mode="HTML", disable_web_page_preview=True))
        if not r.json().get("ok"):
            raise RuntimeError(r.json().get("description", "Telegram error"))
    elif k == "email":
        msg = EmailMessage()
        msg["Subject"] = f"[{level.upper()}] {title}"
        msg["From"] = c.get("from") or c.get("user")
        msg["To"] = c["to"]
        msg.set_content(text)
        port, sec = int(c.get("port") or 587), c.get("security", "starttls")
        s = smtplib.SMTP_SSL(c["host"], port, timeout=20, context=ssl.create_default_context()) if sec == "ssl" \
            else smtplib.SMTP(c["host"], port, timeout=20)
        try:
            if sec == "starttls":
                s.starttls(context=ssl.create_default_context())
            if c.get("user"):
                s.login(c["user"], c.get("password", ""))
            s.send_message(msg)
        finally:
            try:
                s.quit()
            except Exception:
                pass
    elif k == "webhook":
        h = {"Content-Type": "application/json"}
        if c.get("auth"):
            h["Authorization"] = c["auth"]
        r = httpx.request(c.get("method", "POST"), c["url"], headers=h, timeout=15,
                          json=dict(event="alert", level=level, title=title, message=text, ts=int(time.time())))
        r.raise_for_status()
    elif k == "sms":
        for to in [x.strip() for x in (c.get("to") or "").split(",") if x.strip()]:
            msg = text[:300]
            if c.get("method", "GET") == "GET":
                url = c["url"].replace("{to}", urllib.parse.quote(to)).replace("{message}", urllib.parse.quote(msg))
                r = httpx.get(url, timeout=15)
            else:
                body = (c.get("body") or "").replace("{to}", to).replace("{message}", msg)
                r = httpx.post(c["url"], content=body.encode(), timeout=15,
                               headers={"Content-Type": c.get("content_type") or "application/x-www-form-urlencoded"})
            r.raise_for_status()
    else:
        raise RuntimeError("Unknown integration type")


def dispatch(event, level, title, html):
    """Send to all enabled integrations subscribed to `event`."""
    text = plain(html)
    with SessionLocal() as db:
        for i in db.query(Integration).filter(Integration.enabled.is_(True)).all():
            if event not in (i.events or "").split(","):
                continue
            try:
                _send(i, level, title, text, html)
                i.last_ok, i.last_error = datetime.utcnow(), ""
            except Exception as e:
                i.last_error = str(e)[:250]
            db.commit()


def test(iid):
    with SessionLocal() as db:
        i = db.get(Integration, iid)
        try:
            _send(i, "info", "Test message", "This is a test message from the network console.",
                  "✅ <b>Test message</b> from the network console.")
            i.last_ok, i.last_error = datetime.utcnow(), ""
            db.commit()
            return True, ""
        except Exception as e:
            i.last_error = str(e)[:250]
            db.commit()
            return False, str(e)
