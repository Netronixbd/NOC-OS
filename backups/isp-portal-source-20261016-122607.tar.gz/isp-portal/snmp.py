"""Thin wrapper over net-snmp CLI tools (apt install snmp). v1/v2c with robust multi-vendor parsing."""
import math
import os
import re
import subprocess

_ENV = dict(os.environ, MIBS="")
_LINE = re.compile(r'^\.?([\d.]+)\s*=\s*(?:([A-Za-z0-9-]+):\s*)?(.*)$')


class SnmpError(Exception):
    pass


def clean(v):
    v = str(v).strip()
    if len(v) >= 2 and v[0] == '"' and v[-1] == '"':
        v = v[1:-1]
    return v.strip()


def num(v):
    if v is None:
        return None
    s = str(v).strip()
    if "no such" in s.lower() or "end of mib" in s.lower():
        return None
    m = re.search(r'-?\d+(?:\.\d+)?', s)
    return float(m.group()) if m else None


def _parse(out):
    rows = []
    for line in out.splitlines():
        s = line.strip()
        if not s:
            continue
        m = _LINE.match(s)
        if m:
            oid, typ, val = m.group(1), m.group(2) or "STRING", clean(m.group(3))
            if "no such" in val.lower() or "end of mib" in val.lower():
                continue
            rows.append((oid, typ, val))
        elif rows and re.fullmatch(r'[0-9A-Fa-f]{2}(?:\s+[0-9A-Fa-f]{2})*', s):
            # Continuation line of a multi-line Hex-STRING
            oid, typ, prev_val = rows[-1]
            rows[-1] = (oid, typ, f"{prev_val} {s}".strip())
    return rows


def _run(tool, dev, args, timeout, walk=False):
    host = str(dev.get("host") or "").strip()
    if not host or any(c in host for c in (" ", ";", "|", "&", "$", "`")):
        raise SnmpError("Invalid SNMP host")
    cmd = [tool, "-v", str(dev.get("version") or "2c"), "-c", dev.get("community") or "public",
           "-t", "2", "-r", "1", "-On", "-Oe", "-OU", "-Ot"]
    if walk:
        cmd.append("-Cc")
        if tool == "snmpbulkwalk":
            cmd.append("-Cr25")
    cmd += [f"{host}:{int(dev.get('port') or 161)}"] + args
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=_ENV)
    except FileNotFoundError:
        raise SnmpError("net-snmp tools missing (run: apt install snmp)")
    except subprocess.TimeoutExpired:
        raise SnmpError("SNMP timeout")
    rows = _parse(p.stdout)
    if not rows and p.returncode != 0:
        err = (p.stderr or p.stdout).strip()
        raise SnmpError(err.splitlines()[-1][:200] if err else "SNMP error")
    return rows


def get(dev, oids, timeout=15):
    """-> {oid: (type, value)}; missing instances are simply absent. Batches large OID lists safely."""
    if not oids:
        return {}
    out = {}
    clean_oids = [o.strip(".") for o in oids if o and o.strip(".")]
    for i in range(0, len(clean_oids), 24):
        chunk = clean_oids[i:i + 24]
        try:
            rows = _run("snmpget", dev, ["." + o for o in chunk], timeout)
            for o, t, v in rows:
                out[o.strip(".")] = (t, v)
        except SnmpError:
            if len(clean_oids) <= 24:
                raise
    return out


def walk(dev, oid, timeout=45):
    tool = "snmpwalk" if str(dev.get("version") or "2c") == "1" else "snmpbulkwalk"
    return _run(tool, dev, ["." + oid.strip(".")], timeout, walk=True)


# ---------- helpers
def norm_mac(s):
    if not s:
        return None
    s = str(s).strip()
    # Handle 6-character raw byte strings
    if len(s) == 6 and not re.fullmatch(r'[0-9A-Fa-f]{6}', s):
        try:
            if all(0 < ord(c) < 256 for c in s):
                return ":".join(f"{ord(c):02X}" for c in s)
        except Exception:
            pass
    h = re.sub(r'[^0-9A-Fa-f]', '', s)
    if len(h) != 12:
        return None
    mac = ":".join(h[i:i + 2] for i in range(0, 12, 2)).upper()
    if mac in ("00:00:00:00:00:00", "FF:FF:FF:FF:FF:FF"):
        return None
    return mac


def mac_dec(mac):
    m = norm_mac(mac)
    if not m:
        return ""
    return ".".join(str(int(x, 16)) for x in m.split(":"))


def dec_to_mac(dec_str):
    """Convert 6 decimal octets ('164.43.176.18.52.86') to 'A4:2B:B0:12:34:56'."""
    parts = [p for p in str(dec_str).strip(".").split(".") if p.isdigit()]
    if len(parts) < 6:
        return None
    octets = [int(p) for p in parts[-6:]]
    if all(0 <= o <= 255 for o in octets):
        mac = ":".join(f"{o:02X}" for o in octets)
        if mac not in ("00:00:00:00:00:00", "FF:FF:FF:FF:FF:FF"):
            return mac
    return None


def val_mac(typ, v):
    if v is None:
        return None
    m = norm_mac(v)
    if m:
        return m
    if typ in ("STRING", "Hex-STRING") and len(str(v)) == 6:
        try:
            return ":".join(f"{ord(c):02X}" for c in str(v)) if all(ord(c) < 256 for c in str(v)) else None
        except Exception:
            return None
    # GPON 8-byte serial (4 ASCII vendor bytes + 4 hex bytes, e.g. "48 57 54 43 12 34 56 78" -> "HWTC12345678")
    h = re.sub(r'[^0-9A-Fa-f]', '', str(v))
    if len(h) == 16:
        try:
            b = bytes.fromhex(h)
            if all(32 <= x <= 126 for x in b[:4]):
                return b[:4].decode("ascii") + h[8:].upper()
        except Exception:
            pass
    return None


def to_dbm(raw, div, unit):
    try:
        r = float(raw)
    except Exception:
        return None
    # Filter sentinel offline values used by BDCOM (-2147483648), Huawei (2147483647), ZTE (65535 / -32768)
    if r in (-2147483648, 2147483647, -32768, 32767, 65535, 0):
        return None
    if unit == "dbm_zte":
        # ZTE C300/C320 optical power formula: (raw * 0.002) - 30 dBm (when raw is 0..30000) or raw / 1000
        x = (r * 0.002 - 30.0) if 0 < r < 30000 else (r / (float(div) or 1000.0))
        return round(x, 2) if -55 <= x <= 10 else None
    try:
        x = r / (float(div) or 1)
    except Exception:
        return None
    if unit == "uw":
        if x <= 0:
            return None
        x = 10 * math.log10(x / 1000.0)
    return round(x, 2) if -55 <= x <= 10 else None


def rx_quality(dbm):
    """Standard EPON/GPON optical power thresholds."""
    if dbm is None:
        return None
    if dbm > -8:
        return "high"
    if dbm >= -24:
        return "good"
    if dbm >= -27:
        return "weak"
    return "bad"


def parse_dbm_str(v):
    """V-SOL / C-Data style text: '0.02 mW (-18.12 dBm)' or '-19.45 dBm' or '-19.45'."""
    if v is None:
        return None
    s = str(v).strip()
    m = re.findall(r'(-?\d+(?:\.\d+)?)\s*dbm', s, re.I)
    if m:
        x = float(m[-1])
        return round(x, 2) if -55 <= x <= 10 else None
    n = num(s)
    if n is not None and -55 <= n <= 10 and n != 0:
        return round(n, 2)
    return None
