import json
import threading
import time
from html import escape

import httpx

import ctx
import diag
import mikrotik
from db import STATUS_LABEL, Alarm, Complaint, Customer, SessionLocal, apply_action, audit, get_setting

API = "https://api.telegram.org/bot{}/{}"
seen_chats = {}
_member = {}

KB = [["🔎 Search user", "📊 Status"], ["🚨 Alarms", "🎫 Tickets"], ["🛰 OLTs", "🖧 Routers"]]
HELP = ("🤖 <b>Network console bot</b>\n\n"
        "Send a <b>user ID, name (2-3 letters), phone or MAC</b> and I will suggest matches.\n"
        "Inline: type <code>@botname abc</code> in any chat to pick a user.\n\n"
        "<b>Customers</b>\n/diag &lt;q&gt; · full diagnosis card\n/search &lt;q&gt; · find users\n/live &lt;uid&gt; · live speed\n"
        "/ping &lt;uid&gt; · 20×100ms ping\n/disconnect &lt;uid&gt; · redial the session\n\n"
        "<b>Network</b>\n/status · /alarms · /router [name] · /olt [name]\n/offline &lt;olt&gt; · ONUs down\n/weak &lt;olt&gt; · weakest ONUs by Rx\n\n"
        "<b>Tickets</b>\n/open · /ticket &lt;n&gt; · /new &lt;uid&gt; [note]\n/wait &lt;n&gt; · /close &lt;n&gt; [note] · /reply &lt;n&gt; &lt;text&gt;")
COMMANDS = [("diag", "Diagnose a user (id/name/phone/mac)"), ("search", "Find users"), ("live", "Live speed of a user"),
            ("ping", "Ping a user's router"), ("disconnect", "Redial a user session"), ("status", "Network status"),
            ("alarms", "Active alarms"), ("router", "MikroTik status"), ("olt", "OLT / PON status"),
            ("offline", "Offline ONUs of an OLT"), ("weak", "Weakest ONUs of an OLT"), ("open", "Open tickets"),
            ("ticket", "Show a ticket"), ("new", "Create a ticket"), ("help", "Help")]


def _call(method, token=None, _http_timeout=15, **payload):
    token = token or get_setting("tg_token")
    if not token:
        raise RuntimeError("Telegram bot token not set")
    r = httpx.post(API.format(token, method), json=payload, timeout=_http_timeout)
    data = r.json()
    if not data.get("ok"):
        raise RuntimeError(data.get("description", "Telegram error"))
    return data["result"]


def _fit(text, limit=3800):
    if len(text) <= limit:
        return text
    out, n = [], 0
    for ln in text.split("\n"):
        if n + len(ln) + 1 > limit - 20:
            break
        out.append(ln)
        n += len(ln) + 1
    return "\n".join(out) + "\n…"


def send(text, buttons=None, reply_to=None, chat_id=None, token=None, rows=None, keyboard=None):
    chat_id = chat_id or get_setting("tg_chat_id")
    if not chat_id:
        raise RuntimeError("Telegram chat ID not set")
    p = {"chat_id": chat_id, "text": _fit(text), "parse_mode": "HTML", "disable_web_page_preview": True}
    if rows:
        p["reply_markup"] = {"inline_keyboard": rows}
    elif buttons:
        p["reply_markup"] = {"inline_keyboard": [buttons]}
    elif keyboard:
        p["reply_markup"] = {"keyboard": [[{"text": t} for t in r] for r in keyboard], "resize_keyboard": True}
    if reply_to:
        p["reply_to_message_id"] = reply_to
        p["allow_sending_without_reply"] = True
    return _call("sendMessage", token=token, **p)


def buttons_for(cid):
    return [{"text": "⏳ Waiting for update", "callback_data": f"wait:{cid}"},
            {"text": "✅ Close", "callback_data": f"close:{cid}"}]


def draft_rows(cid):
    return [[{"text": "✅ Send reply (বাংলা)", "callback_data": f"cr:{cid}:bn"},
             {"text": "✅ Send reply (English)", "callback_data": f"cr:{cid}:en"}]]


def complaint_text(c, cust, lines=None):
    return (f"🎫 <b>New ticket #{c.id}</b>\n👤 {escape(cust.name or '-')}\n🆔 <code>{escape(cust.user_id)}</code>\n"
            f"📞 {escape(c.contact_phone or cust.phone or '-')}\n📂 {escape(c.category)}\n📝 {escape(c.message or '-')}\n\n"
            f"<i>↩️ Reply to this message to log a reply. Diagnosis follows below…</i>")


def diag_reply_text(c, d, drafts=True):
    txt = f"🔎 <b>Auto diagnosis · #{c.id}</b>\n" + "\n".join(escape(l) for l in d["report"])
    if drafts:
        txt += "\n\n✉️ <b>Draft reply (বাংলা)</b>\n<i>" + escape(d["reply_bn"]) + "</i>"
    return txt


def _remove_buttons(chat, mid):
    try:
        _call("editMessageReplyMarkup", chat_id=chat, message_id=mid, reply_markup={"inline_keyboard": []})
    except Exception:
        pass


def is_member(user_id):
    chat = get_setting("tg_chat_id")
    if not chat or not user_id:
        return False
    c = _member.get(user_id)
    if c and time.time() - c[0] < 300:
        return c[1]
    try:
        r = _call("getChatMember", chat_id=chat, user_id=user_id)
        ok = r.get("status") in ("creator", "administrator", "member") or (r.get("status") == "restricted" and r.get("is_member"))
    except Exception:
        ok = False
    _member[user_id] = (time.time(), ok)
    return ok


def _bg(fn, *a):
    def run():
        try:
            fn(*a)
        except Exception as e:
            first = a[0] if a else None
            cid = first if isinstance(first, (int, str)) else (
                ((first or {}).get("chat") or (first or {}).get("message", {}).get("chat") or {}).get("id"))
            try:
                send(f"⚠️ Error: {escape(str(e))[:300]}", chat_id=cid)
            except Exception:
                pass
    threading.Thread(target=run, daemon=True).start()


# ------------------------------------------------------------------ formatting
def bps(n):
    if n is None:
        return "-"
    return f"{n / 1e9:.2f} Gbps" if n >= 1e9 else (f"{n / 1e6:.2f} Mbps" if n >= 1e6 else f"{n / 1e3:.0f} Kbps")


def size(n):
    n = float(n or 0)
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or u == "TB":
            return f"{n:.1f} {u}" if u != "B" else f"{int(n)} B"
        n /= 1024


def sigbar(dbm):
    if dbm is None:
        return ""
    n = max(0, min(5, round((dbm + 30) / 22 * 5)))
    return "▰" * n + "▱" * (5 - n)


def user_card(d):
    m, o, dv, pg, an = d["mikrotik"], d.get("optical"), d.get("device"), d.get("ping"), d.get("analysis") or {}
    e = escape
    L = [f"<b>👤 {e(d.get('name') or d.get('uid') or d.get('mac') or '-')}</b>"]
    sub = []
    if d.get("uid"):
        sub.append(f"<code>{e(d['uid'])}</code>")
    if d.get("phone"):
        sub.append(f"📞 {e(d['phone'])}")
    if sub:
        L.append(" · ".join(sub))
    v = d["verdict"]
    L += ["━━━━━━━━━━━━━━━━━━", f"<b>🧾 {e(v['text'])}</b>"]
    ca = an.get("cause")
    if ca:
        L.append(f"🎯 <b>{e(ca['title'])}</b> <i>({e(ca['confidence'])} confidence)</i>")
        for i, s in enumerate(ca["steps"][:3], 1):
            L.append(f"   {i}. {e(s)}")
        if ca.get("escalate"):
            L.append("   🚩 <b>Escalate to the field team</b>")
    L.append("━━━━━━━━━━━━━━━━━━")
    if m.get("found"):
        st = {"online": "🟢 Online", "offline": "🔴 Offline", "disabled": "⛔ Disabled"}.get(m["state"], m["state"])
        L.append(f"<b>🌐 Session</b> · {st}" + (f" · up {e(m['uptime'])}" if m.get("uptime") else ""))
        rows = []
        if m.get("ip"):
            rows.append(f"IP <code>{e(m['ip'])}</code> · {e(m.get('router') or '')}")
        pool = m.get("profile_pool") or m.get("pool_by_ip")
        if m.get("profile") or pool:
            rows.append(f"Profile <b>{e(m.get('profile') or '-')}</b>" + (f" ({e(m['rate_limit'])})" if m.get("rate_limit") else "") + (f" · pool {e(pool)}" if pool else ""))
        t = (d.get("snmp") if d.get("snmp") and d["snmp"].get("ok") else m.get("traffic")) or {}
        if t.get("down_bps") is not None:
            rows.append(f"Speed ↓ {bps(t['down_bps'])} · ↑ {bps(t['up_bps'])}")
        s = m.get("session")
        if s and m["state"] == "online":
            rows.append(f"Session ↓ {size(s['down_bytes'])} · ↑ {size(s['up_bytes'])}")
        if m["state"] != "online":
            if m.get("last_disconnect_reason"):
                rows.append(f"Last disconnect: {e(m['last_disconnect_reason'])}")
            if m.get("last_logged_out"):
                rows.append(f"Last logout: {e(m['last_logged_out'])}")
        L += [("┣ " if i < len(rows) - 1 else "┗ ") + r for i, r in enumerate(rows)]
    else:
        L.append("<b>🌐 Session</b> · ❔ user not found on the routers")
    if dv:
        L.append(f"<b>📟 Customer router</b> · {e(dv.get('short') or dv.get('vendor') or 'Unknown brand')} · <code>{e(dv['mac'])}</code>")
    if pg and pg.get("ok"):
        L.append(f"<b>📡 Ping 20×100ms</b> · loss {pg['loss']}% · avg {pg.get('avg')} ms · max {pg.get('max')} ms · jitter {pg.get('jitter')} ms")
    if o and o.get("found"):
        f = o["fields"]
        fv = lambda k: (f.get(k) or {}).get("value")
        L.append(f"<b>🛰 Fiber</b> · {e(o['olt'])} ({e(o.get('vendor') or '-')})")
        rows = [f"PON <b>{e(o.get('pon') or '?')}</b> · ONU <b>{e(o.get('onu') or '?')}</b> · <code>{e(o.get('ifname'))}</code> · link {e(o.get('link') or '?')}" + (f" · VLAN {e(o['vlan'])}" if o.get("vlan") else "")]
        b = " / ".join(x for x in (fv("vendor"), fv("model")) if x)
        extra = ([f"brand {e(o['onu_brand'])}"] if o.get("onu_brand") else []) + ([f"MAC <code>{e(fv('mac'))}</code>"] if fv("mac") else [])
        if b or extra:
            rows.append("ONU " + e(b or "") + (" · " if b and extra else "") + " · ".join(extra))
        for k, lab in (("rx", "ONU Rx"), ("olt_rx", "OLT Rx")):
            x = f.get(k) or {}
            if x.get("value") is not None:
                q = {"good": "✅", "weak": "⚠️", "bad": "🚨", "high": "⚠️"}.get(x.get("quality"), "")
                rows.append(f"{lab} <b>{x['value']} dBm</b> {sigbar(x['value'])} {q}" + (" ⚠unverified" if x.get("conf") == "low" else ""))
        bits = ([f"Tx {fv('tx')} dBm"] if fv("tx") is not None else []) + ([f"{fv('distance')} m"] if fv("distance") is not None else []) + ([f"{fv('temp')} °C"] if fv("temp") is not None else []) + ([f"LAN {fv('uni_speed')} Mbps"] if fv("uni_speed") is not None else [])
        if bits:
            rows.append(" · ".join(bits))
        ph = d.get("pon_health")
        if ph:
            rows.append(f"PON {e(ph['pon'])}: {ph['online']}/{ph['total']} ONUs online")
        L += [("┣ " if i < len(rows) - 1 else "┗ ") + r for i, r in enumerate(rows)]
    elif o is not None:
        L.append("<b>🛰 Fiber</b> · ONU not found by router MAC")
    iss = [h for h in d["hints"] if h["level"] in ("err", "warn")]
    if iss:
        L.append("━━━━━━━━━━━━━━━━━━\n<b>⚠️ Findings</b>")
        L += [("🚨 " if h["level"] == "err" else "⚠️ ") + e(h["text"]) for h in iss[:7]]
    L.append(f"\n<i>Health score {an.get('score', '-')}/100 · {time.strftime('%H:%M:%S')}</i>")
    return "\n".join(L)


def _cb(prefix, uid):
    d = f"{prefix}:{uid}"
    return d if len(d.encode()) <= 64 else None


def card_rows(d):
    uid = d.get("uid")
    rows = []
    if uid:
        r1 = [{"text": t, "callback_data": c} for t, c in (("📈 Live", _cb("lv", uid)), ("📡 Ping", _cb("ping", uid)), ("🔄 Refresh", _cb("dg", uid))) if c]
        r2 = [{"text": t, "callback_data": c} for t, c in (("🛰 Fiber", _cb("fb", uid)), ("📜 Logs", _cb("lg", uid)), ("🎫 Tickets", _cb("ut", uid))) if c]
        r3 = [{"text": t, "callback_data": c} for t, c in (("⏏ Disconnect", _cb("dc", uid)),) if c]
        rows = [r for r in (r1, r2, r3) if r]
    return rows


def send_diag(chat, uid, mac=None):
    try:
        _call("sendChatAction", chat_id=chat, action="typing")
    except Exception:
        pass
    d = ctx.diagnose(uid, mac)
    rows = card_rows(d)
    open_t = d.get("tickets") or []
    if open_t:
        tid = open_t[0]["id"]
        with SessionLocal() as db:
            c = db.get(Complaint, tid)
            if c:
                try:
                    snap = json.loads(c.diag_json or "{}")
                except ValueError:
                    snap = {}
                snap.update(lines=d["report"], reply_bn=d["reply_bn"], reply_en=d["reply_en"])
                c.diag_json = json.dumps(snap, ensure_ascii=False)
                db.commit()
        rows = draft_rows(tid) + rows
    send(user_card(d), rows=rows or None, chat_id=chat)
    if open_t:
        send(f"✉️ <b>Draft reply for ticket #{open_t[0]['id']}</b>\n<i>{escape(d['reply_bn'])}</i>", chat_id=chat)


def send_fiber(chat, uid):
    d = ctx.diagnose(uid, None)
    o, l2 = d.get("optical"), d.get("l2") or {}
    if not o or not o.get("found"):
        send("🛰 ONU was not located on any OLT for this user." + (f"\nSearched MAC <code>{escape(d.get('mac') or '-')}</code>" if d.get("mac") else ""), chat_id=chat)
        return
    f = o["fields"]
    L = [f"<b>🛰 Fiber detail · {escape(uid)}</b>", f"MAC proof: router MAC <code>{escape(d.get('mac') or '-')}</code> was found in the MAC table of <b>{escape(o['olt'])}</b> on <code>{escape(o['ifname'])}</code>" + (f" (VLAN {escape(o['vlan'])})" if o.get("vlan") else "")]
    for k, v in f.items():
        L.append(f"• {escape(k)}: <b>{escape(v.get('value'))}</b> {escape(v.get('unit') or '')}" + (" ⚠" if v.get("conf") == "low" else ""))
    for c in l2.get("checked", []):
        L.append(f"{'✅' if c['state'] == 'found' else ('❌' if c['state'] == 'error' else '▫️')} {escape(c['olt'])}: {escape(c['state'])} {escape(c['detail'])}")
    send("\n".join(L), chat_id=chat)


def send_logs(chat, uid):
    d = ctx.diagnose(uid, None)
    logs = (d["mikrotik"].get("logs") or [])[-10:]
    send(f"<b>📜 Router log · {escape(uid)}</b>\n" + ("\n".join(f"<code>{escape(l.get('time'))}</code> {escape((l.get('message') or '')[:120])}" for l in logs) or "No log lines for this user."), chat_id=chat)


def do_live(chat, uid):
    routers = ctx.all_routers_fresh()
    s = []
    for _ in range(4):
        x = mikrotik.session_live(uid, routers)
        if not x.get("found"):
            send("📈 User is not online.", chat_id=chat)
            return
        s.append(x)
        time.sleep(1.5)
    rates = []
    for a, b in zip(s, s[1:]):
        dt = b["ts"] - a["ts"]
        if dt > 0:
            rates.append(((b["down_bytes"] - a["down_bytes"]) * 8 / dt, (b["up_bytes"] - a["up_bytes"]) * 8 / dt))
    if not rates:
        send("📈 Could not measure.", chat_id=chat)
        return
    avgd, avgu = sum(r[0] for r in rates) / len(rates), sum(r[1] for r in rates) / len(rates)
    send(f"📈 <b>Live · {escape(uid)}</b>\n↓ {bps(avgd)} (peak {bps(max(r[0] for r in rates))})\n↑ {bps(avgu)} (peak {bps(max(r[1] for r in rates))})\n"
         f"Session ↓ {size(s[-1]['down_bytes'])} · ↑ {size(s[-1]['up_bytes'])} · up {escape(s[-1].get('uptime') or '')}", chat_id=chat)


def do_ping(chat, uid):
    p = mikrotik.ping(uid, ctx.all_routers_fresh())
    if p.get("ok"):
        bars = "".join("▁▂▃▄▅▆▇█"[min(7, int((t or 0) / max(p["max"] or 1, 1) * 7))] if t is not None else "✖" for t in p["times"])
        txt = (f"📡 <b>Ping {escape(p['ip'])}</b> · 20 × 100 ms from the router\n<code>{bars}</code>\nSent/received {p['sent']}/{p['received']} · loss {p['loss']}%\n"
               f"min/avg/max {p['min']}/{p['avg']}/{p['max']} ms · jitter {p['jitter']} ms")
    else:
        txt = "📡 " + escape(p.get("error", "ping failed"))
    send(txt, chat_id=chat)


def ask_disconnect(chat, uid):
    if get_setting("tg_allow_disconnect", "1") != "1":
        send("⛔ Disconnect from Telegram is disabled in Settings.", chat_id=chat)
        return
    y, n = _cb("dcy", uid), "x:0"
    send(f"⏏ <b>Disconnect {escape(uid)}?</b>\nThe session is removed and the customer router redials.",
         rows=[[{"text": "✅ Yes, disconnect", "callback_data": y}, {"text": "❌ Cancel", "callback_data": n}]] if y else None, chat_id=chat)


def do_disconnect(chat, uid, who):
    if get_setting("tg_allow_disconnect", "1") != "1":
        send("⛔ Disconnect from Telegram is disabled in Settings.", chat_id=chat)
        return
    r = mikrotik.disconnect(uid, ctx.all_routers_fresh())
    with SessionLocal() as db:
        audit(db, f"telegram: {who}", "disconnect", uid, "ok" if r.get("ok") else r.get("error", ""))
    send(f"⏏ {escape(uid)}: " + ("session removed ✅, waiting for redial" if r.get("ok") else escape(r.get("error", "failed"))), chat_id=chat)
    if r.get("ok"):
        for _ in range(12):
            time.sleep(2)
            if mikrotik.session_live(uid, ctx.all_routers_fresh()).get("found"):
                send(f"🟢 {escape(uid)} reconnected.", chat_id=chat)
                return
        send(f"🔴 {escape(uid)} has not reconnected yet.", chat_id=chat)


def do_search(chat, q, diag_if_exact=True):
    with SessionLocal() as db:
        res = ctx.find(db, q, 10)
    if not res:
        send(f"No user found for <code>{escape(q)}</code>.\nTry the first 2-3 letters of the user ID or name.", chat_id=chat)
        return
    exact = [r for r in res if r["uid"].lower() == q.lower() or r.get("source") == "mac"]
    if exact and diag_if_exact:
        send_diag(chat, exact[0]["uid"], exact[0].get("mac"))
        return
    lines, rows = [], []
    for r in res:
        on = {True: "🟢", False: "🔴"}.get(r.get("online"), "⚪")
        lines.append(f"{on} <code>{escape(r['uid'] or r.get('mac', ''))}</code> · {escape(r['name'] or '-')} · {escape(r['phone'] or '-')}")
        data = _cb("dg", r["uid"]) if r["uid"] else f"dm:{r.get('mac')}"
        if data:
            rows.append([{"text": f"{on} {r['uid'] or r.get('mac')} {('· ' + r['name']) if r['name'] else ''}"[:48], "callback_data": data}])
    send(f"<b>Suggestions for “{escape(q)}”</b> · tap to open\n" + "\n".join(lines), rows=rows, chat_id=chat)


# ------------------------------------------------------------------ network commands
def cmd_alarms(chat):
    with SessionLocal() as db:
        al = db.query(Alarm).filter(Alarm.cleared_at.is_(None)).order_by(Alarm.id.desc()).limit(12).all()
        lines = [f"{'🚨' if a.level == 'critical' else '⚠️'} <b>{escape(a.device)}</b> · {escape(a.message)}" + (f" · ✔ {escape(a.ack_by)}" if a.ack_by else "") for a in al]
        rows = [[{"text": f"✔ Ack #{a.id}", "callback_data": f"ak:{a.id}"}] for a in al if not a.ack_by][:6]
    send("<b>🚨 Active alarms</b>\n" + ("\n".join(lines) if lines else "✅ None"), rows=rows or None, chat_id=chat)


def cmd_router(chat, name=""):
    import monitor
    rs = [r for r in monitor.snapshot().get("routers", []) if not name or name.lower() in r["name"].lower()]
    if not rs:
        send("No router matches (or the first poll has not finished yet).", chat_id=chat)
        return
    L = []
    for r in rs:
        if not r.get("ok"):
            L.append(f"🖧 <b>{escape(r['name'])}</b> 🔴 unreachable · {escape(r.get('error') or '')}")
            continue
        L.append(f"🖧 <b>{escape(r['name'])}</b> 🟢 {escape(r.get('identity') or '')}\n┣ CPU {r.get('cpu')}% · RAM {r.get('mem_pct')}%\n┣ PPPoE users <b>{r.get('active')}</b>\n┗ {escape(r.get('version') or '')} · {escape(r.get('board') or '')} · up {escape(r.get('uptime') or '')}")
    send("\n\n".join(L), chat_id=chat)


def cmd_olt(chat, name=""):
    import monitor
    os_ = [o for o in monitor.snapshot().get("olts", []) if not name or name.lower() in o["name"].lower()]
    if not os_:
        send("No OLT matches (or the first poll has not finished yet).", chat_id=chat)
        return
    for o in os_:
        if not o.get("ok"):
            send(f"🛰 <b>{escape(o['name'])}</b> 🔴 unreachable · {escape(o.get('error') or '')}", chat_id=chat)
            continue
        L = [f"🛰 <b>{escape(o['name'])}</b> 🟢 ONU <b>{o.get('onu_online')}/{o.get('onu_total')}</b> online"]
        for p in o.get("pons", []):
            ic = "🔴" if (p["total"] and not p["up"]) else ("🟡" if p["total"] and p["online"] < 0.7 * p["total"] else "🟢")
            L.append(f"{ic} PON {escape(p['pon'])}: {p['online']}/{p['total']}" + ("" if p["up"] else " · port DOWN"))
        send("\n".join(L), chat_id=chat)


def _olt_by_name(name):
    with SessionLocal() as db:
        for o in ctx.olt_dicts(db):
            if name.lower() in o["name"].lower():
                return o
    return None


def cmd_offline(chat, name):
    import olt as oltlib
    o = _olt_by_name(name)
    if not o:
        send("Usage: /offline &lt;olt name&gt;", chat_id=chat)
        return
    send("⏳ Reading ONU table…", chat_id=chat)
    d = oltlib.details(o)
    off = [x for x in d["onus"] if not x["up"]]
    L = [f"<b>🛰 {escape(o['name'])}</b> · {len(off)} of {len(d['onus'])} ONUs offline"]
    for x in off[:40]:
        L.append(f"🔴 <code>{escape(x['name'])}</code> {escape(x['alias'])}")
    send("\n".join(L), chat_id=chat)


def cmd_weak(chat, name):
    import olt as oltlib
    o = _olt_by_name(name)
    if not o:
        send("Usage: /weak &lt;olt name&gt;", chat_id=chat)
        return
    send("⏳ Scanning ONU Rx power (1-2 min)…", chat_id=chat)
    r = oltlib.scan(o, o["profile"])
    L = [f"<b>📉 Weakest ONUs · {escape(o['name'])}</b> ({r['total']} scanned)"]
    for x in [x for x in r["rows"] if x["rx"] is not None][:15]:
        ic = {"bad": "🚨", "weak": "⚠️", "high": "⚠️"}.get(x["quality"], "✅")
        L.append(f"{ic} <code>{escape(x['name'])}</code> {x['rx']} dBm {sigbar(x['rx'])}")
    send("\n".join(L), chat_id=chat)


# ------------------------------------------------------------------ tickets
def ticket_view(cid):
    with SessionLocal() as db:
        c = db.get(Complaint, cid)
        if not c:
            return None, None
        cu = c.customer
        t = [f"🎫 <b>#{c.id}</b> · {escape(STATUS_LABEL.get(c.status, c.status))}", f"👤 {escape(cu.name or '-')} · <code>{escape(cu.user_id)}</code>",
             f"📞 {escape(c.contact_phone or cu.phone or '-')}", f"📂 {escape(c.category)}"]
        if c.message:
            t.append("📝 " + escape(c.message))
        if c.pon:
            t.append(f"🛰 {escape(c.olt_name)} · PON {escape(c.pon)}")
        for r in c.replies[-6:]:
            t.append(f"{ {'wait': '⏳', 'close': '✅'}.get(r.kind, '💬') } <i>{escape(r.author)}</i> {escape(r.message or '')}")
        rows = [buttons_for(c.id)] if c.status != "closed" else []
        if _cb("dg", cu.user_id):
            rows.append([{"text": "🔎 Diagnose", "callback_data": _cb("dg", cu.user_id)}])
        return "\n".join(t), rows


def send_ticket(chat, cid):
    text, rows = ticket_view(cid)
    send(text or f"Ticket #{cid} not found.", rows=rows, chat_id=chat)


def list_open(chat):
    with SessionLocal() as db:
        items = db.query(Complaint).filter(Complaint.status != "closed").order_by(Complaint.id.desc()).limit(12).all()
        lines = [f"#{c.id} · {escape(c.customer.name or c.customer.user_id)} · {escape(c.category)} · {escape(STATUS_LABEL.get(c.status, c.status))}" for c in items]
        ids = [c.id for c in items]
    if not ids:
        send("🎉 No open tickets.", chat_id=chat)
        return
    rows = [[{"text": f"#{i}", "callback_data": f"tk:{i}"} for i in ids[k:k + 4]] for k in range(0, len(ids), 4)]
    send("<b>Open tickets</b>\n" + "\n".join(lines), rows=rows, chat_id=chat)


def user_tickets(chat, uid):
    with SessionLocal() as db:
        cu = db.query(Customer).filter_by(user_id=uid).first()
        items = list(cu.complaints[:6]) if cu else []
        lines = [f"#{c.id} · {escape(c.category)} · {escape(STATUS_LABEL.get(c.status, c.status))}" for c in items]
        ids = [c.id for c in items]
    send(("<b>Tickets</b> for <code>" + escape(uid) + "</code>\n" + "\n".join(lines)) if lines else "No tickets for this user.",
         rows=[[{"text": f"#{i}", "callback_data": f"tk:{i}"} for i in ids]] if ids else None, chat_id=chat)


def new_ticket(chat, arg, who):
    import cases
    uid, _, note = arg.partition(" ")
    if not uid:
        send("Usage: /new &lt;user id&gt; [note]", chat_id=chat)
        return
    with SessionLocal() as db:
        cm = cases.create_ticket(db, uid, "Other", note or "Created from Telegram", who)
        cid = cm.id if cm else None
    if not cid:
        send(f"User <code>{escape(uid)}</code> was not found on the routers.", chat_id=chat)
        return
    send(f"🎫 Ticket <b>#{cid}</b> created for <code>{escape(uid)}</code>. Diagnosis follows in the group.", chat_id=chat)
    _bg(cases.notify_new, cid)


# ------------------------------------------------------------------ routing
def handle_reply(m):
    if str((m.get("chat") or {}).get("id", "")) != str(get_setting("tg_chat_id")):
        return
    rid = m["reply_to_message"]["message_id"]
    who = (m.get("from") or {}).get("first_name", "staff")
    with SessionLocal() as db:
        c = db.query(Complaint).filter((Complaint.tg_message_id == rid) | (Complaint.tg_diag_message_id == rid)).first()
        if not c or c.status == "closed":
            return
        cid = c.id
        apply_action(db, cid, "reply", who, m["text"], "staff")
    try:
        send(f"💬 Reply logged on ticket #{cid}", reply_to=m["message_id"])
    except Exception:
        pass


def handle_message(m):
    text = (m.get("text") or "").strip()
    frm = m.get("from") or {}
    chat = m["chat"]
    if not text or frm.get("is_bot"):
        return
    private = chat.get("type") == "private"
    in_group = str(chat["id"]) == str(get_setting("tg_chat_id"))
    if not (private or in_group):
        return
    if not text.startswith("/"):
        if in_group and m.get("reply_to_message"):
            return handle_reply(m)
        if not private:
            return
    if not is_member(frm.get("id")):
        if private:
            send("⛔ Only members of the support group can use this bot.", chat_id=chat["id"])
        return
    cid = chat["id"]
    who = frm.get("first_name", "?")
    menu = {"🔎 Search user": "/diag", "📊 Status": "/status", "🚨 Alarms": "/alarms", "🎫 Tickets": "/open", "🛰 OLTs": "/olt", "🖧 Routers": "/router"}
    if text in menu:
        text = menu[text]
        if text == "/diag":
            send("🔎 Type the user ID, 2-3 letters of the name, a phone number or a MAC address.", chat_id=cid)
            return
    if text.startswith("/"):
        cmd, _, arg = text.partition(" ")
        cmd, arg = cmd.split("@")[0].lower(), arg.strip()
    else:
        cmd, arg = "/diag", text
    if cmd in ("/start", "/help"):
        send(HELP, chat_id=cid, keyboard=KB if private else None)
    elif cmd in ("/diag", "/user", "/search", "/mac"):
        if len(arg) < 2:
            send("Usage: /diag &lt;user id | name | phone | MAC&gt; (at least 2 letters)", chat_id=cid)
        else:
            do_search(cid, arg, diag_if_exact=(cmd != "/search"))
    elif cmd == "/live":
        _bg(do_live, cid, arg) if arg else send("Usage: /live &lt;user id&gt;", chat_id=cid)
    elif cmd == "/ping":
        _bg(do_ping, cid, arg) if arg else send("Usage: /ping &lt;user id&gt;", chat_id=cid)
    elif cmd == "/disconnect":
        ask_disconnect(cid, arg) if arg else send("Usage: /disconnect &lt;user id&gt;", chat_id=cid)
    elif cmd in ("/status", "/report"):
        import monitor
        send(monitor.report_text(), chat_id=cid)
    elif cmd == "/alarms":
        cmd_alarms(cid)
    elif cmd == "/router":
        cmd_router(cid, arg)
    elif cmd == "/olt":
        cmd_olt(cid, arg)
    elif cmd == "/offline":
        _bg(cmd_offline, cid, arg)
    elif cmd == "/weak":
        _bg(cmd_weak, cid, arg)
    elif cmd == "/open":
        list_open(cid)
    elif cmd == "/ticket":
        send_ticket(cid, int(arg)) if arg.isdigit() else send("Usage: /ticket &lt;number&gt;", chat_id=cid)
    elif cmd == "/new":
        new_ticket(cid, arg, who)
    elif cmd in ("/wait", "/close", "/reply"):
        n, _, rest = arg.partition(" ")
        if not n.isdigit() or (cmd == "/reply" and not rest.strip()):
            send(f"Usage: {cmd} &lt;ticket number&gt;" + (" &lt;text&gt;" if cmd == "/reply" else ""), chat_id=cid)
            return
        act = cmd[1:]
        with SessionLocal() as db:
            c = apply_action(db, int(n), act, f"telegram: {who}", rest)
        msg = {"wait": "⏳ Waiting for update", "close": "✅ Closed", "reply": "💬 Reply logged"}[act]
        send(f"{msg}: #{n}" if c else f"Ticket #{n} not found or already closed.", chat_id=cid)
    elif cmd == "/whoami":
        send(f"You: {escape(who)} · id <code>{frm.get('id')}</code> · chat <code>{cid}</code>", chat_id=cid)
    else:
        send(HELP, chat_id=cid)


def _answer(cq_id, text=""):
    try:
        _call("answerCallbackQuery", callback_query_id=cq_id, text=text)
    except Exception:
        pass


def handle_callback(cq):
    data = cq.get("data", "")
    msg = cq.get("message") or {}
    chat = (msg.get("chat") or {}).get("id")
    frm = cq.get("from") or {}
    group = str(get_setting("tg_chat_id"))
    if not (str(chat) == group or is_member(frm.get("id"))):
        _answer(cq["id"], "Not allowed")
        return
    act, _, arg = data.partition(":")
    who = frm.get("first_name", "?")
    if act in ("wait", "close", "resolve"):
        act = "close" if act == "resolve" else act
        if not arg.isdigit():
            return
        with SessionLocal() as db:
            c = apply_action(db, int(arg), act, f"telegram: {who}")
        _answer(cq["id"], "Done ✅" if c else "Already closed")
        if c:
            if act == "close":
                _remove_buttons(chat, msg.get("message_id"))
            try:
                send(f"{'⏳ Waiting for update' if act == 'wait' else '✅ Closed'}: ticket #{arg} by {escape(who)}",
                     reply_to=msg.get("message_id") if str(chat) == group else None)
            except Exception:
                pass
        return
    if act == "cr":
        cid_s, _, lang = arg.partition(":")
        text = None
        with SessionLocal() as db:
            c = db.get(Complaint, int(cid_s)) if cid_s.isdigit() else None
            if c and c.status != "closed":
                try:
                    text = json.loads(c.diag_json or "{}").get("reply_" + ("en" if lang == "en" else "bn"))
                except ValueError:
                    text = None
                if text:
                    apply_action(db, c.id, "reply", f"telegram: {who}", text, "staff")
        _answer(cq["id"], "Logged ✅" if text else "No draft / ticket closed")
        if text:
            _remove_buttons(chat, msg.get("message_id"))
            try:
                send(f"💬 Reply logged on ticket #{cid_s} by {escape(who)}. Copy the message and send it to the customer:\n\n<i>{escape(text)}</i>", chat_id=chat)
            except Exception:
                pass
        return
    if act == "ak":
        with SessionLocal() as db:
            a = db.get(Alarm, int(arg)) if arg.isdigit() else None
            if a:
                a.ack_by = f"telegram: {who}"
                db.commit()
        _answer(cq["id"], "Acknowledged ✔")
        return
    if act == "x":
        _answer(cq["id"], "Cancelled")
        _remove_buttons(chat, msg.get("message_id"))
        return
    _answer(cq["id"], "Working…")
    if act == "dg":
        _bg(send_diag, chat, arg)
    elif act == "dm":
        _bg(send_diag, chat, "", arg)
    elif act == "lv":
        _bg(do_live, chat, arg)
    elif act == "ping":
        _bg(do_ping, chat, arg)
    elif act == "fb":
        _bg(send_fiber, chat, arg)
    elif act == "lg":
        _bg(send_logs, chat, arg)
    elif act == "dc":
        ask_disconnect(chat, arg)
    elif act == "dcy":
        _remove_buttons(chat, msg.get("message_id"))
        _bg(do_disconnect, chat, arg, who)
    elif act == "ut":
        _bg(user_tickets, chat, arg)
    elif act == "tk" and arg.isdigit():
        _bg(send_ticket, chat, int(arg))


def handle_inline(iq):
    if not is_member((iq.get("from") or {}).get("id")):
        _call("answerInlineQuery", inline_query_id=iq["id"], results=[], cache_time=5, is_personal=True)
        return
    q = (iq.get("query") or "").strip()
    results = []
    if len(q) >= 2:
        with SessionLocal() as db:
            for r in ctx.suggest(db, q, 15):
                on = {True: "🟢 online", False: "🔴 offline"}.get(r.get("online"), "")
                results.append({"type": "article", "id": r["uid"][:60], "title": r["uid"],
                                "description": " · ".join(x for x in (r["name"], r["phone"], on) if x) or "PPPoE user",
                                "input_message_content": {"message_text": f"/diag {r['uid']}"}})
    _call("answerInlineQuery", inline_query_id=iq["id"], results=results, cache_time=3, is_personal=True)


def poll_loop():
    offset, last_token = None, None
    while True:
        token = get_setting("tg_token")
        if not token:
            time.sleep(10)
            continue
        if token != last_token:
            offset, last_token = None, token
            try:
                _call("setMyCommands", token=token, commands=[dict(command=c, description=d) for c, d in COMMANDS])
            except Exception:
                pass
        try:
            p = {"timeout": 25, "allowed_updates": ["callback_query", "message", "my_chat_member", "inline_query"]}
            if offset:
                p["offset"] = offset
            for u in _call("getUpdates", token=token, _http_timeout=35, **p):
                offset = u["update_id"] + 1
                if "callback_query" in u:
                    _bg(handle_callback, u["callback_query"])
                if "inline_query" in u:
                    _bg(handle_inline, u["inline_query"])
                m = u.get("message")
                if m and m.get("text"):
                    _bg(handle_message, m)
                for k in ("message", "my_chat_member"):
                    ch = (u.get(k) or {}).get("chat")
                    if ch:
                        seen_chats[str(ch["id"])] = ch.get("title") or ch.get("first_name") or "private"
        except Exception:
            time.sleep(5)


def start_poller():
    threading.Thread(target=poll_loop, daemon=True).start()
