"""Shared helpers: DB -> plain dicts for routers/OLTs, live CCR active search, and the one-call diagnosis."""
import json
import statistics
from datetime import datetime, timedelta

import diag
import mikrotik
import olt as oltlib
import rusers
import snmp
import util
from db import OLT, Complaint, Customer, OltProfile, Router, Sample, SessionLocal


def router_dicts(db, prefer=None):
    rs = db.query(Router).all()
    rs.sort(key=lambda r: r.id != prefer)
    return [dict(id=r.id, name=r.name, host=r.host, port=r.port, username=r.username, password=r.password,
                 use_ssl=r.use_ssl, api_enabled=r.api_enabled is not False, snmp_enabled=bool(r.snmp_enabled),
                 snmp_port=r.snmp_port or 161, snmp_community=r.snmp_community or "public") for r in rs]


def all_routers_fresh():
    with SessionLocal() as db:
        return router_dicts(db)


def profile_dict(p):
    if not p:
        return dict(id=None, name="(no profile)", enterprise_oid="", index_template="{ifindex}", oids={}, status_map={})
    try:
        oids = json.loads(p.oids or "{}")
    except ValueError:
        oids = {}
    return dict(id=p.id, name=p.name, enterprise_oid=p.enterprise_oid or "", index_template=p.index_template or "{ifindex}",
                oids=oids, status_map=oltlib.parse_status_map(p.status_map))


def olt_dict(o, profs):
    prof = profs.get(o.profile_id)
    # Fallback: if OLT has no profile_id assigned, match by vendor name automatically
    if not prof:
        v = (o.vendor or "").lower()
        for cand in profs.values():
            if (cand.vendor or "").lower() == v:
                prof = cand
                break
    return dict(id=o.id, name=o.name, vendor=o.vendor, host=o.host, port=o.snmp_port or 161,
                community=o.community or "public", version=o.snmp_version or "2c",
                vlans=[v.strip() for v in (o.vlans or "").split(",") if v.strip()],
                profile=profile_dict(prof))


def olt_dicts(db):
    profs = {p.id: p for p in db.query(OltProfile)}
    return [olt_dict(o, profs) for o in db.query(OLT).filter(OLT.enabled.is_(True))]


def suggest(db, q, limit=12):
    """Live suggestions from MikroTik/CCR active PPPoE connections + PPP secrets + DB metadata."""
    q = (q or "").strip()
    if not q:
        return []
    ql = q.lower()
    phone = util.norm_phone(q)

    # 1. Check cached CCR active/secret directory first
    cached_hits = rusers.search(q, limit * 2)
    online_hits = [u for u in cached_hits if u.get("online")]

    # 2. If cache is cold, stale (>20s), or has few active matches, query MikroTik/CCR active connections live via API
    live_hits = []
    if len(online_hits) < 5 or rusers.last_age() > 20:
        routers = router_dicts(db)
        if routers:
            live_hits = mikrotik.search_active_live(q, routers, limit=limit)
            if live_hits:
                rusers.merge_live(live_hits)

    # 3. Query local Customer DB metadata
    cond = Customer.user_id.ilike(f"%{q}%") | Customer.name.ilike(f"%{q}%") | Customer.onu_mac.ilike(f"%{q}%")
    if len(phone) >= 4:
        cond = cond | Customer.phone.ilike(f"%{phone}%")
    db_rows = db.query(Customer).filter(cond).limit(50).all()
    db_map = {c.user_id.lower(): c for c in db_rows if c.user_id}

    out, seen = [], set()

    def _add_item(uid, name="", phone_val="", ip="", mac="", router="", uptime="", profile="", online=None, source="router"):
        key = uid.lower()
        if not uid or key in seen:
            return
        seen.add(key)
        c = db_map.get(key)
        u = rusers.get(uid) or {}
        final_online = online if online is not None else u.get("online")
        final_router = router or u.get("router") or ""
        out.append(dict(
            uid=uid,
            name=name or (c.name if c else "") or u.get("name", ""),
            phone=phone_val or (c.phone if c else "") or u.get("phone", ""),
            ip=ip or u.get("ip", ""),
            mac=mac or u.get("mac", ""),
            router=final_router,
            uptime=uptime or u.get("uptime", ""),
            profile=profile or u.get("profile", ""),
            source=f"CCR · {final_router}" if final_router else source,
            online=final_online,
        ))

    # Prioritize live active CCR matches, then cached CCR matches, then DB matches
    for u in live_hits:
        _add_item(u["uid"], u.get("name"), u.get("phone"), u.get("ip"), u.get("mac"),
                  u.get("router"), u.get("uptime"), u.get("profile"), u.get("online"), u.get("source", "CCR Active"))
    for u in cached_hits:
        _add_item(u["uid"], u.get("name"), u.get("phone"), u.get("ip"), u.get("mac"),
                  u.get("router"), u.get("uptime"), u.get("profile"), u.get("online"), "CCR")
    for c in db_rows:
        _add_item(c.user_id, c.name, c.phone, source="Saved")

    out.sort(key=lambda x: (not bool(x.get("online")), not x["uid"].lower().startswith(ql), x["uid"].lower()))
    return out[:limit]


def find(db, q, limit=12):
    q = (q or "").strip()
    if util.looks_mac(q):
        mac = snmp.norm_mac(q)
        uid = mikrotik.find_by_mac(mac, router_dicts(db))
        if uid:
            u = rusers.get(uid) or {}
            c = db.query(Customer).filter_by(user_id=uid).first()
            return [dict(
                uid=uid,
                name=(c.name if c else "") or u.get("name", ""),
                phone=(c.phone if c else "") or u.get("phone", ""),
                ip=u.get("ip", ""),
                router=u.get("router", ""),
                source="CCR MAC match",
                online=True,
                mac=mac,
            )]
        return [dict(uid="", name="(MAC only — locating directly on OLT)", phone="", ip="", router="", source="OLT MAC", online=None, mac=mac)]
    return suggest(db, q, limit)


def diagnose(uid, mac=None, exclude=None):
    with SessionLocal() as db:
        # Auto-adopt user from CCR if not yet in Customer table
        cust = db.query(Customer).filter_by(user_id=uid).first() if uid else None
        if uid and not cust:
            try:
                import cases
                cust = cases.adopt_router_user(db, uid)
            except Exception:
                cust = None
        hist, name, phone, address, onu_mac_saved = None, "", "", "", ""
        if cust:
            name, phone, address, onu_mac_saved = cust.name or "", cust.phone or "", cust.address or "", cust.onu_mac or ""
            q = db.query(Complaint).filter(Complaint.customer_id == cust.id,
                                           Complaint.created_at >= datetime.utcnow() - timedelta(days=30))
            if exclude:
                q = q.filter(Complaint.id != exclude)
            hist = dict(count30=q.count())
        u = rusers.get(uid) if uid else None
        if u:
            name, phone = name or u.get("name", ""), phone or u.get("phone", "")
        d = diag.collect(uid, mac, onu_mac_saved or None,
                         router_dicts(db, cust.router_id if cust else None), olt_dicts(db), history=hist)
        # If comment on router had name/phone and DB didn't, parse it automatically
        if (not name or not phone) and (d.get("mikrotik") or {}).get("comment"):
            cname, cphone = util.parse_comment(d["mikrotik"]["comment"])
            name = name or cname
            phone = phone or cphone
        d["name"], d["phone"], d["address"], d["onu_mac_saved"] = name, phone, address, onu_mac_saved
        _extras(db, d, uid)
        diag.finalize(d)
        d["reply_bn"] = diag.customer_reply(d, "bn", name)
        d["reply_en"] = diag.customer_reply(d, "en", name)
        d["tickets"] = [dict(id=c.id, category=c.category, status=c.status, message=c.message)
                        for c in (cust.complaints if cust else []) if c.status != "closed"]
        return d


def _extras(db, d, uid):
    """PON neighbours, signal history/trend; also records this check as a sample."""
    opt = d.get("optical") or {}
    if opt.get("found") and opt.get("pon"):
        try:
            import monitor
            for o in monitor.snapshot().get("olts", []):
                if o.get("name") == opt["olt"]:
                    for p in o.get("pons", []):
                        if p["pon"] == opt["pon"]:
                            d["pon_health"] = dict(olt=o["name"], pon=p["pon"], online=p["online"], total=p["total"], up=p["up"])
        except Exception:
            pass
    if not uid:
        return
    rows = db.query(Sample).filter(Sample.uid == uid).order_by(Sample.id.desc()).limit(40).all()
    f = opt.get("fields", {}) if opt.get("found") else {}
    rx = (f.get("rx") or {}).get("value")
    prev = [r.rx for r in rows if r.rx is not None]
    if rx is not None and len(prev) >= 3:
        med = statistics.median(prev)
        d["trend"] = dict(delta=round(rx - med, 1), median=round(med, 1))
    mt, pg = d["mikrotik"], d.get("ping") or {}
    if mt.get("found") and (not rows or (datetime.utcnow() - rows[0].ts).total_seconds() > 300):
        db.add(Sample(uid=uid, state=mt.get("state") or "", rx=rx, tx=(f.get("tx") or {}).get("value"),
                      olt_rx=(f.get("olt_rx") or {}).get("value"), distance=(f.get("distance") or {}).get("value"),
                      loss=pg.get("loss"), avg=pg.get("avg"), jitter=pg.get("jitter"), olt=opt.get("olt") or "", pon=opt.get("pon") or ""))
        db.commit()
        for old in db.query(Sample).filter(Sample.uid == uid).order_by(Sample.id.desc()).offset(300).all():
            db.delete(old)
        db.commit()
    d["samples"] = [dict(ts=int(r.ts.replace(tzinfo=None).timestamp()), state=r.state, rx=r.rx, tx=r.tx, olt_rx=r.olt_rx,
                         avg=r.avg, loss=r.loss, distance=r.distance) for r in reversed(rows)]
