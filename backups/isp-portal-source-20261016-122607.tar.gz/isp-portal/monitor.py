"""Background health monitor: routers (API/SNMP) + OLTs (IF-MIB) + VLAN-only Interface Watch."""
import collections
import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from html import escape

import ctx
import mikrotik
import notify
import olt as oltlib
import telegram_bot
from db import OLT, Alarm, IfaceWatch, OltProfile, SessionLocal, Tunnel, get_setting

log = logging.getLogger("monitor")
SNAP = dict(ts=0, interval=30, routers=[], olts=[], ifaces=[])
HIST = {}                 # key -> deque[(ts, value)]
FAILS = collections.Counter()
_lock = threading.Lock()
_poll_lock = threading.Lock()


def cfg(key, default):
    try:
        return float(get_setting(key, "") or default)
    except ValueError:
        return float(default)


def _hist(key, val, window=3600):
    d = HIST.setdefault(key, collections.deque(maxlen=240))
    now = time.time()
    peak = max([v for t, v in d if now - t <= window] or [val])
    d.append((now, val))
    return peak


# ------------------------------------------------------------------ alarms
def _notify(text, level="warning", title="Network alarm", event="alarm"):
    try:
        telegram_bot.send(text)
    except Exception:
        pass
    try:
        notify.dispatch(event, level, title, text)
    except Exception:
        pass


def raise_alarm(key, level, device, message):
    with SessionLocal() as db:
        a = db.query(Alarm).filter(Alarm.key == key, Alarm.cleared_at.is_(None)).first()
        if a:
            changed = a.level != level
            a.last_seen, a.message, a.level = datetime.utcnow(), message, level
            db.commit()
            if changed and level == "critical":
                _notify(f"🚨 <b>ALARM escalated</b> · {escape(device)}\n{escape(message)}", "critical", device)
            return
        db.add(Alarm(key=key, level=level, device=device, message=message))
        db.commit()
    _notify(f"{'🚨' if level == 'critical' else '⚠️'} <b>ALARM</b> · {escape(device)}\n{escape(message)}", level, device)


def clear_alarm(key):
    with SessionLocal() as db:
        a = db.query(Alarm).filter(Alarm.key == key, Alarm.cleared_at.is_(None)).first()
        if not a:
            return
        a.cleared_at = datetime.utcnow()
        dev, msg = a.device, a.message
        db.commit()
    _notify(f"✅ <b>Resolved</b> · {escape(dev)}\n{escape(msg)}", "info", dev)


# ------------------------------------------------------------------ evaluation
def evaluate_router(r, s):
    key = f"router:{r['id']}"
    name = r["name"]
    if not s["ok"]:
        FAILS[key] += 1
        if FAILS[key] >= 2:
            raise_alarm(key + ":down", "critical", name, f"Router unreachable ({s.get('error') or 'no response'})")
        return
    FAILS[key] = 0
    clear_alarm(key + ":down")
    cpu = s.get("cpu")
    if cpu is not None:
        crit, warn = cfg("mon_cpu_crit", 95), cfg("mon_cpu_warn", 85)
        if cpu >= crit:
            raise_alarm(key + ":cpu", "critical", name, f"CPU load {cpu}%")
        elif cpu >= warn:
            raise_alarm(key + ":cpu", "warning", name, f"CPU load {cpu}%")
        else:
            clear_alarm(key + ":cpu")
    if s.get("active") is not None:
        peak = _hist(("r", r["id"], "active"), s["active"])
        pct = cfg("mon_drop_pct", 20)
        if peak >= 50 and s["active"] <= peak * (1 - pct / 100):
            raise_alarm(key + ":users", "critical", name, f"Active PPPoE users dropped: {peak} → {s['active']}")
        elif s["active"] >= peak * (1 - pct / 200):
            clear_alarm(key + ":users")


def evaluate_olt(o, s):
    key = f"olt:{o['id']}"
    name = o["name"]
    if not s["ok"]:
        FAILS[key] += 1
        if FAILS[key] >= 2:
            raise_alarm(key + ":down", "critical", name, f"OLT unreachable over SNMP ({s.get('error') or 'no response'})")
        return
    FAILS[key] = 0
    clear_alarm(key + ":down")
    pct = cfg("mon_pon_drop_pct", 50)
    for p in s["pons"]:
        k = f"{key}:pon:{p['pon']}"
        if p["total"] > 0 and not p["up"]:
            raise_alarm(k + ":down", "critical", name, f"PON {p['pon']} is DOWN ({p['total']} ONUs registered)")
        else:
            clear_alarm(k + ":down")
        base = _hist(("o", o["id"], p["pon"]), p["online"])
        if base >= 4 and p["online"] <= base * (1 - pct / 100) and p["up"]:
            raise_alarm(k + ":drop", "critical", name, f"PON {p['pon']}: ONUs online dropped {base} → {p['online']}")
        elif p["online"] >= base * (1 - pct / 200):
            clear_alarm(k + ":drop")
    if s["onu_supported"]:
        base = _hist(("o", o["id"], "all"), s["onu_online"])
        if base >= 10 and s["onu_online"] <= base * 0.8:
            raise_alarm(key + ":onudrop", "critical", name, f"ONUs online dropped {base} → {s['onu_online']}")
        elif s["onu_online"] >= base * 0.9:
            clear_alarm(key + ":onudrop")


# ------------------------------------------------------------------ VLAN interface watch
IFPREV, IFHIST = {}, {}


def _fmt(bps):
    return f"{bps / 1e9:.2f} Gbps" if bps >= 1e9 else (f"{bps / 1e6:.1f} Mbps" if bps >= 1e6 else f"{bps / 1e3:.0f} Kbps")


def evaluate_iface(r, w, row, c, prev):
    key = f"if:{w['rid']}:{w['name']}"
    dev = f"{r['name']} · {w['name']}"
    if not row["running"] and not row.get("disabled"):
        FAILS[key + ":down"] += 1
        if FAILS[key + ":down"] >= 2:
            raise_alarm(key + ":down", "critical", dev, "VLAN interface is DOWN")
    else:
        FAILS[key + ":down"] = 0
        clear_alarm(key + ":down")
    u = row["util"]
    if u is not None:
        lvl = "critical" if u >= w["crit"] else ("warning" if u >= w["warn"] else None)
        if lvl:
            FAILS[key + ":util"] += 1
            if FAILS[key + ":util"] >= 2:
                raise_alarm(key + ":util", lvl, dev, f"Utilization {u}% of {w['cap']} Mbps (in {_fmt(row['rx_bps'])}, out {_fmt(row['tx_bps'])})")
        else:
            FAILS[key + ":util"] = 0
            clear_alarm(key + ":util")
    cur = max(row["rx_bps"] or 0, row["tx_bps"] or 0)
    h = IFHIST.setdefault(key, collections.deque(maxlen=10))
    if len(h) >= 6 and w["cap"]:
        avg = sum(h) / len(h)
        if avg >= 0.05 * w["cap"] * 1e6 and cur < 0.1 * avg:
            FAILS[key + ":drop"] += 1
            if FAILS[key + ":drop"] >= 2:
                raise_alarm(key + ":drop", "warning", dev, f"Traffic dropped abnormally: {_fmt(avg)} → {_fmt(cur)}")
        else:
            FAILS[key + ":drop"] = 0
            if cur >= 0.3 * avg:
                clear_alarm(key + ":drop")
    h.append(cur)
    de = c["err"] - prev[3]
    if de >= 100:
        FAILS[key + ":calm"] = 0
        raise_alarm(key + ":err", "warning", dev, f"{de} new interface errors since the last check")
    else:
        FAILS[key + ":calm"] += 1
        if FAILS[key + ":calm"] >= 5:
            clear_alarm(key + ":err")


def poll_ifaces(routers):
    with SessionLocal() as db:
        watch = [
            dict(
                id=w.id,
                rid=w.router_id,
                name=w.name,
                kind=w.kind or "vlan",
                enabled=bool(w.enabled),
                cap=w.capacity_mbps or 1000,
                warn=w.warn_pct or 80,
                crit=w.crit_pct or 90,
            )
            for w in db.query(IfaceWatch).all()
            if mikrotik.is_vlan_iface(w.name, w.kind)
        ]
    by_router = {}
    for w in watch:
        by_router.setdefault(w["rid"], []).append(w)
    rmap = {r["id"]: r for r in routers}

    def work(rid):
        r = rmap.get(rid)
        if not r:
            return rid, None, "router missing"
        try:
            data, via = mikrotik.get_iface_counters(r, vlan_only=True)
            return rid, data, via
        except Exception as e:
            return rid, None, str(e)[:100]

    out, now = [], time.time()
    with ThreadPoolExecutor(max_workers=6) as ex:
        results = list(ex.map(work, list(by_router)))
    for rid, data, via in results:
        r = rmap.get(rid) or {}
        for w in by_router[rid]:
            row = dict(
                id=w["id"],
                router=r.get("name", "?"),
                router_id=rid,
                name=w["name"],
                kind=w["kind"],
                enabled=w["enabled"],
                cap=w["cap"],
                rx_bps=None,
                tx_bps=None,
                util=None,
                running=None,
                ok=False,
                warn=w["warn"],
                crit=w["crit"],
                via=via if data else None,
            )
            if not data or w["name"] not in data:
                row["error"] = via if not data else "VLAN not found"
                if w["enabled"]:
                    out.append(row)
                continue
            c = data[w["name"]]
            prev = IFPREV.get((rid, w["name"]))
            IFPREV[(rid, w["name"])] = (now, c["rx"], c["tx"], c["err"])
            row.update(ok=True, running=c["running"], disabled=c["disabled"], vid=c.get("vid"), parent=c.get("parent"))
            if prev and now > prev[0] and c["rx"] >= prev[1] and c["tx"] >= prev[2]:
                dt = now - prev[0]
                rx, tx = (c["rx"] - prev[1]) * 8 / dt, (c["tx"] - prev[2]) * 8 / dt
                row.update(rx_bps=rx, tx_bps=tx, util=round(max(rx, tx) / (w["cap"] * 1e6) * 100, 1) if w["cap"] else None)
                if w["enabled"]:
                    try:
                        evaluate_iface(r, w, row, c, prev)
                    except Exception:
                        log.exception("iface eval")
            if w["enabled"]:
                out.append(row)
    return out


def discover_ifaces(router_ids=None):
    """Strictly discover ONLY router VLAN interfaces and remove any non-VLAN interfaces from IfaceWatch."""
    with SessionLocal() as db:
        routers = ctx.router_dicts(db)
        # Clean any legacy non-VLAN entries
        for w in db.query(IfaceWatch).all():
            if not mikrotik.is_vlan_iface(w.name, w.kind):
                db.delete(w)
        db.commit()

    n = 0
    for r in routers:
        if router_ids and r["id"] not in router_ids:
            continue
        try:
            data, _ = mikrotik.get_iface_counters(r, vlan_only=True)
        except Exception:
            continue
        with SessionLocal() as db:
            existing = {w.name: w for w in db.query(IfaceWatch).filter_by(router_id=r["id"])}
            for name, c in data.items():
                if not c.get("is_vlan") and not mikrotik.is_vlan_iface(name, c.get("type", "")):
                    continue
                kind_str = c.get("kind") or "vlan"
                if name not in existing:
                    db.add(IfaceWatch(
                        router_id=r["id"],
                        name=name,
                        kind=kind_str[:24],
                        enabled=False,
                        capacity_mbps=1000,
                        note=(c.get("comment") or "")[:120],
                    ))
                    n += 1
                else:
                    w = existing[name]
                    if kind_str and w.kind != kind_str[:24]:
                        w.kind = kind_str[:24]
                    if not w.note and c.get("comment"):
                        w.note = c["comment"][:120]
            db.commit()
    return n


def discover_async(ids=None):
    threading.Thread(target=discover_ifaces, args=(ids,), daemon=True).start()


# ------------------------------------------------------------------ PPTP tunnels watchdog / daily report
_tun_try = {}


def tunnel_watchdog():
    try:
        import vpn
    except Exception:
        return
    if not vpn.available():
        return
    with SessionLocal() as db:
        ts = [dict(id=t.id, name=t.name, server=t.server, username=t.username, password=t.password, mppe=t.mppe,
                   routes=t.routes, auto=t.auto) for t in db.query(Tunnel).all()]
    for t in ts:
        if not t["auto"]:
            continue
        key = f"tunnel:{t['id']}"
        s = vpn.status(t)
        if s["up"]:
            FAILS[key] = 0
            clear_alarm(key)
            continue
        FAILS[key] += 1
        if FAILS[key] >= 3:
            raise_alarm(key, "warning", f"VPN {t['name']}", f"PPTP tunnel to {t['server']} is down")
        if not s["daemon"] and time.time() - _tun_try.get(t["id"], 0) > 90:
            _tun_try[t["id"]] = time.time()
            try:
                vpn.write_all(ts)
                threading.Thread(target=lambda: vpn.connect(t), daemon=True).start()
            except Exception:
                log.exception("tunnel connect")


def report_text(title="📊 <b>Network status</b>"):
    s = snapshot()
    L = [title]
    for r in s.get("routers", []):
        L.append(f"🖧 <b>{escape(r['name'])}</b> " + (f"🟢 CPU {r.get('cpu')}% · {r.get('active')} PPPoE users" if r.get("ok") else "🔴 unreachable"))
    for o in s.get("olts", []):
        if not o.get("ok"):
            L.append(f"🛰 <b>{escape(o['name'])}</b> 🔴 unreachable")
            continue
        bad = [p for p in o.get("pons", []) if (p["total"] and not p["up"]) or (p["total"] and p["online"] < 0.7 * p["total"])]
        L.append(f"🛰 <b>{escape(o['name'])}</b> 🟢 ONU {o.get('onu_online')}/{o.get('onu_total')}" +
                 (" · ⚠️ PON " + ", ".join(p["pon"] for p in bad) if bad else ""))
    with SessionLocal() as db:
        al = db.query(Alarm).filter(Alarm.cleared_at.is_(None)).count()
    L.append(f"🚨 Active alarms: {al}")
    return "\n".join(L)


_last_report = {"day": None}


def maybe_daily_report():
    try:
        hour = int(get_setting("daily_report_hour", "-1") or -1)
    except ValueError:
        return
    now = datetime.now()
    if hour >= 0 and now.hour == hour and _last_report["day"] != now.date():
        _last_report["day"] = now.date()
        _notify(report_text("🗓 <b>Daily network report</b>"), "info", "Daily report", "report")


# ------------------------------------------------------------------ polling
def _olt_snap(o):
    try:
        s = oltlib.snapshot(o)
    except Exception as e:
        s = dict(ok=False, error=str(e)[:150], pons=[], onu_total=0, onu_online=0, onu_supported=False)
    return s


def poll_once():
    if not _poll_lock.acquire(blocking=False):
        return
    try:
        t0 = time.time()
        with SessionLocal() as db:
            routers = ctx.router_dicts(db)
            profs = {p.id: p for p in db.query(OltProfile)}
            olts = [ctx.olt_dict(o, profs) for o in db.query(OLT).filter(OLT.enabled.is_(True))]
        with ThreadPoolExecutor(max_workers=8) as ex:
            rf = [(r, ex.submit(mikrotik.system_stats, r)) for r in routers]
            of = [(o, ex.submit(_olt_snap, o)) for o in olts]
            rs, os_ = [], []
            for r, f in rf:
                try:
                    s = f.result()
                except Exception as e:
                    s = dict(ok=False, error=str(e)[:100])
                s.update(id=r["id"], name=r["name"], host=r["host"], api=r.get("api_enabled", True), snmp=r.get("snmp_enabled"))
                rs.append(s)
            for o, f in of:
                s = f.result()
                s.update(id=o["id"], name=o["name"], host=o["host"], vendor=o.get("vendor"))
                os_.append(s)
        for r, s in zip(routers, rs):
            try:
                evaluate_router(r, s)
                h = HIST.get(("r", r["id"], "active"))
                s["spark"] = [v for _, v in list(h)[-40:]] if h else []
            except Exception:
                log.exception("router eval")
        for o, s in zip(olts, os_):
            try:
                evaluate_olt(o, s)
            except Exception:
                log.exception("olt eval")
        try:
            ifs = poll_ifaces(routers)
        except Exception:
            log.exception("iface poll")
            ifs = []
        with _lock:
            SNAP.update(ts=time.time(), routers=rs, olts=os_, ifaces=ifs, took=round(time.time() - t0, 1),
                        interval=int(cfg("mon_interval", 30)))
    finally:
        _poll_lock.release()


def snapshot():
    with _lock:
        return dict(SNAP)


def start():
    def loop():
        time.sleep(3)
        n = 0
        while True:
            try:
                if n % 30 == 0:
                    discover_ifaces()
                poll_once()
                tunnel_watchdog()
                maybe_daily_report()
            except Exception:
                log.exception("poll")
            n += 1
            time.sleep(max(5, cfg("mon_interval", 30)))
    threading.Thread(target=loop, daemon=True).start()
