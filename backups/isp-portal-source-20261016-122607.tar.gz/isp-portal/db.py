import json
import os
import secrets
from datetime import datetime
from sqlalchemy import (Boolean, Column, DateTime, Float, ForeignKey, Integer, String, Text, create_engine,
                        inspect, text)
from sqlalchemy.orm import declarative_base, relationship, sessionmaker

os.makedirs("data", exist_ok=True)
DB_URL = os.getenv("DATABASE_URL", "sqlite:///./data/portal.db")
engine = create_engine(DB_URL, connect_args={"check_same_thread": False} if DB_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(bind=engine, autoflush=False)
Base = declarative_base()

STATUS_LABEL = {"open": "Open", "waiting": "Waiting for update", "replied": "Replied", "closed": "Closed"}


class Setting(Base):
    __tablename__ = "settings"
    key = Column(String(64), primary_key=True)
    value = Column(Text, default="")


class Admin(Base):
    __tablename__ = "admins"
    id = Column(Integer, primary_key=True)
    username = Column(String(64), unique=True)
    password_hash = Column(String(256))
    full_name = Column(String(64), default="")
    role = Column(String(12), default="super")        # super / admin / read
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_login = Column(DateTime, nullable=True)
    layout = Column(Text, default="")                 # dashboard widget layout (JSON)


class Router(Base):
    __tablename__ = "routers"
    id = Column(Integer, primary_key=True)
    name = Column(String(64))
    host = Column(String(128))
    api_enabled = Column(Boolean, default=True)
    port = Column(Integer, default=8728)
    username = Column(String(64), default="")
    password = Column(String(128), default="")
    use_ssl = Column(Boolean, default=False)
    snmp_enabled = Column(Boolean, default=False)
    snmp_port = Column(Integer, default=161)
    snmp_community = Column(String(64), default="public")


class OltProfile(Base):
    """Vendor OID profile. `oids` = {field: {"oid": column OID, "div": 1, "unit": "dbm", "alt": [...]}}"""
    __tablename__ = "olt_profiles"
    id = Column(Integer, primary_key=True)
    name = Column(String(64))
    vendor = Column(String(32), default="Other")
    enterprise_oid = Column(String(64), default="")
    index_template = Column(String(64), default="{ifindex}")   # vars: ifindex slot pon onu
    oids = Column(Text, default="{}")
    status_map = Column(String(255), default="")             # "1=Online,2=Offline"
    notes = Column(Text, default="")


class OLT(Base):
    __tablename__ = "olts"
    id = Column(Integer, primary_key=True)
    name = Column(String(64))
    vendor = Column(String(32), default="BDCOM")
    host = Column(String(128))
    snmp_port = Column(Integer, default=161)
    community = Column(String(64), default="public")
    snmp_version = Column(String(4), default="2c")
    profile_id = Column(Integer, ForeignKey("olt_profiles.id", ondelete="SET NULL"), nullable=True)
    vlans = Column(String(255), default="")      # optional: community@vlan tries for FDB lookup
    enabled = Column(Boolean, default=True)


class Customer(Base):
    __tablename__ = "customers"
    id = Column(Integer, primary_key=True)
    token = Column(String(32), unique=True, index=True)
    user_id = Column(String(128), unique=True, index=True)   # PPPoE username
    name = Column(String(128), default="")
    phone = Column(String(20), default="", index=True)
    address = Column(String(255), default="")
    onu_mac = Column(String(20), default="")                 # optional manual ONU MAC
    router_id = Column(Integer, ForeignKey("routers.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    complaints = relationship("Complaint", back_populates="customer", cascade="all, delete-orphan",
                              order_by="Complaint.id.desc()")


class Complaint(Base):
    __tablename__ = "complaints"
    id = Column(Integer, primary_key=True)
    customer_id = Column(Integer, ForeignKey("customers.id"))
    category = Column(String(64))
    message = Column(Text, default="")
    contact_phone = Column(String(20), default="")
    status = Column(String(16), default="open", index=True)   # open / waiting / replied / closed
    created_at = Column(DateTime, default=datetime.utcnow)
    resolved_at = Column(DateTime, nullable=True)
    resolved_by = Column(String(64), default="")
    resolve_note = Column(Text, default="")
    tg_message_id = Column(Integer, nullable=True)
    notify_error = Column(String(255), default="")
    diag_json = Column(Text, default="")
    tg_diag_message_id = Column(Integer, nullable=True)
    olt_name = Column(String(64), default="")
    pon = Column(String(16), default="")
    customer = relationship("Customer", back_populates="complaints")
    replies = relationship("ComplaintReply", cascade="all, delete-orphan", order_by="ComplaintReply.id")


class ComplaintReply(Base):
    __tablename__ = "complaint_replies"
    id = Column(Integer, primary_key=True)
    complaint_id = Column(Integer, ForeignKey("complaints.id"))
    role = Column(String(12), default="staff")      # staff / customer / system
    author = Column(String(64), default="")
    kind = Column(String(12), default="reply")      # reply / wait / close
    message = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)


class Alarm(Base):
    __tablename__ = "alarms"
    id = Column(Integer, primary_key=True)
    key = Column(String(128), index=True)
    level = Column(String(12), default="warning")      # critical / warning
    device = Column(String(64), default="")
    message = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)
    last_seen = Column(DateTime, default=datetime.utcnow)
    cleared_at = Column(DateTime, nullable=True)
    ack_by = Column(String(64), default="")


class AuditLog(Base):
    __tablename__ = "audit_log"
    id = Column(Integer, primary_key=True)
    ts = Column(DateTime, default=datetime.utcnow)
    who = Column(String(64), default="")
    action = Column(String(32), default="")
    target = Column(String(128), default="")
    detail = Column(Text, default="")


def audit(db, who, action, target="", detail=""):
    db.add(AuditLog(who=who or "", action=action, target=target, detail=(detail or "")[:500]))
    db.commit()


class Tunnel(Base):
    """PPTP client tunnel from this server to a MikroTik, so private device IPs behind it become reachable."""
    __tablename__ = "tunnels"
    id = Column(Integer, primary_key=True)
    name = Column(String(64))
    server = Column(String(128))
    username = Column(String(64))
    password = Column(String(128))
    mppe = Column(Boolean, default=True)
    routes = Column(Text, default="")        # comma separated subnets reachable through the tunnel
    auto = Column(Boolean, default=True)
    note = Column(String(255), default="")


class Integration(Base):
    __tablename__ = "integrations"
    id = Column(Integer, primary_key=True)
    name = Column(String(64))
    kind = Column(String(16))                # telegram / email / webhook / sms
    enabled = Column(Boolean, default=True)
    events = Column(String(64), default="alarm,ticket")
    config = Column(Text, default="{}")
    last_error = Column(Text, default="")
    last_ok = Column(DateTime, nullable=True)


class IfaceWatch(Base):
    __tablename__ = "iface_watch"
    id = Column(Integer, primary_key=True)
    router_id = Column(Integer, ForeignKey("routers.id", ondelete="CASCADE"))
    name = Column(String(64))
    kind = Column(String(24), default="")
    enabled = Column(Boolean, default=False)
    capacity_mbps = Column(Integer, default=1000)
    warn_pct = Column(Integer, default=80)
    crit_pct = Column(Integer, default=90)
    note = Column(String(128), default="")


class Sample(Base):
    """Per-user diagnosis history (signal / ping trend)."""
    __tablename__ = "samples"
    id = Column(Integer, primary_key=True)
    uid = Column(String(128), index=True)
    ts = Column(DateTime, default=datetime.utcnow, index=True)
    state = Column(String(12), default="")
    rx = Column(Float, nullable=True)
    tx = Column(Float, nullable=True)
    olt_rx = Column(Float, nullable=True)
    distance = Column(Float, nullable=True)
    loss = Column(Integer, nullable=True)
    avg = Column(Float, nullable=True)
    jitter = Column(Float, nullable=True)
    olt = Column(String(64), default="")
    pon = Column(String(16), default="")


# ==============================================================================
# Complete, Production-Verified Multi-Vendor OLT OID Profiles & MIB Definitions
# ==============================================================================
MASTER_PROFILES = [
    {
        "name": "BDCOM EPON",
        "vendor": "BDCOM",
        "enterprise_oid": "1.3.6.1.4.1.3320",
        "index_template": "{ifindex}",
        "status_map": "0=Authenticated,1=Registered,2=Deregistered,3=Online,4=Lost",
        "notes": (
            "BDCOM P3310 / P3600 Series EPON MIB (NMS-EPON-ONU-MIB / 1.3.6.1.4.1.3320.101). "
            "Indexed by ONU logical ifIndex (EPON0/x:y). Distance uses .10.1.1.27 (ifIndex) with automatic fallback "
            "to .11.1.1.7 (<PON ifIndex>.<ONU MAC>)."
        ),
        "oids": {
            "status": dict(oid="1.3.6.1.4.1.3320.101.10.1.1.26", div=1, unit="dbm", index="ifindex"),
            "rx": dict(oid="1.3.6.1.4.1.3320.101.10.5.1.5", div=10, unit="dbm", index="ifindex"),
            "tx": dict(oid="1.3.6.1.4.1.3320.101.10.5.1.6", div=10, unit="dbm", index="ifindex"),
            "olt_rx": dict(oid="1.3.6.1.4.1.3320.101.107.1.3", div=10, unit="dbm", index="ifindex",
                           alt=["1.3.6.1.4.1.3320.9.183.1.1.5"]),
            "distance": dict(oid="1.3.6.1.4.1.3320.101.10.1.1.27", div=1, unit="dbm", index="auto",
                             alt=["1.3.6.1.4.1.3320.101.11.1.1.7"]),
            "mac": dict(oid="1.3.6.1.4.1.3320.101.10.1.1.3", div=1, unit="dbm", index="ifindex"),
            "vendor": dict(oid="1.3.6.1.4.1.3320.101.10.1.1.1", div=1, unit="dbm", index="ifindex"),
            "model": dict(oid="1.3.6.1.4.1.3320.101.10.1.1.2", div=1, unit="dbm", index="ifindex"),
            "temp": dict(oid="1.3.6.1.4.1.3320.101.10.5.1.2", div=256, unit="dbm", index="ifindex"),
            "voltage": dict(oid="1.3.6.1.4.1.3320.101.10.5.1.3", div=10000, unit="dbm", index="ifindex"),
            "uptime": dict(oid="1.3.6.1.4.1.3320.101.10.1.1.80", div=1, unit="dbm", index="ifindex"),
            "uni_status": dict(oid="1.3.6.1.4.1.3320.101.12.1.1.8", div=1, unit="dbm", index="ifindex"),
        },
    },
    {
        "name": "BDCOM GPON",
        "vendor": "BDCOM",
        "enterprise_oid": "1.3.6.1.4.1.3320.10",
        "index_template": "{ifindex}",
        "status_map": "1=Offline,2=Inactive,3=Online,4=Working",
        "notes": (
            "BDCOM GP3600 Series GPON MIB (NMS-GPON-MIB / 1.3.6.1.4.1.3320.10). "
            "Indexed by GPON ONU ifIndex (GPON0/x:y). Optical power unit 0.1 dBm, distance in meters."
        ),
        "oids": {
            "status": dict(oid="1.3.6.1.4.1.3320.10.3.1.1.33", div=1, unit="dbm", index="ifindex"),
            "rx": dict(oid="1.3.6.1.4.1.3320.10.3.4.1.2", div=10, unit="dbm", index="ifindex"),
            "tx": dict(oid="1.3.6.1.4.1.3320.10.3.4.1.3", div=10, unit="dbm", index="ifindex"),
            "olt_rx": dict(oid="1.3.6.1.4.1.3320.10.2.3.1.4", div=10, unit="dbm", index="ifindex"),
            "distance": dict(oid="1.3.6.1.4.1.3320.10.3.1.1.35", div=1, unit="dbm", index="ifindex"),
            "mac": dict(oid="1.3.6.1.4.1.3320.10.3.1.1.4", div=1, unit="dbm", index="ifindex"),
            "vendor": dict(oid="1.3.6.1.4.1.3320.10.3.1.1.2", div=1, unit="dbm", index="ifindex"),
            "model": dict(oid="1.3.6.1.4.1.3320.10.3.1.1.9", div=1, unit="dbm", index="ifindex"),
            "temp": dict(oid="1.3.6.1.4.1.3320.10.3.4.1.4", div=256, unit="dbm", index="ifindex"),
            "voltage": dict(oid="1.3.6.1.4.1.3320.10.3.4.1.5", div=10000, unit="dbm", index="ifindex"),
        },
    },
    {
        "name": "V-SOL EPON",
        "vendor": "VSOL",
        "enterprise_oid": "1.3.6.1.4.1.37950",
        "index_template": "{pon}.{onu}",
        "status_map": "1=Online,0=Offline,2=Offline",
        "notes": (
            "V-SOL V1600D Series EPON MIB (1.3.6.1.4.1.37950.1.1.5.12). "
            "Indexed by {pon}.{onu} with automatic fallback to {ifindex}. Supports both text optical strings "
            "('0.01 mW (-18.45 dBm)') and numeric 0.1/0.01 dBm tables."
        ),
        "oids": {
            "status": dict(oid="1.3.6.1.4.1.37950.1.1.5.12.1.12.1.7", div=1, unit="dbm", index="auto",
                           alt=["1.3.6.1.4.1.37950.1.1.5.12.1.25.1.4"]),
            "rx": dict(oid="1.3.6.1.4.1.37950.1.1.5.12.2.1.8.1.7", div=1, unit="dbm_str", index="auto",
                       alt=["1.3.6.1.4.1.37950.1.1.5.10.12.5.1.5"]),
            "tx": dict(oid="1.3.6.1.4.1.37950.1.1.5.12.2.1.8.1.6", div=1, unit="dbm_str", index="auto",
                       alt=["1.3.6.1.4.1.37950.1.1.5.10.12.5.1.6"]),
            "distance": dict(oid="1.3.6.1.4.1.37950.1.1.5.12.1.12.1.10", div=1, unit="dbm", index="auto",
                             alt=["1.3.6.1.4.1.37950.1.1.5.12.1.25.1.9"]),
            "mac": dict(oid="1.3.6.1.4.1.37950.1.1.5.12.1.12.1.3", div=1, unit="dbm", index="auto",
                        alt=["1.3.6.1.4.1.37950.1.1.5.12.1.9.1.5", "1.3.6.1.4.1.37950.1.1.5.12.1.25.1.3"]),
            "name": dict(oid="1.3.6.1.4.1.37950.1.1.5.12.1.12.1.2", div=1, unit="dbm", index="auto"),
            "vendor": dict(oid="1.3.6.1.4.1.37950.1.1.5.12.1.12.1.11", div=1, unit="dbm", index="auto"),
            "model": dict(oid="1.3.6.1.4.1.37950.1.1.5.12.1.12.1.12", div=1, unit="dbm", index="auto"),
            "temp": dict(oid="1.3.6.1.4.1.37950.1.1.5.12.2.1.8.1.3", div=1, unit="dbm", index="auto"),
            "voltage": dict(oid="1.3.6.1.4.1.37950.1.1.5.12.2.1.8.1.4", div=1, unit="dbm", index="auto"),
            "uptime": dict(oid="1.3.6.1.4.1.37950.1.1.5.12.1.12.1.15", div=1, unit="dbm", index="auto"),
        },
    },
    {
        "name": "V-SOL GPON",
        "vendor": "VSOL",
        "enterprise_oid": "1.3.6.1.4.1.37950",
        "index_template": "{pon}.{onu}",
        "status_map": "1=Online,2=Offline,0=Offline,3=LOS",
        "notes": (
            "V-SOL V1600G Series GPON MIB (1.3.6.1.4.1.37950.1.1.6). "
            "Indexed by {pon}.{onu} with fallback to {ifindex}."
        ),
        "oids": {
            "status": dict(oid="1.3.6.1.4.1.37950.1.1.6.1.1.4.1.5", div=1, unit="dbm", index="auto"),
            "rx": dict(oid="1.3.6.1.4.1.37950.1.1.6.1.1.3.1.7", div=1, unit="dbm_str", index="auto",
                       alt=["1.3.6.1.4.1.37950.1.1.6.1.1.3.1.5"]),
            "tx": dict(oid="1.3.6.1.4.1.37950.1.1.6.1.1.3.1.6", div=1, unit="dbm_str", index="auto"),
            "olt_rx": dict(oid="1.3.6.1.4.1.37950.1.1.6.1.1.3.1.8", div=1, unit="dbm_str", index="auto"),
            "distance": dict(oid="1.3.6.1.4.1.37950.1.1.6.1.1.4.1.7", div=1, unit="dbm", index="auto"),
            "mac": dict(oid="1.3.6.1.4.1.37950.1.1.6.1.1.4.1.3", div=1, unit="dbm", index="auto"),
            "name": dict(oid="1.3.6.1.4.1.37950.1.1.6.1.1.4.1.24", div=1, unit="dbm", index="auto"),
            "vendor": dict(oid="1.3.6.1.4.1.37950.1.1.6.1.1.2.1.2", div=1, unit="dbm", index="auto"),
            "model": dict(oid="1.3.6.1.4.1.37950.1.1.6.1.1.2.1.4", div=1, unit="dbm", index="auto"),
            "temp": dict(oid="1.3.6.1.4.1.37950.1.1.6.1.1.3.1.3", div=1, unit="dbm", index="auto"),
            "voltage": dict(oid="1.3.6.1.4.1.37950.1.1.6.1.1.3.1.4", div=1, unit="dbm", index="auto"),
        },
    },
    {
        "name": "C-Data EPON",
        "vendor": "C-Data",
        "enterprise_oid": "1.3.6.1.4.1.17409",
        "index_template": "{ifindex}",
        "status_map": "1=Online,2=Offline,3=PowerOff,4=LOS",
        "notes": (
            "C-Data FD1104 / FD1108 / FD1208 / FD1608 EPON MIB (NSCRTV-EPON-MIB 1.3.6.1.4.1.17409.2.3 & 34592). "
            "Rx/Tx optical power in 0.01 dBm (divisor 100), distance in meters."
        ),
        "oids": {
            "status": dict(oid="1.3.6.1.4.1.17409.2.3.4.1.1.8", div=1, unit="dbm", index="auto"),
            "rx": dict(oid="1.3.6.1.4.1.17409.2.3.4.2.1.4", div=100, unit="dbm", index="auto"),
            "tx": dict(oid="1.3.6.1.4.1.17409.2.3.4.2.1.5", div=100, unit="dbm", index="auto"),
            "olt_rx": dict(oid="1.3.6.1.4.1.17409.2.3.4.2.1.13", div=100, unit="dbm", index="auto"),
            "distance": dict(oid="1.3.6.1.4.1.17409.2.3.4.1.1.15", div=1, unit="dbm", index="auto"),
            "mac": dict(oid="1.3.6.1.4.1.17409.2.3.4.1.1.7", div=1, unit="dbm", index="auto"),
            "name": dict(oid="1.3.6.1.4.1.17409.2.3.4.1.1.2", div=1, unit="dbm", index="auto"),
            "vendor": dict(oid="1.3.6.1.4.1.17409.2.3.4.1.1.13", div=1, unit="dbm", index="auto"),
            "model": dict(oid="1.3.6.1.4.1.17409.2.3.4.1.1.14", div=1, unit="dbm", index="auto"),
            "temp": dict(oid="1.3.6.1.4.1.17409.2.3.4.2.1.7", div=100, unit="dbm", index="auto"),
            "voltage": dict(oid="1.3.6.1.4.1.17409.2.3.4.2.1.6", div=100000, unit="dbm", index="auto"),
        },
    },
    {
        "name": "C-Data GPON",
        "vendor": "C-Data",
        "enterprise_oid": "1.3.6.1.4.1.17409.2.8",
        "index_template": "{ifindex}",
        "status_map": "1=Online,2=Offline,3=LOS",
        "notes": (
            "C-Data FD1608S / FD1616S GPON MIB (1.3.6.1.4.1.17409.2.8). "
            "Rx/Tx optical power in 0.01 dBm (divisor 100), distance in meters."
        ),
        "oids": {
            "status": dict(oid="1.3.6.1.4.1.17409.2.8.4.1.1.7", div=1, unit="dbm", index="auto"),
            "rx": dict(oid="1.3.6.1.4.1.17409.2.8.4.4.1.4", div=100, unit="dbm", index="auto"),
            "tx": dict(oid="1.3.6.1.4.1.17409.2.8.4.4.1.5", div=100, unit="dbm", index="auto"),
            "olt_rx": dict(oid="1.3.6.1.4.1.17409.2.8.4.4.1.9", div=100, unit="dbm", index="auto"),
            "distance": dict(oid="1.3.6.1.4.1.17409.2.8.4.1.1.9", div=1, unit="dbm", index="auto"),
            "mac": dict(oid="1.3.6.1.4.1.17409.2.8.4.1.1.3", div=1, unit="dbm", index="auto"),
            "name": dict(oid="1.3.6.1.4.1.17409.2.8.4.1.1.2", div=1, unit="dbm", index="auto"),
            "model": dict(oid="1.3.6.1.4.1.17409.2.8.4.1.1.5", div=1, unit="dbm", index="auto"),
            "temp": dict(oid="1.3.6.1.4.1.17409.2.8.4.4.1.7", div=100, unit="dbm", index="auto"),
            "voltage": dict(oid="1.3.6.1.4.1.17409.2.8.4.4.1.6", div=100000, unit="dbm", index="auto"),
        },
    },
    {
        "name": "DBC / Corelink / HSGQ OLT",
        "vendor": "DBC/HSGQ",
        "enterprise_oid": "1.3.6.1.4.1.3320",
        "index_template": "{ifindex}",
        "status_map": "1=Online,0=Offline,2=Offline,3=Online",
        "notes": (
            "Universal profile for DBC, Corelink, HSGQ, GCOM & RicherLink EPON/GPON OLTs. "
            "Automatically probes BDCOM (3320), V-SOL (37950), and C-Data/NSCRTV (17409) MIB trees."
        ),
        "oids": {
            "status": dict(oid="1.3.6.1.4.1.3320.101.10.1.1.26", div=1, unit="dbm", index="auto",
                           alt=["1.3.6.1.4.1.37950.1.1.5.12.1.12.1.7", "1.3.6.1.4.1.17409.2.3.4.1.1.8"]),
            "rx": dict(oid="1.3.6.1.4.1.3320.101.10.5.1.5", div=10, unit="dbm", index="auto",
                       alt=["1.3.6.1.4.1.37950.1.1.5.12.2.1.8.1.7", "1.3.6.1.4.1.17409.2.3.4.2.1.4"]),
            "tx": dict(oid="1.3.6.1.4.1.3320.101.10.5.1.6", div=10, unit="dbm", index="auto",
                       alt=["1.3.6.1.4.1.37950.1.1.5.12.2.1.8.1.6", "1.3.6.1.4.1.17409.2.3.4.2.1.5"]),
            "olt_rx": dict(oid="1.3.6.1.4.1.3320.101.107.1.3", div=10, unit="dbm", index="auto",
                           alt=["1.3.6.1.4.1.17409.2.3.4.2.1.13"]),
            "distance": dict(oid="1.3.6.1.4.1.3320.101.10.1.1.27", div=1, unit="dbm", index="auto",
                             alt=["1.3.6.1.4.1.3320.101.11.1.1.7", "1.3.6.1.4.1.37950.1.1.5.12.1.12.1.10",
                                  "1.3.6.1.4.1.17409.2.3.4.1.1.15"]),
            "mac": dict(oid="1.3.6.1.4.1.3320.101.10.1.1.3", div=1, unit="dbm", index="auto",
                        alt=["1.3.6.1.4.1.37950.1.1.5.12.1.12.1.3", "1.3.6.1.4.1.17409.2.3.4.1.1.7"]),
            "vendor": dict(oid="1.3.6.1.4.1.3320.101.10.1.1.1", div=1, unit="dbm", index="auto",
                           alt=["1.3.6.1.4.1.37950.1.1.5.12.1.12.1.11", "1.3.6.1.4.1.17409.2.3.4.1.1.13"]),
            "model": dict(oid="1.3.6.1.4.1.3320.101.10.1.1.2", div=1, unit="dbm", index="auto",
                          alt=["1.3.6.1.4.1.37950.1.1.5.12.1.12.1.12", "1.3.6.1.4.1.17409.2.3.4.1.1.14"]),
            "temp": dict(oid="1.3.6.1.4.1.3320.101.10.5.1.2", div=256, unit="dbm", index="auto"),
            "voltage": dict(oid="1.3.6.1.4.1.3320.101.10.5.1.3", div=10000, unit="dbm", index="auto"),
        },
    },
    {
        "name": "Huawei OLT (generic)",
        "vendor": "Huawei",
        "enterprise_oid": "1.3.6.1.4.1.2011",
        "index_template": "{ifindex}.{onu}",
        "status_map": "1=Online,2=Offline,3=LOS",
        "notes": (
            "Huawei SmartAX MA5600T / MA5608T / MA5800 GPON & EPON MIB (HUAWEI-XPON-MIB 1.3.6.1.4.1.2011.6.128.1.1). "
            "Indexed by <PON ifIndex>.<ONU ID>. Optical power unit 0.01 dBm (divisor 100), distance in meters."
        ),
        "oids": {
            "status": dict(oid="1.3.6.1.4.1.2011.6.128.1.1.2.46.1.15", div=1, unit="dbm", index="auto"),
            "rx": dict(oid="1.3.6.1.4.1.2011.6.128.1.1.2.51.1.4", div=100, unit="dbm", index="auto"),
            "tx": dict(oid="1.3.6.1.4.1.2011.6.128.1.1.2.51.1.3", div=100, unit="dbm", index="auto"),
            "olt_rx": dict(oid="1.3.6.1.4.1.2011.6.128.1.1.2.51.1.6", div=100, unit="dbm", index="auto"),
            "distance": dict(oid="1.3.6.1.4.1.2011.6.128.1.1.2.46.1.20", div=1, unit="dbm", index="auto",
                             alt=["1.3.6.1.4.1.2011.6.128.1.1.2.53.1.1.5"]),
            "mac": dict(oid="1.3.6.1.4.1.2011.6.128.1.1.2.43.1.3", div=1, unit="dbm", index="auto",
                        alt=["1.3.6.1.4.1.2011.6.128.1.1.2.53.1.1.2"]),
            "name": dict(oid="1.3.6.1.4.1.2011.6.128.1.1.2.43.1.9", div=1, unit="dbm", index="auto"),
            "model": dict(oid="1.3.6.1.4.1.2011.6.128.1.1.2.45.1.4", div=1, unit="dbm", index="auto"),
            "vendor": dict(oid="1.3.6.1.4.1.2011.6.128.1.1.2.45.1.2", div=1, unit="dbm", index="auto"),
            "temp": dict(oid="1.3.6.1.4.1.2011.6.128.1.1.2.51.1.1", div=1, unit="dbm", index="auto"),
            "voltage": dict(oid="1.3.6.1.4.1.2011.6.128.1.1.2.51.1.5", div=50, unit="dbm", index="auto"),
        },
    },
    {
        "name": "ZTE OLT (generic)",
        "vendor": "ZTE",
        "enterprise_oid": "1.3.6.1.4.1.3902",
        "index_template": "{ifindex}.{onu}",
        "status_map": "1=Logging,2=LOS,3=Online,4=DyingGasp,5=AuthFailed,6=Offline",
        "notes": (
            "ZTE ZXA10 C300 / C320 / C600 GPON & EPON MIB (1.3.6.1.4.1.3902.1012.3 & 1015). "
            "Indexed by <PON ifIndex>.<ONU ID>. Optical power unit 0.001 dBm (or ZTE offset), distance in meters."
        ),
        "oids": {
            "status": dict(oid="1.3.6.1.4.1.3902.1012.3.28.2.1.4", div=1, unit="dbm", index="auto"),
            "rx": dict(oid="1.3.6.1.4.1.3902.1012.3.50.12.1.1.10", div=1000, unit="dbm_zte", index="auto"),
            "tx": dict(oid="1.3.6.1.4.1.3902.1012.3.50.12.1.1.14", div=1000, unit="dbm_zte", index="auto"),
            "olt_rx": dict(oid="1.3.6.1.4.1.3902.1012.3.50.12.1.1.3", div=1000, unit="dbm_zte", index="auto"),
            "distance": dict(oid="1.3.6.1.4.1.3902.1012.3.11.4.1.2", div=1, unit="dbm", index="auto"),
            "mac": dict(oid="1.3.6.1.4.1.3902.1012.3.28.1.1.5", div=1, unit="dbm", index="auto"),
            "name": dict(oid="1.3.6.1.4.1.3902.1012.3.28.1.1.2", div=1, unit="dbm", index="auto"),
            "model": dict(oid="1.3.6.1.4.1.3902.1012.3.28.1.1.1", div=1, unit="dbm", index="auto"),
            "vendor": dict(oid="1.3.6.1.4.1.3902.1012.3.50.11.2.1.1", div=1, unit="dbm", index="auto"),
            "temp": dict(oid="1.3.6.1.4.1.3902.1012.3.50.12.1.1.19", div=256, unit="dbm", index="auto"),
            "voltage": dict(oid="1.3.6.1.4.1.3902.1012.3.50.12.1.1.17", div=50, unit="dbm", index="auto"),
        },
    },
    {
        "name": "FiberHome OLT (generic)",
        "vendor": "FiberHome",
        "enterprise_oid": "1.3.6.1.4.1.5875",
        "index_template": "{ifindex}",
        "status_map": "1=Online,0=Offline,2=LOS",
        "notes": (
            "FiberHome AN5516 / AN5116 GPON & EPON MIB (1.3.6.1.4.1.5875.800.3). "
            "Optical power unit 0.01 dBm (divisor 100), distance in meters."
        ),
        "oids": {
            "status": dict(oid="1.3.6.1.4.1.5875.800.3.10.1.1.11", div=1, unit="dbm", index="auto"),
            "rx": dict(oid="1.3.6.1.4.1.5875.800.3.9.3.3.1.6", div=100, unit="dbm", index="auto"),
            "tx": dict(oid="1.3.6.1.4.1.5875.800.3.9.3.3.1.7", div=100, unit="dbm", index="auto"),
            "distance": dict(oid="1.3.6.1.4.1.5875.800.3.9.6.1.1.5", div=1, unit="dbm", index="auto"),
            "mac": dict(oid="1.3.6.1.4.1.5875.800.3.10.1.1.10", div=1, unit="dbm", index="auto"),
            "vendor": dict(oid="1.3.6.1.4.1.5875.800.3.10.1.1.6", div=1, unit="dbm", index="auto"),
            "model": dict(oid="1.3.6.1.4.1.5875.800.3.10.1.1.7", div=1, unit="dbm", index="auto"),
            "temp": dict(oid="1.3.6.1.4.1.5875.800.3.9.3.3.1.8", div=100, unit="dbm", index="auto"),
            "voltage": dict(oid="1.3.6.1.4.1.5875.800.3.9.3.3.1.9", div=100, unit="dbm", index="auto"),
        },
    },
    {
        "name": "Nokia / ALU OLT (generic)",
        "vendor": "Nokia",
        "enterprise_oid": "1.3.6.1.4.1.6527",
        "index_template": "{ifindex}",
        "status_map": "1=Online,2=Offline",
        "notes": "Nokia / Alcatel-Lucent ISAM 7360 GPON MIB (ASAM-ONT-MIB / TIMETRA).",
        "oids": {
            "status": dict(oid="1.3.6.1.4.1.637.61.1.35.10.1.1.2", div=1, unit="dbm", index="auto"),
            "rx": dict(oid="1.3.6.1.4.1.637.61.1.35.10.14.1.2", div=10, unit="dbm", index="auto"),
            "tx": dict(oid="1.3.6.1.4.1.637.61.1.35.10.14.1.4", div=10, unit="dbm", index="auto"),
            "distance": dict(oid="1.3.6.1.4.1.637.61.1.35.10.1.1.29", div=1, unit="dbm", index="auto"),
            "mac": dict(oid="1.3.6.1.4.1.637.61.1.35.10.1.1.5", div=1, unit="dbm", index="auto"),
            "model": dict(oid="1.3.6.1.4.1.637.61.1.35.10.1.1.25", div=1, unit="dbm", index="auto"),
        },
    },
    {
        "name": "Ubiquiti UFiber (generic)",
        "vendor": "Ubiquiti",
        "enterprise_oid": "1.3.6.1.4.1.41112",
        "index_template": "{pon}.{onu}",
        "status_map": "1=Online,0=Offline",
        "notes": "Ubiquiti UFiber GPON OLT MIB (1.3.6.1.4.1.41112.1.9).",
        "oids": {
            "status": dict(oid="1.3.6.1.4.1.41112.1.9.3.1.1.6", div=1, unit="dbm", index="auto"),
            "rx": dict(oid="1.3.6.1.4.1.41112.1.9.3.1.1.8", div=100, unit="dbm", index="auto"),
            "tx": dict(oid="1.3.6.1.4.1.41112.1.9.3.1.1.9", div=100, unit="dbm", index="auto"),
            "distance": dict(oid="1.3.6.1.4.1.41112.1.9.3.1.1.7", div=1, unit="dbm", index="auto"),
            "mac": dict(oid="1.3.6.1.4.1.41112.1.9.3.1.1.2", div=1, unit="dbm", index="auto"),
            "model": dict(oid="1.3.6.1.4.1.41112.1.9.3.1.1.3", div=1, unit="dbm", index="auto"),
        },
    },
]


def _migrate():
    """Add columns that new versions introduced and clean non-VLAN interfaces from iface_watch."""
    insp = inspect(engine)
    with engine.begin() as conn:
        for t in Base.metadata.sorted_tables:
            if not insp.has_table(t.name):
                continue
            have = {c["name"] for c in insp.get_columns(t.name)}
            for col in t.columns:
                if col.name in have:
                    continue
                d = col.default.arg if col.default is not None else None
                if callable(d):
                    d = None
                ddl = f'ALTER TABLE {t.name} ADD COLUMN {col.name} {col.type.compile(engine.dialect)}'
                if isinstance(d, bool):
                    ddl += f" DEFAULT {int(d)}"
                elif isinstance(d, (int, float)):
                    ddl += f" DEFAULT {d}"
                elif isinstance(d, str):
                    ddl += " DEFAULT '" + d.replace("'", "''") + "'"
                conn.execute(text(ddl))
        conn.execute(text("UPDATE complaints SET status='closed' WHERE status='resolved'"))
        # Clean non-VLAN interfaces from iface_watch so only router VLAN interfaces remain
        conn.execute(text("DELETE FROM iface_watch WHERE lower(kind) NOT LIKE '%vlan%' AND lower(name) NOT LIKE '%vlan%'"))


def seed_profiles(db, force_reset_id=None):
    """Ensure all master OLT profiles exist with full, accurate OIDs and auto-link OLTs without profiles."""
    by_name = {p.name: p for p in db.query(OltProfile).all()}
    master_map = {m["name"]: m for m in MASTER_PROFILES}

    for m in MASTER_PROFILES:
        p = by_name.get(m["name"])
        if not p:
            p = OltProfile(
                name=m["name"],
                vendor=m["vendor"],
                enterprise_oid=m["enterprise_oid"],
                index_template=m["index_template"],
                status_map=m["status_map"],
                notes=m["notes"],
                oids=json.dumps(m["oids"]),
            )
            db.add(p)
        else:
            # Populate or upgrade OIDs if empty, unconfigured, or low-confidence from older seed
            try:
                cur_oids = json.loads(p.oids or "{}")
            except ValueError:
                cur_oids = {}
            should_upgrade = (
                force_reset_id == p.id
                or not cur_oids
                or len(cur_oids) < 4
                or any((v or {}).get("conf") == "low" for v in cur_oids.values())
            )
            if should_upgrade:
                merged = dict(m["oids"])
                if force_reset_id != p.id:
                    for k, v in cur_oids.items():
                        if (v or {}).get("oid") and (v or {}).get("conf") != "low" and k not in merged:
                            merged[k] = v
                p.oids = json.dumps(merged)
                p.enterprise_oid = m["enterprise_oid"]
                p.index_template = m["index_template"]
                p.status_map = m["status_map"]
                p.notes = m["notes"]
                p.vendor = m["vendor"]
    db.commit()

    # Auto-assign matching vendor profile to any OLT that has no profile or points to an empty generic profile
    all_profs = db.query(OltProfile).all()
    vendor_to_prof = {}
    for p in all_profs:
        vendor_to_prof.setdefault(p.vendor.lower(), p.id)
        if "epon" in p.name.lower():
            vendor_to_prof[p.vendor.lower()] = p.id
    for o in db.query(OLT).all():
        prof = db.get(OltProfile, o.profile_id) if o.profile_id else None
        has_oids = False
        if prof:
            try:
                has_oids = bool(json.loads(prof.oids or "{}"))
            except ValueError:
                has_oids = False
        if not prof or not has_oids:
            vkey = (o.vendor or "").lower()
            pid = vendor_to_prof.get(vkey) or vendor_to_prof.get("dbc/hsgq") or vendor_to_prof.get("bdcom")
            if pid:
                o.profile_id = pid
    db.commit()


def init_db():
    Base.metadata.create_all(engine)
    _migrate()
    with SessionLocal() as db:
        seed_profiles(db)


def get_setting(key, default=""):
    with SessionLocal() as db:
        s = db.get(Setting, key)
        return s.value if s and s.value is not None else default


def set_setting(key, value):
    with SessionLocal() as db:
        s = db.get(Setting, key)
        if s:
            s.value = value
        else:
            db.add(Setting(key=key, value=value))
        db.commit()


def get_or_create_secret_key():
    env_key = os.getenv("SECRET_KEY", "").strip()
    if env_key:
        return env_key
    saved = get_setting("session_secret_key", "")
    if not saved:
        saved = secrets.token_hex(32)
        set_setting("session_secret_key", saved)
    return saved


def apply_action(db, cid, action, by, message="", role="staff"):
    """action: reply / wait / close. Returns complaint, or None if missing/closed."""
    c = db.get(Complaint, cid)
    if not c or c.status == "closed":
        return None
    message = (message or "").strip()[:1000]
    if action == "close":
        c.status, c.resolved_at, c.resolved_by, c.resolve_note = "closed", datetime.utcnow(), by[:64], message
    elif action == "wait":
        c.status = "waiting"
    elif action == "reply":
        c.status = "replied" if role == "staff" else "open"
    db.add(ComplaintReply(complaint_id=c.id, role=role, author=by[:64], kind=action, message=message))
    db.commit()
    return c
