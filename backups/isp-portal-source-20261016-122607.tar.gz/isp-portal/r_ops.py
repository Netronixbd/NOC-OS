"""Operations routes: dashboard (widgets), device detail pages, VLAN interface watch, alarm state, diagnosis extras."""
import json
import time
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse, RedirectResponse
from sqlalchemy import func
from starlette.concurrency import run_in_threadpool

import ctx
import mikrotik
import monitor
import olt as oltlib
from core import flash, get_db, render
from db import OLT, Admin, Alarm, AuditLog, Complaint, IfaceWatch, OltProfile, Router, SessionLocal

router = APIRouter()
DEFAULT_LAYOUT = [
    dict(id="kpi", w=12),
    dict(id="alarms", w=6),
    dict(id="tickets", w=6),
    dict(id="routers", w=12),
    dict(id="olts", w=12),
    dict(id="ifaces", w=12),
    dict(id="history", w=6),
    dict(id="activity", w=6),
]
WIDTHS = (3, 4, 6, 8, 12)


# ------------------------------------------------------------------ dashboard
@router.get("/admin")
def dashboard(request: Request):
    return render(request, "admin_dashboard.html")


@router.get("/admin/api/dashboard")
async def api_dashboard(max_age: int = 0, refresh: int = 0):
    snap = monitor.snapshot()
    if refresh or (max_age and (not snap["ts"] or time.time() - snap["ts"] >= max_age)):
        await run_in_threadpool(monitor.poll_once)
        snap = monitor.snapshot()
    now = datetime.utcnow()
    with SessionLocal() as db:
        alarms = [
            dict(id=a.id, level=a.level, device=a.device, message=a.message, ack=a.ack_by,
                 since=int((now - a.created_at).total_seconds()))
            for a in db.query(Alarm).filter(Alarm.cleared_at.is_(None)).order_by(Alarm.id.desc()).limit(30)
        ]
        hist = [
            dict(id=a.id, device=a.device, message=a.message, level=a.level,
                 raised=a.created_at.isoformat(), cleared=a.cleared_at.isoformat())
            for a in db.query(Alarm).filter(Alarm.cleared_at.isnot(None)).order_by(Alarm.cleared_at.desc()).limit(12)
        ]
        tickets = [
            dict(id=c.id, uid=c.customer.user_id, name=c.customer.name, category=c.category, status=c.status)
            for c in db.query(Complaint).filter(Complaint.status != "closed").order_by(Complaint.id.desc()).limit(8)
        ]
        activity = [
            dict(ts=a.ts.isoformat(), who=a.who, action=a.action, target=a.target)
            for a in db.query(AuditLog).order_by(AuditLog.id.desc()).limit(10)
        ]
        tk = dict(
            open=db.query(Complaint).filter(Complaint.status != "closed").count(),
            today=db.query(Complaint).filter(Complaint.created_at >= now - timedelta(hours=24)).count(),
        )
    snap = dict(snap)
    snap.update(alarms=alarms, history=hist, tickets=tk, ticket_list=tickets, activity=activity,
                age=int(time.time() - snap["ts"]) if snap["ts"] else None, now=time.time())
    return JSONResponse(snap)


@router.get("/admin/api/layout")
def get_layout(request: Request, db=Depends(get_db)):
    a = db.get(Admin, request.state.user["id"])
    try:
        lay = json.loads(a.layout) if a.layout else None
    except ValueError:
        lay = None
    catalog = [
        dict(id="kpi", name="Key numbers"),
        dict(id="alarms", name="Active alarms"),
        dict(id="history", name="Alarm history"),
        dict(id="tickets", name="Open tickets"),
        dict(id="activity", name="Recent activity"),
        dict(id="routers", name="All routers"),
        dict(id="olts", name="All OLTs"),
        dict(id="ifaces", name="VLAN utilization"),
    ]
    catalog += [dict(id=f"router:{r.id}", name=f"Router · {r.name}") for r in db.query(Router).all()]
    catalog += [dict(id=f"olt:{o.id}", name=f"OLT · {o.name}") for o in db.query(OLT).all()]
    return JSONResponse(dict(layout=lay or DEFAULT_LAYOUT, default=DEFAULT_LAYOUT, catalog=catalog))


@router.post("/admin/api/layout")
async def set_layout(request: Request, db=Depends(get_db)):
    body = await request.json()
    lay = [dict(id=str(x["id"])[:40], w=int(x["w"]) if int(x.get("w", 6)) in WIDTHS else 6) for x in body.get("layout", [])][:40]
    a = db.get(Admin, request.state.user["id"])
    a.layout = json.dumps(lay) if not body.get("reset") else ""
    db.commit()
    return JSONResponse(dict(ok=True))


@router.get("/admin/api/alarm-state")
def alarm_state(after: int = 0, after_clear: float = 0.0, db=Depends(get_db)):
    """Returns both newly raised active alarms ('new') and newly resolved alarms ('resolved') for distinct Issue/Resolve sounds."""
    active = db.query(Alarm).filter(Alarm.cleared_at.is_(None)).order_by(Alarm.id.desc()).all()
    max_id = db.query(func.max(Alarm.id)).scalar() or 0

    # Newly resolved alarms since after_clear (within last 5 minutes)
    cutoff = datetime.utcnow() - timedelta(minutes=5)
    recent_cleared = (
        db.query(Alarm)
        .filter(Alarm.cleared_at.isnot(None), Alarm.cleared_at >= cutoff)
        .order_by(Alarm.cleared_at.desc())
        .limit(10)
        .all()
    )
    resolved = []
    max_clear = after_clear
    for a in recent_cleared:
        cts = a.cleared_at.replace(tzinfo=None).timestamp()
        if cts > max_clear:
            max_clear = cts
        if after_clear > 0 and cts > after_clear + 0.001:
            resolved.append(dict(id=a.id, level=a.level, device=a.device, message=a.message, cleared_ts=cts))

    return JSONResponse(dict(
        count=len(active),
        max_id=max_id,
        max_clear=round(max_clear, 3),
        crit=sum(a.level == "critical" for a in active),
        unacked_crit=sum(a.level == "critical" and not a.ack_by for a in active),
        new=[dict(id=a.id, level=a.level, device=a.device, message=a.message) for a in active if after > 0 and a.id > after][:5],
        resolved=resolved[:5],
    ))


# ------------------------------------------------------------------ device detail pages
@router.get("/admin/devices/router/{rid}/view")
def router_view(request: Request, rid: int, db=Depends(get_db)):
    r = db.get(Router, rid)
    if not r:
        return RedirectResponse("/admin/devices", 303)
    return render(request, "admin_device_router.html", r=r)


@router.get("/admin/api/device/router/{rid}")
async def api_router(rid: int, db=Depends(get_db)):
    r = next((x for x in ctx.router_dicts(db) if x["id"] == rid), None)
    if not r:
        return JSONResponse(dict(error="Router not found"), status_code=404)
    watch = {w.name: dict(id=w.id, enabled=w.enabled, cap=w.capacity_mbps) for w in db.query(IfaceWatch).filter_by(router_id=rid)}
    try:
        info = await run_in_threadpool(mikrotik.device_info, r)
    except Exception as e:
        return JSONResponse(dict(error=str(e)[:200]))
    info["watch"] = watch
    return JSONResponse(info)


@router.get("/admin/api/device/router/{rid}/counters")
async def api_router_counters(rid: int, db=Depends(get_db)):
    r = next((x for x in ctx.router_dicts(db) if x["id"] == rid), None)
    if not r:
        return JSONResponse(dict(error="Router not found"), status_code=404)
    try:
        data, via = await run_in_threadpool(mikrotik.get_iface_counters, r)
    except Exception as e:
        return JSONResponse(dict(error=str(e)[:200]))
    return JSONResponse(dict(ts=time.time(), via=via, ifaces={k: [v["rx"], v["tx"], v["running"], v["err"]] for k, v in data.items()}))


@router.get("/admin/devices/olt/{oid}/view")
def olt_view(request: Request, oid: int, db=Depends(get_db)):
    o = db.get(OLT, oid)
    if not o:
        return RedirectResponse("/admin/devices", 303)
    return render(request, "admin_device_olt.html", o=o, prof=db.get(OltProfile, o.profile_id))


def _dev(db, oid):
    o = db.get(OLT, oid)
    return ctx.olt_dict(o, {p.id: p for p in db.query(OltProfile)}) if o else None


@router.get("/admin/api/device/olt/{oid}")
async def api_olt(oid: int, db=Depends(get_db)):
    dev = _dev(db, oid)
    if not dev:
        return JSONResponse(dict(error="OLT not found"), status_code=404)
    try:
        d = await run_in_threadpool(oltlib.details, dev)
    except Exception as e:
        return JSONResponse(dict(error=str(e)[:200]))
    d.update(vendor=dev["vendor"], host=dev["host"], profile=dev["profile"]["name"])
    return JSONResponse(d)


@router.get("/admin/api/olt/{oid}/counters")
async def api_olt_counters(oid: int, ix: str = "", db=Depends(get_db)):
    dev = _dev(db, oid)
    ixs = [i for i in ix.split(",") if i.isdigit()][:40]
    if not dev or not ixs:
        return JSONResponse(dict(error="bad request"), status_code=400)
    try:
        c = await run_in_threadpool(oltlib.counters, dev, ixs)
    except Exception as e:
        return JSONResponse(dict(error=str(e)[:200]))
    return JSONResponse(dict(ts=time.time(), counters={k: list(v) for k, v in c.items()}))


# ------------------------------------------------------------------ VLAN interface watch
@router.get("/admin/interfaces")
def interfaces_page(request: Request, db=Depends(get_db)):
    routers = db.query(Router).all()
    rows = {}
    total_vlans = 0
    watched_vlans = 0
    for w in db.query(IfaceWatch).order_by(IfaceWatch.router_id, IfaceWatch.enabled.desc(), IfaceWatch.name).all():
        if not mikrotik.is_vlan_iface(w.name, w.kind):
            continue
        rows.setdefault(w.router_id, []).append(w)
        total_vlans += 1
        if w.enabled:
            watched_vlans += 1
    return render(request, "admin_interfaces.html", routers=routers, rows=rows, total_vlans=total_vlans, watched_vlans=watched_vlans)


@router.get("/admin/api/ifaces")
def api_ifaces():
    s = monitor.snapshot()
    return JSONResponse(dict(ifaces=s.get("ifaces", []), ts=s.get("ts")))


@router.post("/admin/interfaces/save")
async def interfaces_save(request: Request, db=Depends(get_db)):
    f = await request.form()
    n = 0
    for w in db.query(IfaceWatch).all():
        if f"cap_{w.id}" not in f:
            continue
        w.enabled = bool(f.get(f"en_{w.id}"))
        for attr, key, dflt in (("capacity_mbps", "cap", 1000), ("warn_pct", "warn", 80), ("crit_pct", "crit", 90)):
            try:
                setattr(w, attr, max(1, int(f.get(f"{key}_{w.id}") or dflt)))
            except ValueError:
                pass
        w.note = (f.get(f"note_{w.id}") or "")[:120]
        n += 1
    db.commit()
    if request.headers.get("x-requested-with") == "fetch" or "application/json" in (request.headers.get("accept") or ""):
        return JSONResponse(dict(ok=True, saved=n, message=f"Saved {n} VLAN interface(s)."))
    flash(request, f"Saved {n} VLAN interfaces. Alarms use these capacities and thresholds.")
    return RedirectResponse("/admin/interfaces", 303)


@router.post("/admin/interfaces/discover")
async def interfaces_discover(request: Request):
    n = await run_in_threadpool(monitor.discover_ifaces)
    if request.headers.get("x-requested-with") == "fetch" or "application/json" in (request.headers.get("accept") or ""):
        return JSONResponse(dict(ok=True, added=n, message=f"Discovery finished: {n} new VLAN interface(s) added."))
    flash(request, f"VLAN discovery finished: {n} new VLAN interface(s) added.")
    return RedirectResponse("/admin/interfaces", 303)


# ------------------------------------------------------------------ diagnosis tools
@router.get("/admin/api/ping-custom")
async def ping_custom(uid: str, count: int = 10, size: int = 0, df: int = 0, interval: str = "200ms"):
    count = max(1, min(50, count))
    size = size if 28 <= size <= 1500 else None
    interval = interval if interval in ("100ms", "200ms", "500ms", "1s") else "200ms"
    return JSONResponse(await run_in_threadpool(lambda: mikrotik.ping(uid, ctx.all_routers_fresh(), count, interval, size, bool(df))))


@router.get("/admin/api/mtu")
async def api_mtu(uid: str):
    return JSONResponse(await run_in_threadpool(lambda: mikrotik.mtu_probe(uid, ctx.all_routers_fresh())))
